# typecho-theme-i
一款简洁的Typecho模板
![demo](https://user-images.githubusercontent.com/31686695/104546820-fceddf80-5667-11eb-8c98-4947c7957a08.png)
