<?php
//数据库连接信息
$cfg_dbhost = '127.0.0.1';
$cfg_dbname = 'cms';
$cfg_dbuser = 'cms';
$cfg_dbpwd = '57c2f0b0a6ff3004';
$cfg_dbprefix = 'duomi_';
$cfg_db_language = 'utf8';
?>