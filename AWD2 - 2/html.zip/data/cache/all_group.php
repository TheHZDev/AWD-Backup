<?php
return array (
  0 => 
  array (
    'gid' => '1',
    'gname' => '游客用户',
    'gtype' => '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15',
    'g_auth' => '1,2,3',
    'g_upgrade' => '0',
    'g_authvalue' => '0',
  ),
  1 => 
  array (
    'gid' => '2',
    'gname' => '普通会员',
    'gtype' => '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15',
    'g_auth' => '1,2,3',
    'g_upgrade' => '10',
    'g_authvalue' => '0',
  ),
);
?>