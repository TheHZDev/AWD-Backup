<?php

// +----------------------------------------------------------------------
// | JiZhiCMS { 极致CMS，给您极致的建站体验 }  
// +----------------------------------------------------------------------
// | Copyright (c) 2018-2099 http://www.jizhicms.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: 留恋风 <2581047041@qq.com>
// +----------------------------------------------------------------------
// | Date：2019/11/15
// +----------------------------------------------------------------------

namespace A\exts;

use FrPHP\lib\Controller;
use FrPHP\Extend\Page;
class PluginsController extends Controller {
	
	
	//自动执行
	public function _init(){
		/**
			继承系统默认配置
		
		**/
		
		//检查当前账户是否合乎操作
		if(!isset($_SESSION['admin']) || $_SESSION['admin']['id']==0){
			Redirect(U('Login/index'));
			
		}
 
	    if($_SESSION['admin']['isadmin']!=1){
			if(strpos($_SESSION['admin']['paction'],','.APP_CONTROLLER.',')!==false){
			   
			}else{
				$action = APP_CONTROLLER.'/'.APP_ACTION;
				if(strpos($_SESSION['admin']['paction'],','.$action.',')===false){
				   $ac = M('Ruler')->find(array('fc'=>$action));
				   if($this->frparam('ajax')){
					   
					   JsonReturn(['code'=>1,'msg'=>'您没有【'.$ac['name'].'】的权限！','url'=>U('Index/index')]);
				   }
				   Error('您没有【'.$ac['name'].'】的权限！',U('Index/index'));
				}
			}
		   
		  
		}
	  
	    $webconf = webConf();
	    $this->webconf = $webconf;
	    $customconf = get_custom();
	    $this->customconf = $customconf;
		
		//插件模板页目录
		
		$this->tpl = '@'.dirname(__FILE__).'/tpl/';
		
		/**
			在下面添加自定义操作
		**/
		
		
	}
	
	//执行SQL语句在此处处理,或者移动文件也可以在此处理
	public  function install(){
		//下面是新增test表的SQL操作
		//检测是否已安装前台插件
		$filepath = APP_PATH.'Admin/plugins/JzwycController.php';
		if(file_exists($filepath)){
			JsonReturn(array('code'=>1,'msg'=>'后台Admin/plugins下面已存在相应的Jzwyc控制器！'));
		}
		//移动后台文件
		$dir = APP_PATH.'A/exts/jzwyc/file';
		copy($dir."/wyc.html",APP_PATH.'A/t/tpl/wyc.html');
		
		//写入系统权限控制
		$w['name'] = '伪原创';
		$w['fc'] = 'Jzwyc';
		$pid = M('ruler')->add($w);
		$w['name'] = '文章伪原创';
		$w['fc'] = 'Jzwyc/index';
		$w['pid'] = $pid;
		$w['isdesktop'] = 1;
		$n = M('ruler')->add($w);
		
		//写入左侧导航栏
		$dao = M('layout')->find('id=1');
		$left_layout = json_decode($dao['left_layout'],1);
		$left_layout[]=[
			"name" => "文章伪原创",
			"icon" => '&amp;#xe6a2;',
			"nav" => array($n)
		];
		$left_layout = json_encode($left_layout,JSON_UNESCAPED_UNICODE);
		M('layout')->update(['id'=>$dao['id']],['left_layout'=>$left_layout]);
		

		return true;
		
	}
	
	//卸载程序,对新增字段、表等进行删除SQL操作，或者其他操作
	public function uninstall(){
		//下面是删除test表的SQL操作
		unlink(APP_PATH."A/t/tpl/wyc.html");
		//删除权限表
		M('ruler')->delete(['fc'=>'Jzwyc']);
		M('ruler')->delete(['fc'=>'Jzwyc/index']);
		//删除左侧导航
		$dao = M('layout')->find('id=1');
		$left_layout = json_decode($dao['left_layout'],1);
		$new_layout = [];
		foreach($left_layout as $v){
			if($v['name']!='文章伪原创'){
				$new_layout[]=$v;
			}
		}
		$left_layout = json_encode($new_layout,JSON_UNESCAPED_UNICODE);
		M('layout')->update(['id'=>$dao['id']],['left_layout'=>$left_layout]);
		
		return true;
	}
	
	//安装页面介绍,操作说明
	public function desc(){
		
		$this->display($this->tpl.'plugins-description.html');
	}
	
	//配置文件,插件相关账号密码等操作
	public  function setconf($plugins){
		//将插件赋值到模板中
		$this->plugins = $plugins;
		$this->config = json_decode($plugins['config'],1);
		
		$this->display($this->tpl.'plugins-body.html');
	}
	//获取插件内提交的数据处理
	public function setconfigdata($data){
		
		
		JsonReturn(['code'=>0,'msg'=>'设置成功！']);
		
		
	}
	
	
}




