<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m">
<div><?php echo $msg;?></div>
<div><a href="<?php echo $url; ?>">返回</a></div>
</div>