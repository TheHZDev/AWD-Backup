<?php
//mysql database address
define('DB_HOST','localhost');
//mysql database user
define('DB_USER','cms');
//database password
define('DB_PASSWD','abd6d1c374e9b851');
//database name
define('DB_NAME','cms');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','V*QIBAs1GL!SM4bCt57FUwKpz4ORkmfh617c00a243a2514dc62e4fa0f14f9f82');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_9ulWwsd2Ub9rcqYorzAkucZpWlkVLg2g');
