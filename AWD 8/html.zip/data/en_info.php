<?php
$_confing=array (
  'web_name' => 'BEESCMS',
  'web_index_name' => '',
  'web_rewrite' => '0',
  'is_cache' => '1',
  'cache_time' => '30',
  'web_logo' => 'img/20121210/201212102144457490.gif',
  'web_template' => 'default_en',
  'phone_template' => 'default_phone',
  'web_powerby' => '',
  'web_tongji' => '',
  'web_keywords' => '',
  'web_description' => 'BEESCMS企业网站管理系统',
  'web_yinxiao' => '',
  'hot_key' => '',
  'all_key' => '',
  'nav' => 'websys',
  'admin_p_nav' => 'allsys',
);
?>