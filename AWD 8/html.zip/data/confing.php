<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD','root');
define('DB_NAME', 'beescms');
define('DB_PRE', 'bees_');
define('DB_PCONNECT', 0);
define('DB_CHARSET', 'utf8');
define('CMS_ADDTIME', 1505278617);
define('CMS_SELF','/');
?>