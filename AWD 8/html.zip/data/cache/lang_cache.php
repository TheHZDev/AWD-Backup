<?php
$lang_cache=array (
  0 => 
  array (
    'id' => '9',
    'lang_name' => '简体中文',
    'lang_order' => '10',
    'lang_tag' => 'cn',
    'lang_is_use' => '1',
    'lang_is_open' => '0',
    'lang_is_url' => '0',
    'lang_url' => 'http://',
    'lang_is_fix' => '1',
    'lang_main' => '1',
  ),
  1 => 
  array (
    'id' => '10',
    'lang_name' => 'English',
    'lang_order' => '9',
    'lang_tag' => 'en',
    'lang_is_use' => '1',
    'lang_is_open' => '0',
    'lang_is_url' => '0',
    'lang_url' => 'http://',
    'lang_is_fix' => '0',
    'lang_main' => '0',
  ),
);
?>