<?php
include('./cms_inc.php');
include('./cms_check.php');
if (isset($_POST['save'])){
	null_back($_POST['c_name'],'请填写频道名称');
	null_back($_POST['c_parent'],'请选择上级频道');
	null_back($_POST['c_cmodel'],'请选择或填写频道模型');
	null_back($_POST['c_dmodel'],'请选择或填写详情模型');
	null_back($_POST['c_mcmodel'],'请选择或填写手机频道模型');
	null_back($_POST['c_mdmodel'],'请选择或填写手机详情模型');
	non_numeric_back($_POST['c_page'],'分页条数必须是数字');
	non_numeric_back($_POST['c_order'],'排序必须是数字');
	$_data['c_name'] = $_POST['c_name'];
	$_data['c_parent'] = $_POST['c_parent'];
	$_data['c_cmodel'] = $_POST['c_cmodel'];
	$_data['c_dmodel'] = $_POST['c_dmodel'];
	$_data['c_mcmodel'] = $_POST['c_mcmodel'];
	$_data['c_mdmodel'] = $_POST['c_mdmodel'];
	$_data['c_content'] = $_POST['c_content'];
	$_data['c_scontent'] = $_POST['c_scontent'];
	$_data['c_mcontent'] = $_POST['c_mcontent'];
	$_data['c_mscontent'] = $_POST['c_mscontent'];
	$_data['c_page'] = $_POST['c_page'];
	$_data['c_seoname'] = $_POST['c_seoname'];
	$_data['c_keywords'] = $_POST['c_keywords'];
	$_data['c_description'] = $_POST['c_description'];
	$_data['c_nav'] = $_POST['c_nav'];
	$_data['c_nname'] = ($_POST['c_nname'] == '' ? $_POST['c_name'] : $_POST['c_nname'] );
	$_data['c_link'] = $_POST['c_link'];
	$_data['c_sname'] = $_POST['c_sname'];
	$_data['c_aname'] = $_POST['c_aname'];
	$_data['c_cover'] = $_POST['c_cover'];
	$_data['c_icon'] = $_POST['c_icon'];
	$_data['c_target'] = $_POST['c_target'];
	$_data['c_safe'] = $_POST['c_safe'];
	$_data['c_rh'] = $_POST['c_rh'];
	$_data['c_order'] = $_POST['c_order'];
	$sql = 'update cms_channel set '.arrtoupdate($_data).' where id = '.$_GET['id'].'';
	if(sql_query($sql)){
		update_channel();
		alert_href('频道修改成功!','cms_channel.php');
	}else{
		alert_back('修改失败!');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	K.create('#c_content');
	K.create('#c_scontent');
	K.create('#c_mcontent');
	K.create('#c_mscontent');
	var editor = K.editor();
	K('#cover_upload').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#c_cover').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#c_cover').val(url);
				editor.hideDialog();
				}
			});
		});
	});
	K('#icon_upload').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#c_icon').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#c_icon').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
		<?php include('./cms_inc_left.php') ?>
		<div id="right">
			<div class="hd-1">修改频道</div>
			<div class="bd-1">
				<?php
				$result = sql_query('select * from cms_channel where id = '.$_GET['id']);
				if ($row = sql_fetch_array($result)){
				?>
				<form method="post">
					<div class="l20">
						<div class="form-group x3">
							<div class="label"><label for="c_name">频道名称 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="c_name" class="input" name="c_name" type="text" size="60" data-validate="required:请输入频道名称" value="<?php echo $row['c_name'];?>" />
								<div class="input-note">请输入频道名称</div>
							</div>
						</div>
						<div class="form-group x4">
							<div class="label"><label for="c_parent">上级频道</label></div>
							<div class="field">
								<select id="c_parent" class="input" name="c_parent">
									<option value="0">作为主频道</option>
									<?php echo channel_select_list(0,0,$row['c_parent'],$_GET['id']);?>
								</select>
								<div class="input-note">请选择要添加频道的上级频道</div>
							</div>
						</div>
						<div class="form-group x5">
							<div class="label"><label for="c_nname">导航名称</label></div>
							<div class="field">
								<div class="l4">
									<div class="x8"><input id="c_nname" class="input" name="c_nname" type="text" size="30" value="" /></div>
									<div class="x4">
										<select class="input" name="c_nav" >
										<option value="1" <?php echo ($row['c_nav'] == 1) ? 'selected="selected"' : '' ; ?>>显示</option>
										<option value="0" <?php echo ($row['c_nav'] == 0) ? 'selected="selected"' : '' ; ?>>隐藏</option>
										<?php
										if (!$system_closem) {
										?>
										<option value="2" <?php echo ($row['c_nav'] == 2) ? 'selected="selected"' : '' ; ?>>强制显示</option>
										<option value="3" <?php echo ($row['c_nav'] == 3) ? 'selected="selected"' : '' ; ?>>强制电脑显示</option>
										<option value="4" <?php echo ($row['c_nav'] == 4) ? 'selected="selected"' : '' ; ?>>强制手机显示</option>
										<option value="5" <?php echo ($row['c_nav'] == 5) ? 'selected="selected"' : '' ; ?>>电脑隐藏</option>
										<option value="6" <?php echo ($row['c_nav'] == 6) ? 'selected="selected"' : '' ; ?>>手机隐藏</option>
										<?php
										}
										?>
										</select>
									</div>
								</div>
								<div class="input-note">留空后自动识别为频道名称，强制显示可以把非主频道显示到导航</div>
							</div>
						</div>
						<div class="fc"></div>
						<div class="form-group x3">
							<div class="label"><label for="c_cmodel">频道模型 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<div class="l4">
									<div class="x6">
										<input id="c_cmodel" class="input" name="c_cmodel" type="text" data-validate="required:请选择或输入频道模型" value="<?php echo $row['c_cmodel'];?>" />
									</div>
									<div class="x6">
										<select class="input" onChange="c_cmodel.value=this.value;c_cmodel.focus();c_cmodel.blur();">
											<option value="">选择或填写</option>
											<?php echo model_select_list(1,$row['c_cmodel'])?>
										</select>
									</div>
								</div>
								<div class="input-note">电脑端频道模型</div>
							</div>
						</div>
						<div class="form-group x3">
							<div class="label"><label for="c_dmodel">详情模型 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<div class="l4">
									<div class="x6">
										<input id="c_dmodel" class="input" name="c_dmodel" type="text" data-validate="required:请选择或输入详情模型" value="<?php echo $row['c_dmodel'];?>" />
									</div>
									<div class="x6">
										<select class="input" onChange="c_dmodel.value=this.value;c_dmodel.focus();c_dmodel.blur();">
											<option value="">选择或填写</option>
											<?php echo model_select_list(2,$row['c_dmodel'])?>
										</select>
									</div>
								</div>
								<div class="input-note">电脑端详情模型</div>
							</div>
						</div>
						<div class="form-group x3<?php echo ($system_closem) ? ' dn' : '' ;?>">
							<div class="label"><label for="c_mcmodel">手机频道模型 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<div class="l4">
									<div class="x6">
										<input id="c_mcmodel" class="input" name="c_mcmodel" type="text" data-validate="required:请选择或输入手机频道模型" value="<?php echo $row['c_mcmodel'];?>" />
									</div>
									<div class="x6">
										<select class="input" onChange="c_mcmodel.value=this.value;c_mcmodel.focus();c_mcmodel.blur();">
											<option value="">选择或填写</option>
											<?php echo model_select_list(3,$row['c_mcmodel'])?>
										</select>
									</div>
									</div>
								<div class="input-note">手机端频道模型</div>
							</div>
						</div>
						<div class="form-group x3<?php echo ($system_closem) ? ' dn' : '' ;?>">
							<div class="label"><label for="c_mdmodel">手机详情模型 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<div class="l4">
									<div class="x6">
										<input id="c_mdmodel" class="input" name="c_mdmodel" type="text" data-validate="required:请选择或输入手机详情模型" value="<?php echo $row['c_mdmodel'];?>" />
									</div>
									<div class="x6">
										<select class="input" onChange="c_mdmodel.value=this.value;c_mdmodel.focus();c_mdmodel.blur();">
											<option value="">选择或填写</option>
											<?php echo model_select_list(4,$row['c_mdmodel'])?>
										</select>
									</div>
								</div>
								<div class="input-note">电脑端手机详情模型</div>
							</div>
						</div>
						<div class="fc"></div>
						<div class="form-group x12">
							<div class="label"><label for="c_content">详细内容</label></div>
							<div class="field">
								<textarea id="c_content" class="input" name="c_content" row="5" /><?php echo htmlspecialchars($row['c_content'])?></textarea>
								<div class="input-note">显示在频道页，多用于单页显示。</div>
							</div>
						</div>
						<div class="form-group x12">
							<div class="label"><label for="c_scontent">简短内容</label></div>
							<div class="field">
								<textarea id="c_scontent" class="input" name="c_scontent" row="5" /><?php echo htmlspecialchars($row['c_scontent'])?></textarea>
								<div class="input-note">多用于首页部分内容显示</div>
							</div>
						</div>
						<div class="form-group x12<?php echo ($system_closem) ? ' dn' : '' ;?>">
							<div class="label"><label for="c_mcontent">手机详细内容</label></div>
							<div class="field">
								<textarea id="c_mcontent" class="input" name="c_mcontent" /><?php echo htmlspecialchars($row['c_mcontent'])?></textarea>
								<div class="input-note">留空后自动识别为电脑端详细内容</div>
							</div>
						</div>
						<div class="form-group x12<?php echo ($system_closem) ? ' dn' : '' ;?>">
							<div class="label"><label for="c_mscontent">手机简短内容</label></div>
							<div class="field">
								<textarea id="c_mscontent" class="input" name="c_mscontent" row="5" /><?php echo htmlspecialchars($row['c_mscontent'])?></textarea>
								<div class="input-note">留空后自动识别为识别为电脑端简短内容</div>
							</div>
						</div>
						<div class="form-group x4">
							<div class="label"><label for="c_seoname">优化标题</label></div>
							<div class="field">
								<input id="c_seoname" class="input" name="c_seoname" type="text" size="60" value="<?php echo $row['c_seoname'];?>" />
								<div class="input-note">填写后优先显示在频道名称前</div>
							</div>
						</div>
						<div class="form-group x4">
							<div class="label"><label for="c_keywords">关键字</label></div>
							<div class="field">
								<input id="c_keywords" class="input" name="c_keywords" type="text" size="60" value="<?php echo $row['c_keywords'];?>" />
								<div class="input-note">填写相关字词，有助于优化，可用英文逗号或空格间隔。</div>
							</div>
						</div>
						<div class="form-group x4">
							<div class="label"><label for="c_description">关键描述</label></div>
							<div class="field">
								<input id="c_description" class="input" name="c_description" type="text" size="60" value="<?php echo $row['c_description'];?>" />
								<div class="input-note">填写相关描述，有助于优化。</div>
							</div>
						</div>
						<div class="form-group x2">
							<div class="label"><label for="c_aname">别名</label></div>
							<div class="field">
								<input id="c_aname" class="input" name="c_aname" type="text" size="60" value="<?php echo $row['c_aname'];?>" />
								<div class="input-note">一般用英文配合显示</div>
							</div>
						</div>
						<div class="form-group x2">
							<div class="label"><label for="c_sname">短名</label></div>
							<div class="field">
								<input id="c_sname" class="input" name="c_sname" type="text" size="60" value="<?php echo $row['c_sname'];?>" />
								<div class="input-note">作用于推荐**，热门**等</div>
							</div>
						</div>
						<div class="form-group x2">
							<div class="label"><label for="c_page">分页</label></div>
							<div class="field">
								<input id="c_page" class="input" name="c_page" type="text" size="60" data-validate="required:必填,plusinteger:请输入合法的分页数字" value="<?php echo $row['c_page'];?>" />
								<div class="input-note">频道页每页显示多少条</div>
							</div>
						</div>
						<div class="form-group x2">
							<div class="label"><label for="c_order">排序</label></div>
							<div class="field">
								<input id="c_order" class="input" name="c_order" type="text" size="60" data-validate="required:必填,plusinteger:请输入合法的排序数字" value="<?php echo $row['c_order'];?>" />
								<div class="input-note">填写0自动识别为ID</div>
							</div>
						</div>
						<div class="form-group x4">
							<div class="label"><label for="c_link">链接</label></div>
							<div class="field">
								<input id="c_link" class="input" name="c_link" type="text" size="60" value="<?php echo $row['c_link'];?>" data-validate="url:请填写合法的URL地址" />
								<div class="input-note">外部地址请用http://开始</div>
							</div>
						</div>
						<div class="form-group x2">
							<div class="label"><label for="c_cover">封面</label> <span class="badge bg-green cp" id="cover_upload">上传</span></div>
							<div class="field">
								<input id="c_cover" class="input" name="c_cover" type="text" size="60" value="<?php echo $row['c_cover'];?>" />
								<div class="input-note">显示在频道页的导航下部</div>
							</div>
						</div>
						<div class="form-group x2">
							<div class="label"><label for="c_icon">图标</label> <span class="badge bg-green cp" id="icon_upload">上传</span></div>
							<div class="field">
								<input id="c_icon" class="input" name="c_icon" type="text" size="60" value="<?php echo $row['c_icon'];?>" />
								<div class="input-note">二次开发使用</div>
							</div>
						</div>
						<div class="form-group x">
							<div class="label"><label for="c_target">打开方式</label></div>
							<div class="field">
								<label class="btn"><input id="c_target" name="c_target" type="radio" value="_self" <?php echo ($row['c_target'] == '_self' ? 'checked="checked"' : '')?>/>原窗口</label>
								<label class="btn"><input name="c_target" type="radio" value="_blank" <?php echo ($row['c_target'] == '_blank' ? 'checked="checked"' : '')?>/>新窗口</label>
								<div class="input-note">请选择打开方式</div>
							</div>
						</div>
						<div class="form-group x">
							<div class="label"><label for="c_rh">推荐热门</label></div>
							<div class="field">
								<label class="btn"><input id="c_rh" name="c_rh" type="radio" value="1" <?php echo ($row['c_rh'] == 1 ? 'checked="checked"' : '')?>/>显示</label>
								<label class="btn"><input name="c_rh" type="radio" value="0" <?php echo ($row['c_rh'] == 0 ? 'checked="checked"' : '')?>/>隐藏</label>
								<div class="input-note">是否显示推荐热门</div>
							</div>
						</div>
						<div class="form-group x">
							<div class="label"><label for="c_safe">保护</label></div>
							<div class="field">
								<label class="btn"><input id="c_safe" name="c_safe" type="radio" value="0" <?php echo ($row['c_safe'] == 0 ? 'checked="checked"' : '')?>/>不保护</label>
								<label class="btn"><input name="c_safe" type="radio" value="1" <?php echo ($row['c_safe'] == 1 ? 'checked="checked"' : '')?>/>保护</label>
								<div class="input-note">开启安全保护后，能有效防止误操作删除。</div>
							</div>
						</div>
						<div class="form-group x12">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot" name="save" type="submit" value="修改频道" />
							</div>
						</div>
					</div>
				</form>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?>
</body>
</html>