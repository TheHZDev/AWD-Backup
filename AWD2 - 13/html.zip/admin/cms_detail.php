<?php
include('./cms_inc.php');
include('./cms_check.php');
if (isset($_POST['execute'])) {
	null_back($_POST['id'],'请至少选中一项！');
	$s = '';
	$id = '';
	foreach( $_POST['id'] as $value ){
		$id .= $s.$value;
		$s = ',';
	}
	switch ($_POST['execute_method']){
		case 'srec':
			$sql = 'update cms_detail set d_rec = 1 where id in ('.$id.')';
			break;
		case 'crec':
			$sql = 'update cms_detail set d_rec = 0 where id in ('.$id.')';
			break;
		case 'shot':
			$sql = 'update cms_detail set d_hot = 1 where id in ('.$id.')';
			break;
		case 'chot':
			$sql = 'update cms_detail set d_hot = 0 where id in ('.$id.')';
			break;
		case 'delete':
			$sql = 'delete from cms_detail where id in ('.$id.')';
			break;
		default:
			alert_back('请选择要执行的操作');
	}
	sql_query($sql);
	alert_href('执行成功!','cms_detail.php?cid=0');
};
if ( isset($_POST['shift']) ) {
	null_back($_POST['id'],'请至少选中一项！');
	$s = '';
	$id = '';
	foreach( $_POST['id'] as $value ){
		$id .= $s.$value;
		$s = ',';
	}
	null_back($_POST['shift_target'],'请选择要转移到的频道');
	sql_query('update cms_detail set d_parent = '.$_POST['shift_target'].' where id in ('.$id.')');
	alert_href('转移成功!','cms_detail.php?cid=0');
}
if(isset($_GET['del'])){
	$sql = 'delete from cms_detail where id = '.$_GET['del'].'';
	if(sql_query($sql)){
		alert_href('删除成功!',url_decode($_GET['url']));
	}else{
		alert_back('error');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
<script type="text/javascript">
</script>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
		<?php include('./cms_inc_left.php') ?>
		<div id="right">
			<div class="hd-1">管理内容</div>
			<div class="bd-1">
				<form method="get">
					<div class="l10">
						<div class="form-group x3">
							<div class="label"><label for="key">关键字</label></div>
							<div class="field">
								<input id="key" class="input" name="key" type="text" size="60" value="" />
							</div>
						</div>
						<div class="form-group x4">
							<div class="label"><label for="cid">频道</label></div>
							<div class="field">
								<select id="cid" class="input" name="cid">
									<option value="0">不限制</option>
									<?php echo channel_select_list(0,0,(isset($_GET['cid'])) ? $_GET['cid'] : 0 ,0);?>
								</select>
							</div>
						</div>
						<div class="form-group x3">
							<div class="label"><label for="pro">属性</label></div>
							<div class="field">
								<select id="pro" class="input" name="pro">
									<option value="">不限制</option>
									<option value="pic" <?php echo (isset($_GET['pro']) && $_GET['pro'] == 'pic') ? ' selected="selected"' : '' ; ?>>有缩略图</option>
									<option value="rec" <?php echo (isset($_GET['pro']) && $_GET['pro'] == 'rec') ? ' selected="selected"' : '' ; ?>>推荐</option>
									<option value="hot" <?php echo (isset($_GET['pro']) && $_GET['pro'] == 'hot') ? ' selected="selected"' : '' ; ?>>热门</option>
									<option value="cov" <?php echo (isset($_GET['pro']) && $_GET['pro'] == 'cov') ? ' selected="selected"' : '' ; ?>>封面</option>
									<option value="file" <?php echo (isset($_GET['pro']) && $_GET['pro'] == 'file') ? ' selected="selected"' : '' ; ?>>有附件</option>
									<option value="link" <?php echo (isset($_GET['pro']) && $_GET['pro'] == 'link') ? ' selected="selected"' : '' ; ?>>外链</option>
								</select>
							</div>
						</div>
						<div class="form-group x2">
							<div class="label"><label>　</label></div>
							<div class="field">
								<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="按条件筛选" />
							</div>
						</div>
					</div>
				</form>
				<form method="post" class="form-auto">
					<table class="table table-bordered table-hover table-striped">
						<tr>
							<th>选择</th>
							<th>排序</th>
							<th width="77">缩略图</th>
							<th width="360">内容名称</th>
							<th>所属频道</th>
							<th>属性</th>
							<th>日期</th>
							<th>修改</th>
						</tr>
						<?php
						$sql = 'select id,d_order,d_picture,d_name,d_parent,d_rec,d_hot,d_date from cms_detail order by d_order desc , id desc';
						if (isset($_GET['save'])) {
							$sql = 'select id,d_order,d_picture,d_name,d_parent,d_rec,d_hot,d_date from cms_detail where '.true.'';
							if ($_GET['cid'] != 0) {
								$sql .= ' and d_parent in ('.get_channel($_GET['cid'],'c_sub').')';
							}
							if ($_GET['key'] != '') {
								$sql .= ' and d_name like "%'.$_GET['key'].'%"';
							}
							if ($_GET['pro'] != '') {
								switch ( $_GET['pro'] ) {
									case 'pic':
										$sql .= ' and d_picture <> ""';
										break;
									case 'rec':
										$sql .= ' and d_rec = 1';
										break;
									case 'hot':
										$sql .= ' and d_hot = 1';
										break;
									case 'cov':
										$sql .= ' and d_cov = 1';
										break;
									case 'file':
										$sql .= ' and d_file <> ""';
										break;
									case 'link':
										$sql .= ' and d_link <> ""';
										break;
								};
							}
							$sql .= ' order by d_order desc , id desc';
						}
						$pager = page_handle('page',20,sql_num_rows(sql_query($sql)));
						$result = sql_query($sql.' limit '.$pager[0].','.$pager[1].'');
						while($row= sql_fetch_array($result)){
						?>
						<tr class="ac">
							<td><input type="checkbox" name="id[]" value="<?php echo $row['id'] ?>" /></td>
							<td><?php echo $row['d_order'] ?></td>
							<td><?php echo ($row['d_picture'] == '') ? '' : '<img src="'.$row['d_picture'].'" width="60" />' ; ?></td>
							<td class="al"><?php echo '<a href="'.d_url($row['id']).'" target="_blank">'.$row['d_name'].'</a>' ?></td>
							<td><?php echo get_channel_name($row['d_parent'])?></td>
							<td>
								<?php
								echo ($row['d_rec'] == 1 ? '<span class="badge bg-main">荐</span> ':'');
								echo ($row['d_hot'] == 1 ? '<span class="badge bg-dot">热</span> ':'');
								echo ($row['d_picture'] != '' ? '<span class="badge">图</span>':'');
								?>
							</td>
							<td><?php echo date('Y-m-d',$row['d_date']) ?></td>
							<td>
								<a class="btn bg-sub" href="cms_detail_edit.php?id=<?php echo $row['id']?>&url=<?php echo url_encode(get_url());?>"><span class="icon-edit"> 修改</span></a>
								<a class="btn bg-dot" href="cms_detail.php?del=<?php echo $row['id']?>&url=<?php echo url_encode(get_url());?>" onclick="return confirm('确定要删除吗？')"><span class="icon-times"> 删除</span></a>
							</td>
						</tr>
						<?php } ?>
						<tr>
							<td><span class="btn bg-main" onclick="check_all('id[]')">选</span></td>
							<td colspan="7">
								<select id="execute_method" class="input" name="execute_method">
									<option value="">请选择操作</option>
									<option value="srec">设为推荐</option>
									<option value="crec">取消推荐</option>
									<option value="shot">设为热门</option>
									<option value="chot">取消热门</option>
									<option value="delete">删除选中</option>
								</select>
								<input type="submit" id="execute" class="btn bg-sub" name="execute" onclick="return confirm('确定要执行吗')" value="执行" />
								<select id="shift_target" class="input" name="shift_target">
									<option value="">请选择目标频道</option>
									<?php echo channel_select_list(0,0,0,0);?>
								</select>
								<input type="submit" id="shift" class="btn bg-sub" name="shift" onclick="return confirm('确定要转移吗')" value="转移" />
							</td>
						</tr>
					</table>
				</form>
				<div class="page_show"><?php echo page_show($pager[2],$pager[3],$pager[4],2);?> </div>
			</div>
		</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?>
</body>
</html>