<?php
include('./cms_inc.php');
include('./cms_check.php');
if(isset($_POST['save'])){
	sql_query('update cms_template set t_logo = "'.$_POST['s_logo'].'" where t_path = "'.$system_template.'"');
	sql_query('update cms_template set t_logo = "'.$_POST['s_mlogo'].'" where t_path = "'.$system_mtemplate.'"');
	$_data['s_domain'] = $_POST['s_domain'];
	$_data['s_mdomain'] = $_POST['s_mdomain'];
	$_data['s_name'] = $_POST['s_name'];
	$_data['s_mode'] = $_POST['s_mode'];
	$_data['s_seoname'] = $_POST['s_seoname'];
	$_data['s_keywords'] = $_POST['s_keywords'];
	$_data['s_description'] = $_POST['s_description'];
	$_data['s_copyright'] = $_POST['s_copyright'];
	$_data['s_mcopyright'] = $_POST['s_mcopyright'];
	$_data['s_hotkeywords'] = $_POST['s_hotkeywords'];
	$_data['s_feedback'] = $_POST['s_feedback'];
	$_data['s_phone'] = $_POST['s_phone'];
	$_data['s_qq'] = $_POST['s_qq'];
	$_data['s_qrcode'] = $_POST['s_qrcode'];
	$_data['s_p1'] = $_POST['s_p1'];
	$_data['s_p2'] = $_POST['s_p2'];
	$_data['s_p3'] = $_POST['s_p3'];
	$_data['s_p4'] = $_POST['s_p4'];
	$_data['s_square'] = $_POST['s_square'];
	$_data['s_slideshow'] = $_POST['s_slideshow'];
	$sql = 'update cms_system set '.arrtoupdate($_data).' where id = 1';
	if(sql_query($sql)){
		alert_href('系统设置修改成功!','cms_system.php');
	}else{
		alert_back('修改失败!');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	K.create('#s_copyright');
	K.create('#s_mcopyright');
	var editor = K.editor();
	K('#qrcode').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_qrcode').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_qrcode').val(url);
				editor.hideDialog();
				}
			});
		});
	});
	K('#mlogo').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_mlogo').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_mlogo').val(url);
				editor.hideDialog();
				}
			});
		});
	});
	K('#logo').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_logo').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_logo').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
			<?php include('./cms_inc_left.php') ?>
			<div id="right">
				<div class="hd-1">系统设置</div>
				<div class="bd-1">
					<?php
					$result = sql_query('select * from cms_system where id = 1');
					if( $row = sql_fetch_array($result)){
					?>
					<form method="post">
						<div class="l20">
							<div class="x3">
								<div class="form-group">
									<div class="label"><label for="s_mode">运行模式</label></div>
									<div class="field">
										<label class="btn"><input id="s_mode" name="s_mode" type="radio" value="1" <?php echo ($row['s_mode'] == 1) ? 'checked="checked"' : '' ; ?> />动态</label>
									</div>
								</div>
							</div>
							<div class="x3">
								<div class="form-group">
									<div class="label"><label for="s_name">网站名称</label></div>
									<div class="field">
										<input id="s_name" class="input" name="s_name" type="text" size="60" value="<?php echo $row['s_name'];?>"/>
										<div class="input-note">请填写网站名称</div>
									</div>
								</div>
							</div>
							<div class="x3">
								<div class="form-group">
									<div class="label"><label for="s_domain">域名</label></div>
									<div class="field">
										<input id="s_domain" class="input" name="s_domain" type="text" size="60" value="<?php echo $row['s_domain'];?>" data-validate="required:必须填写,url:请填写合法的域名" />
										<div class="input-note">示例：http://www.domain.com</div>
									</div>
								</div>
							</div>
							<div class="x3<?php echo ($system_closem) ? ' dn' : '' ;?>">
								<div class="form-group">
									<div class="label"><label for="s_mdomain">手机域名</label></div>
									<div class="field">
										<input id="s_mdomain" class="input" name="s_mdomain" type="text" size="60" value="<?php echo $row['s_mdomain'];?>" data-validate="url:请填写合法的域名" />
										<div class="input-note">示例：http://m.domain.com</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_seoname">优化标题</label></div>
									<div class="field">
										<input id="s_seoname" class="input" name="s_seoname" type="text" size="60" value="<?php echo $row['s_seoname'];?>" />
										<div class="input-note">请填写优化标题</div>
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_keywords">关键字</label></div>
									<div class="field">
										<input id="s_keywords" class="input" name="s_keywords" type="text" size="60" value="<?php echo $row['s_keywords'];?>" />
										<div class="input-note">请填写关键字</div>
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_description">关键描述</label></div>
									<div class="field">
										<input id="s_description" class="input" name="s_description" type="text" size="60" value="<?php echo $row['s_description'];?>" />
										<div class="input-note">请填写关键描述</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="xx24">
								<div class="form-group">
									<div class="label"><label for="s_phone">电话</label></div>
									<div class="field">
										<input id="s_phone" class="input" name="s_phone" type="text" size="60" value="<?php echo $row['s_phone'];?>" />
										<div class="input-note">请填写您的电话</div>
									</div>
								</div>
							</div>
							<div class="xx24">
								<div class="form-group">
									<div class="label"><label for="s_qq">QQ</label></div>
									<div class="field">
										<input id="s_qq" class="input" name="s_qq" type="text" size="60" value="<?php echo $row['s_qq'];?>" />
										<div class="input-note">请填写您的QQ</div>
									</div>
								</div>
							</div>
							<div class="xx24">
								<div class="form-group">
									<div class="label"><label for="s_logo">Logo</label> <span class="badge bg-dot cp" id="logo">上传</span></div>
									<div class="field">
										<input id="s_logo" class="input" name="s_logo" type="text" size="40" value="<?php echo $system_logo;?>" />
										<div class="input-note">请上传Logo</div>
									</div>
								</div>
							</div>
							<div class="xx24<?php echo ($system_closem) ? ' dn' : '' ;?>">
								<div class="form-group">
									<div class="label"><label for="s_mlogo">手机Logo</label> <span class="badge bg-dot cp" id="mlogo">上传</span></div>
									<div class="field">
										<input id="s_mlogo" class="input" name="s_mlogo" type="text" size="40" value="<?php echo $system_mlogo;?>" />
										<div class="input-note">请上传手机Logo</div>
									</div>
								</div>
							</div>
							<div class="xx24">
								<div class="form-group">
									<div class="label"><label for="s_qrcode">二维码</label> <span class="badge bg-dot cp" id="qrcode">上传</span></div>
									<div class="field">
										<input id="s_qrcode" class="input" name="s_qrcode" type="text" size="40" value="<?php echo $row['s_qrcode'];?>" />
										<div class="input-note">请上传您的二维码</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="xx16">
								<div class="form-group">
									<div class="label"><label for="s_slideshow">幻灯高度</label></div>
									<div class="field">
										<input id="s_slideshow" class="input" name="s_slideshow" type="text" maxlength="255" size="60" value="<?php echo $row['s_slideshow'];?>" data-validate="required:必须填写,plusinteger:必须为正整数"/>
										<div class="input-note">请填写幻灯高度</div>
									</div>
								</div>
							</div>
							<div class="xx16">
								<div class="form-group">
									<div class="label"><label for="s_square">缩略图正方形</label></div>
									<div class="field">
										<select id="s_square" class="input" name="s_square">
											<option value="1" <?php echo ($row['s_square'] == 1) ? ' selected="selected"' : '' ; ?>>是</option>
											<option value="0" <?php echo ($row['s_square'] == 0) ? ' selected="selected"' : '' ; ?>>否</option>
										</select>
										<div class="input-note">缩略图正方形</div>
									</div>
								</div>
							</div>
							<div class="xx22">
								<div class="form-group">
									<div class="label"><label for="s_p1">详情参数1</label></div>
									<div class="field">
										<input id="s_p1" class="input" name="s_p1" type="text" size="60" value="<?php echo $row['s_p1'];?>" />
									</div>
								</div>
							</div>
							<div class="xx22">
								<div class="form-group">
									<div class="label"><label for="s_p2">详情参数2</label></div>
									<div class="field">
										<input id="s_p2" class="input" name="s_p2" type="text" size="60" value="<?php echo $row['s_p2'];?>" />
									</div>
								</div>
							</div>
							<div class="xx22">
								<div class="form-group">
									<div class="label"><label for="s_p3">详情参数3</label></div>
									<div class="field">
										<input id="s_p3" class="input" name="s_p3" type="text" size="60" value="<?php echo $row['s_p3'];?>" />
									</div>
								</div>
							</div>
							<div class="xx22">
								<div class="form-group">
									<div class="label"><label for="s_p4">详情参数4</label></div>
									<div class="field">
										<input id="s_p4" class="input" name="s_p4" type="text" size="60" value="<?php echo $row['s_p4'];?>" />
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x12">
								<div class="form-group">
									<div class="label"><label for="s_hotkeywords">热门关键词</label></div>
									<div class="field">
										<input id="s_hotkeywords" class="input" name="s_hotkeywords" type="text" size="60" value="<?php echo $row['s_hotkeywords'];?>" />
										<div class="input-note">每个词之间用“|”分割</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x12">
								<div class="form-group">
									<div class="label"><label for="s_copyright">版权信息</label></div>
									<div class="field">
										<textarea id="s_copyright" class="input" name="s_copyright" /><?php echo htmlspecialchars($row['s_copyright'])?></textarea>
										<div class="input-note">请填写版权信息</div>
									</div>
								</div>
							</div>
							<div class="x12<?php echo ($system_closem) ? ' dn' : '' ;?>">
								<div class="form-group">
									<div class="label"><label for="s_mcopyright">手机版权信息</label></div>
									<div class="field">
										<textarea id="s_mcopyright" class="input" name="s_mcopyright" /><?php echo htmlspecialchars($row['s_mcopyright'])?></textarea>
										<div class="input-note">请填写手机版权信息</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_feedback">留言控制</label></div>
									<div class="field">
										<label class="btn"><input id="s_feedback" name="s_feedback" type="radio" value="0" <?php echo ( $row['s_feedback'] == 0 ) ? 'checked="checked"' : '' ; ?>/>禁止留言</label>
										<label class="btn"><input name="s_feedback" type="radio" value="1" <?php echo ( $row['s_feedback'] == 1 ) ? 'checked="checked"' : '' ; ?>/>需要审核</label>
										<label class="btn"><input name="s_feedback" type="radio" value="2" <?php echo ( $row['s_feedback'] == 2 ) ? 'checked="checked"' : '' ; ?>/>不需审核</label>
										<div class="input-note">选择留言模式</div>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot" name="save" type="submit" value="保存设置" />
							</div>
						</div>
					</form>
					<?php
						}
					?>
				</div>

			</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?>
</body>
</html>