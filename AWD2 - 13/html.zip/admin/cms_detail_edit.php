<?php
include('./cms_inc.php');
include('./cms_check.php');
if ( isset($_POST['save']) ) {
	$_data['d_name'] = $_POST['d_name'];
	$_data['d_picture'] = $_POST['d_picture'];
	$_data['d_parent'] = $_POST['d_parent'];
	$_data['d_rec'] = $_POST['d_rec'];
	$_data['d_hot'] = $_POST['d_hot'];
	$_data['d_cov'] = $_POST['d_cov'];
	$_data['d_content'] = $_POST['d_content'];
	$_data['d_scontent'] = ($_POST['d_scontent'] == '') ? cut_str(clear_html($_POST['d_content']),100) : $_POST['d_scontent'];
	$_data['d_mcontent'] = $_POST['d_mcontent'];
	$_data['d_slideshow'] = $_POST['d_slideshow'];
	$_data['d_keywords'] = $_POST['d_keywords'];
	$_data['d_description'] = $_POST['d_description'];
	$_data['d_seoname'] = $_POST['d_seoname'];
	$_data['d_file'] = $_POST['d_file'];
	$_data['d_p1'] = $_POST['d_p1'];
	$_data['d_p2'] = $_POST['d_p2'];
	$_data['d_p3'] = $_POST['d_p3'];
	$_data['d_p4'] = $_POST['d_p4'];
	$_data['d_link'] = $_POST['d_link'];
	$_data['d_order'] = $_POST['d_order'];
	$_data['d_author'] = $_POST['d_author'];
	$_data['d_source'] = $_POST['d_source'];
	$_data['d_date'] = strtotime($_POST['d_date']);
	$sql = 'update cms_detail set '.arrtoupdate($_data).' where id = '.$_GET['id'].'';
	if (sql_query($sql)) {
		alert_href('详情修改成功!', url_decode($_GET['url']));
	} else {
		alert_back('error');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	K.create('#d_content');
	K.create('#d_mcontent');
	var editor = K.editor();
	K('#picture').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#d_picture').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#d_picture').val(url);
				editor.hideDialog();
				}
			});
		});
	});
	K('#slideshow').click(function() {
		editor.loadPlugin('multiimage', function() {
			editor.plugin.multiImageDialog({
				clickFn : function(urlList) {
					var tem_val = '';
					var tem_s = '';
					K.each(urlList, function(i, data) {
						tem_val = tem_val + tem_s + data.url;
						tem_s = '|';
					});
					K('#d_slideshow').val(tem_val);
					editor.hideDialog();
				}
			});
		});
	});
	K('#file').click(function() {
		editor.loadPlugin('insertfile', function() {
			editor.plugin.fileDialog({
				fileUrl : K('#d_file').val(),
				clickFn : function(url, title) {
					K('#d_file').val(url);
					editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
			<?php include('./cms_inc_left.php') ?>
			<div id="right">
				<div class="hd-1">修改详情</div>
				<div class="bd-1">
					<?php
					$result = sql_query('select * from cms_detail where id = '.$_GET['id'].'');
					if ($row = sql_fetch_array($result)){
					?>
					<form method="post">
						<div class="l20">
							<div class="form-group x4">
								<div class="label"><label for="d_parent">所属频道 <span class="badge bg-dot">必选</span></label></div>
								<div class="field">
									<select id="d_parent" class="input" name="d_parent">
										<?php echo channel_select_list(0,0,$row['d_parent'],0); ?>
									</select>
									<div class="input-note">请选择详情属于哪个频道</div>
								</div>
							</div>
							<div class="form-group x5">
								<div class="label"><label for="d_name">详情名称 <span class="badge bg-dot">必填</span></label></div>
								<div class="field">
									<input id="d_name" class="input" name="d_name" type="text" size="60" data-validate="required:请输入详情名称" value="<?php echo $row['d_name'];?>" />
									<div class="input-note">请输入详情名称</div>
								</div>
							</div>
							<div class="form-group x3">
								<div class="label"><label for="d_picture">缩略图</label> <span class="badge bg-green cp" id="picture">上传</span></div>
								<div class="field">
									<input id="d_picture" class="input" name="d_picture" type="text" size="60" value="<?php echo $row['d_picture'];?>" />
									<div class="input-note">图片列表显示的缩略图</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="form-group xx18">
								<div class="label"><label for="d_rec">推荐</label></div>
								<div class="field">
									<label class="btn"><input id="d_rec" name="d_rec" type="radio" value="0" <?php echo ($row['d_rec'] == 0 ? 'checked="checked"' : '')?>/>否</label>
									<label class="btn"><input name="d_rec" type="radio" value="1" <?php echo ($row['d_rec'] == 1 ? 'checked="checked"' : '')?>/>是</label>
									<div class="input-note">选择是否推荐</div>
								</div>
							</div>
							<div class="form-group xx18">
								<div class="label"><label for="d_hot">热门</label></div>
								<div class="field">
									<label class="btn"><input id="d_hot" name="d_hot" type="radio" value="0" <?php echo ($row['d_hot'] == 0 ? 'checked="checked"' : '')?>/>否</label>
									<label class="btn"><input name="d_hot" type="radio" value="1" <?php echo ($row['d_hot'] == 1 ? 'checked="checked"' : '')?>/>是</label>
									<div class="input-note">选择是否热门</div>
								</div>
							</div>
							<div class="form-group xx18">
								<div class="label"><label for="d_cov">封面</label></div>
								<div class="field">
									<label class="btn"><input id="d_cov" name="d_cov" type="radio" value="0" <?php echo ($row['d_cov'] == 0 ? 'checked="checked"' : '')?>/>否</label>
									<label class="btn"><input name="d_cov" type="radio" value="1" <?php echo ($row['d_cov'] == 1 ? 'checked="checked"' : '')?>/>是</label>
									<div class="input-note">选择是否封面</div>
								</div>
							</div>
							<div class="form-group xx15">
								<div class="label"><label for="d_order">排序 <span class="badge bg-dot">必填</span></label></div>
								<div class="field">
									<input id="d_order" class="input" name="d_order" type="text" size="60" data-validate="required:必填,plusinteger:请输入排序数字" value="<?php echo $row['d_order'];?>" />
									<div class="input-note">请输入排序数字</div>
								</div>
							</div>
							<div class="form-group xx15">
								<div class="label"><label for="d_author">作者</label></div>
								<div class="field">
									<input id="d_author" class="input" name="d_author" type="text" size="12" value="<?php echo $row['d_author'];?>" />
									<div class="input-note">请输入作者</div>
								</div>
							</div>
							<div class="form-group xx15">
								<div class="label"><label for="d_source">来源</label></div>
								<div class="field">
									<input id="d_source" class="input" name="d_source" type="text" size="12" value="<?php echo $row['d_source'];?>" />
									<div class="input-note">请输入来源</div>
								</div>
							</div>
							<div class="form-group xx21">
								<div class="label"><label for="d_date">发布日期</label></div>
								<div class="field">
									<input id="d_date" class="input" name="d_date" type="text" maxlength="255" size="60" readonly="readonly" value="<?php echo date('Y-m-d H:i:s',$row['d_date']);?>" data-validate="required:必须选择日期" onclick="laydate({istime: true, format: 'YYYY-MM-DD hh:mm:ss'})" />
									<div class="input-note">请选择日期</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="form-group x12">
								<div class="label"><label for="d_content">详细内容</label></div>
								<div class="field">
									<textarea id="d_content" class="input" name="d_content" /><?php echo htmlspecialchars($row['d_content']);?></textarea>
									<div class="input-note">支持图文混排等</div>
								</div>
							</div>
							<div class="form-group x12<?php echo ($system_closem) ? ' dn' : '' ;?>">
								<div class="label"><label for="d_mcontent">手机详细内容</label></div>
								<div class="field">
									<textarea id="d_mcontent" class="input" name="d_mcontent" /><?php echo htmlspecialchars($row['d_mcontent']);?></textarea>
									<div class="input-note">留空自动识别为详细内容</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="form-group x12">
								<div class="label"><label for="d_scontent">简短内容</label></div>
								<div class="field">
									<textarea id="d_scontent" class="input" name="d_scontent" row="5" /><?php echo $row['d_scontent'];?></textarea>
									<div class="input-note">一般用于内容摘要，留空后自动截取部分详细内容。</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="form-group x12">
								<div class="label"><label for="d_slideshow">组图</label> <span class="badge bg-green cp" id="slideshow">上传</span></div>
								<div class="field">
									<textarea id="d_slideshow" class="input" name="d_slideshow" row="5" /><?php echo $row['d_slideshow'];?></textarea>
									<div class="input-note">图片地址用"|"分割</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="form-group x4">
								<div class="label"><label for="d_keywords">关键字</label></div>
								<div class="field">
									<input id="d_keywords" class="input" name="d_keywords" type="text" size="60" value="<?php echo $row['d_keywords'];?>" />
									<div class="input-note">请输入关键字</div>
								</div>
							</div>
							<div class="form-group x4">
								<div class="label"><label for="d_description">关键描述</label></div>
								<div class="field">
									<input id="d_description" class="input" name="d_description" type="text" size="60" value="<?php echo $row['d_description'];?>" />
									<div class="input-note">请输入关键描述</div>
								</div>
							</div>
							<div class="form-group x4">
								<div class="label"><label for="d_seoname">优化标题</label></div>
								<div class="field">
									<input id="d_seoname" class="input" name="d_seoname" type="text" size="60" value="<?php echo $row['d_seoname'];?>" />
									<div class="input-note">请输入优化标题</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="form-group x6">
								<div class="label"><label for="d_file">附件下载</label> <span class="badge bg-green cp" id="file">上传</span></div>
								<div class="field">
									<input id="d_file" class="input" name="d_file" type="text" size="30" value="<?php echo $row['d_file'];?>" />
									<div class="input-note">请上传或填写附件地址</div>
								</div>
							</div>
							<div class="form-group x6">
								<div class="label"><label for="d_link">链接</label></div>
								<div class="field">
									<input id="d_link" class="input" name="d_link" type="text" size="60" data-validate="url:请填写合法的URL地址" value="<?php echo $row['d_link'];?>" />
									<div class="input-note">外部用http://开头</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x3">
								<div class="form-group">
									<div class="label"><label for="d_p1"><?php echo $system_p1;?></label></div>
									<div class="field">
										<input id="d_p1" class="input" name="d_p1" type="text" size="60" value="<?php echo $row['d_p1'];?>" />
									</div>
								</div>
							</div>
							<div class="x3">
								<div class="form-group">
									<div class="label"><label for="d_p2"><?php echo $system_p2;?></label></div>
									<div class="field">
										<input id="d_p2" class="input" name="d_p2" type="text" size="60" value="<?php echo $row['d_p2'];?>" />
									</div>
								</div>
							</div>
							<div class="x3">
								<div class="form-group">
									<div class="label"><label for="d_p3"><?php echo $system_p3;?></label></div>
									<div class="field">
										<input id="d_p3" class="input" name="d_p3" type="text" size="60" value="<?php echo $row['d_p3'];?>" />
									</div>
								</div>
							</div>
							<div class="x3">
								<div class="form-group">
									<div class="label"><label for="d_p4"><?php echo $system_p4;?></label></div>
									<div class="field">
										<input id="d_p4" class="input" name="d_p4" type="text" size="60" value="<?php echo $row['d_p4'];?>" />
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="form-group x12">
								<div class="label"><label></label></div>
								<div class="field">
									<input id="save" class="btn bg-dot" name="save" type="submit" value="修改详情" />
								</div>
							</div>
						</div>
					</form>
					<?php
					}
					?>
				</div>
			</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?>
</body>
</html>