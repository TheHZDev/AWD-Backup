<?php
include('./cms_inc.php');
include('./cms_check.php');
if ( isset($_POST['save']) ) {
	null_back($_POST['s_picture'],'请输入或上传图片');
	non_numeric_back($_POST['s_order'],'请输入排序数字');
	$_data['s_name'] = $_POST['s_name'];
	$_data['s_parent'] = $_POST['s_parent'];
	$_data['s_picture'] = $_POST['s_picture'];
	$_data['s_url'] = $_POST['s_url'];
	$_data['s_order'] = $_POST['s_order'];
	$_data['s_content'] = $_POST['s_content'];
	$str = arrtoinsert($_data);
	$sql = 'insert into cms_slideshow ('.$str[0].') values ('.$str[1].')';
	if (sql_query($sql)) {
		$order = sql_insert_id();
		if ( $_POST['s_order'] == 0 ) {
			sql_query('update cms_slideshow set s_order = '.$order.' where id = '.$order);
		}
		alert_href('幻灯添加成功!','cms_slideshow.php');
	} else {
		alert_back('添加失败!');
	}
}
if(isset($_GET['del'])){
	$sql = 'delete from cms_slideshow where id = '.$_GET['del'].'';
	if(sql_query($sql)){
		alert_href('删除成功!','cms_slideshow.php');
	}else{
		alert_back('删除失败！');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('./cms_inc_head.php') ?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	var editor = K.editor();
	K('#picture').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_picture').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_picture').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?php include('./cms_inc_header.php') ?>
<div id="content">
	<div class="container oh">
			<?php include('./cms_inc_left.php') ?>
			<div id="right">
				<div class="hd-1">添加幻灯</div>
				<div class="bd-1">
					<form method="post">
						<div class="form-group">
							<div class="label"><label for="s_name">名称</label></div>
							<div class="field">
								<input id="s_name" class="input" name="s_name" type="text" size="60" value="" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_parent">属于</label></div>
							<div class="field">
								<select id="s_parent" class="input" name="s_parent">
									<option value="1">电脑端</option>
									<?php
									if (!$system_closem) {
									?>
									<option value="2">手机端</option>
									<?php
									}
									?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_picture">图片 <span class="badge bg-dot">必填</span></label> <span class="badge bg-green cp" id="picture">上传</span></div>
							<div class="field">
								<input id="s_picture" class="input" name="s_picture" type="text" size="60" data-validate="required:请输入或上传图片" value="" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_url">链接</label></div>
							<div class="field">
								<input id="s_url" class="input" name="s_url" type="text" size="60" value="" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_order">排序 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="s_order" class="input" name="s_order" type="text" size="60" data-validate="required:必填,plusinteger:请输入排序数字" value="0" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_content">内容</label></div>
							<div class="field">
								<textarea id="s_content" class="input" name="s_content" row="5" /></textarea>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot" name="save" type="submit" value="添加幻灯" />
							</div>
						</div>
					</form>
				</div>

				<div class="hd-1">幻灯管理</div>
				<div class="bd-1">
					<table class="table table-bordered">
						<tr>
							<th>排序</th>
							<th>图片</th>
							<th>属于</th>
							<th>名称</th>
							<th>链接地址</th>
							<th>操作</th>
						</tr>
						<?php
						$result = sql_query('select * from cms_slideshow order by s_order asc , id asc');
						if ($system_closem) {
							$result = sql_query('select * from cms_slideshow where s_parent = 1 order by s_order asc , id asc');
						}
						while($row = sql_fetch_array($result)){
						?>
						<tr class="ac">
							<td><?php echo $row['s_order']?></td>
							<td><a href="<?php echo $row['s_picture']?>" target="_blank">点击查看</a></td>
							<td>
								<?php
								switch ($row['s_parent']){
									case 1:
										echo '电脑端';
										break;
									case 2:
										echo '手机端';
										break;
								}
								?>
							</td>
							<td><?php echo $row['s_name']?></td>
							<td><?php echo $row['s_url']?></td>
							<td><a class="btn bg-sub" href="cms_slideshow_edit.php?id=<?php echo $row['id']?>"><span class="icon-edit"> 修改</span></a> <a class="btn bg-dot" href="cms_slideshow.php?del=<?php echo $row['id']?>" onclick="return confirm('确认要删除吗？')"><span class="icon-times"> 删除</span></a></td>
						</tr>
						<?php
						}
						?>
					</table>
				</div>
			</div>
	</div>
</div>
<?php include('./cms_inc_footer.php') ?></body>
</html>