<?php
require_once('../system/conn.php');
require_once('../system/library.php');
require_once('../system/config.php');
require_once('../system/function.php');
?>