<?php
if(!isset($_COOKIE['admin_name'])){
	alert_href('请重新登录','cms_login.php');
} else {
	$result = sql_query('select * from cms_admin where a_name = "'.$_COOKIE['admin_name'].'" and a_password = "'.$_COOKIE['admin_password'].'"');
	if (!$row = sql_fetch_array($result)) {
		alert_href('请重新登录','cms_login.php');
	}
};
?>