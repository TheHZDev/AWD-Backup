<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title><?php echo $system_name.'-'.$system_seoname?></title>
<meta name="keywords" content="<?php echo $system_keywords;?>" />
<meta name="description" content="<?php echo $system_description;?>" />
<?php include($dir.$t_path.'inc_head.php');?>
<script type="text/javascript">
$(function(){
	$('.home a').addClass('current');
});
</script>
</head>
<body>
<?php include($dir.$t_path.'inc_header.php');?>
<div id="slideshow" class="oh">
	<div class="bd">
		<ul>
		<?php
		$result = sql_query('select * from cms_slideshow where s_parent = 1 order by s_order asc , id asc');
		while ($row = sql_fetch_array($result)){
			echo '
			<li style="background: url('.$row['s_picture'].') center no-repeat;">
				<div class="url">
					<a style="height:'.$system_slideshow.'px;" href="'.$row['s_url'].'" title="'.$row['s_name'].'"></a>
				</div>
			</li>
			';
		}
		?>
		</ul>
	</div>
	<div class="hd">
		<ul>
		</ul>
	</div>
	<div class="next hide" style="height: <?php echo $system_slideshow?>px;"></div> <div class="prev hide" style="height: <?php echo $system_slideshow?>px;"></div>
</div>
<div class="container">
	<div id="search">
		热门关键词：
		<?php
		$arr_key = explode('|',$system_hotkeywords);
		foreach( $arr_key as $key => $value ){
			echo '<a class="badge" href="search.php?key='.$value.'">'.$value.'</a> ';
		}
		?>
		<form method="get" action="search.php">
			<input id="search_text" type="text" name="key" />
			<input id="search_btn" type="submit" value="搜索" />
		</form>
	</div>
</div>
<div id="index-1">
	<div class="container">
		<?php
		$result = sql_query('select * from cms_channel where id = 1');
		if ($row = sql_fetch_array($result)) {
		?>
		<div class="name"><?php echo $row['c_name'];?> <?php echo $row['c_aname'];?></div>
		<div class="seoname"><span><?php echo $row['c_seoname'];?></span></div>
		<?php echo $row['c_scontent'];?>
		<?php } ?>
	</div>
</div>
<div id="index-2">
	<div class="container">
		<?php
		$results = sql_query('select * from cms_channel where id = 3');
		if ($rows = sql_fetch_array($results)) {
		?>
		<div class="name"><?php echo $rows['c_name'];?> <?php echo $rows['c_aname'];?></div>
		<div class="seoname"><span><?php echo $rows['c_seoname'];?></span></div>
		<?php } ?>
		<div class="l20 products_list">
			<?php
			$result = sql_query('select id,d_name,d_picture,d_scontent,d_date from cms_detail where d_parent in ('.$rows['c_sub'].') order by d_order desc , id desc limit 0, 5');
			while($row = sql_fetch_array($result)){
			?>
			<div class="xx24">
				<div class="wrap mb20">
					<div class="square_img"><a href="<?php echo d_url($row['id'])?>" target="_blank"><img src="<?php echo $row['d_picture'];?>" title="<?php echo $row['d_name'];?>" alt="<?php echo $row['d_name'];?>"/></a></div>
					<div class="title cut"><a href="<?php echo d_url($row['id'])?>" target="_blank" title="<?php echo $row['d_name'];?>"><?php echo $row['d_name'];?></a></div>
				</div>
			</div>
			<?php
			}
			?>
		</div>
	</div>
</div>
<div id="index-3">
	<div class="container">
		<div class="l20">
			<div class="x8">
				<?php
				$results = sql_query('select * from cms_channel where id = 2');
				if ($rows = sql_fetch_array($results)) {
				?>
				<div class="index_hd">
					<div class="name_wrap">
						<div><?php echo $rows['c_name'];?></div>
						<div class="aname"><?php echo $rows['c_aname'];?></div>
						<div class="more"><a href="<?php echo c_url($rows['id']);?>">MORE+</a></div>
					</div>
				</div>
				<ul class="list-group">
					<?php
					$result = sql_query('select id,d_name,d_picture,d_scontent,d_date from cms_detail where d_parent in ('.$rows['c_sub'].') order by d_order desc , id desc limit 0, 10');
					while($row = sql_fetch_array($result)){
						echo '<li class="cut"><span class="fr badge">'.date('m-d',$row['d_date']).'</span><a href="'.d_url($row['id']).'" title="'.$row['d_name'].'">'.$row['d_name'].'</a></li>';
					}
					?>
				</ul>
				<?php } ?>
			</div>
			<div class="x4">
				<?php
				$result = sql_query('select * from cms_channel where id = 6');
				if ($row = sql_fetch_array($result)) {
				?>
				<div class="index_hd">
					<div class="name_wrap">
						<div><?php echo $row['c_name'];?></div>
						<div class="aname"><?php echo $row['c_aname'];?></div>
						<div class="more"><a href="<?php echo c_url($row['id']);?>">MORE+</a></div>
					</div>
					<?php echo $row['c_scontent'];?>
				</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
<div id="index-link">
	<div class="container">
		<div class="bd1">
			<div class="link_text">
				<div class="l10">
					<?php
					$result = sql_query('select * from cms_link where l_picture = "" order by l_order asc , id asc');
					while ($row = sql_fetch_array($result)){
						echo '<div class="a8"><a href="'.$row['l_url'].'" target="_blank">'.$row['l_name'].'</a></div>';
					}
					?>
				</div>
			</div>
			<div class="link_picture">
				<div class="l10">
					<?php
					$result = sql_query('select * from cms_link where l_picture <> "" order by l_order asc , id asc');
					while ($row = sql_fetch_array($result)){
						echo '<div class="a8"><a href="'.$row['l_url'].'" target="_blank"><img src="'.$row['l_picture'].'" alt="'.$row['l_name'].'" title="'.$row['l_name'].'"></a></div>';
					}
					?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include($dir.$t_path.'inc_footer.php');?>
</body>
</html>
