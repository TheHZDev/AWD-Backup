<div id="footer">

	<div class="container">
		<div class="ac mb10">
			<a href="<?php echo $s_path;?>/feedback.php"><span class="icon-user"> 留言反馈</span></a>
			<a href="<?php echo $s_path;?>/sitemap.php"><span class="icon-sitemap"> 网站地图</span></a>
			<a href="javascript:void(0)"><span class="icon-home win-homepage"> 设为首页</span></a>
			<a href="javascript:void(0)"><span class="icon-star win-favorite"> 收入加藏</span></a>
		</div>
		<div class="line">
			<?php echo $system_copyright?>
		</div>
	</div>
</div>
<div id="float">
	<div class="wrap custom">
		<span class="icon icon-arrow-circle-o-left"></span>
		<div class="content"><?php echo get_chip(1);?></div>
	</div>
	<div class="wrap qrcode">
		<span class="icon icon-weixin "></span>
		<div class="content">
			<img src="<?php echo $system_qrcode;?>" />
		</div>
	</div>
	<div class="wrap phone">
		<span class="icon icon-phone"></span>
		<div class="content"><?php echo $system_phone;?></div>
	</div>
	<div class="wrap qq">
		<span class="icon icon-qq "></span>
		<div class="content"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $system_qq;?>&site=qq&menu=yes"><?php echo $system_qq;?></a></div>
	</div>
	<div class="wrap gotop">
		<span class="icon icon-chevron-up "></span>
	</div>
</div>
<?php
if ($system_square == 1) {
?>
<script type="text/javascript">
$(function(){
	$('.square_img img').jqthumb({
		width:$('.square_img').width(),
		height:$('.square_img').width()
	});
	$('.square_img2 img').jqthumb({
		width:$('.square_img2').width(),
		height:$('.square_img2').width()
	});
	$('.square_img3 img').jqthumb({
		width:$('.square_img3').width(),
		height:$('.square_img3').width()
	});
	$('.square_img4 img').jqthumb({
		width:$('.square_img4').width(),
		height:$('.square_img4').width()
	});
});
</script>
<?php
}
?>