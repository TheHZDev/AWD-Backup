﻿$(function(){
	//导航
	$('#navigation').slide({
		type: "menu",
		titCell: '.main',
		targetCell: '.sub',
		effect: 'slideDown',
		delayTime: 300,
		triggerTime: 100
	});
	//幻灯
	$('#slideshow').slide({
		titCell: ".hd ul",
		mainCell: ".bd ul",
		effect: "fade",
		delayTime:1500,
		interTime: 5000,
		autoPlay: true,
		autoPage: true,
		trigger: "click"
	});
	$('#slideshow').mouseover(function(){
		$(this).find('.next').fadeIn();
		$(this).find('.prev').fadeIn();
	}).mouseleave(function(){
		$(this).find('.next').hide();
		$(this).find('.prev').hide();
	})
	$('#search_btn').click(function(){
		if ($('#search_text').val() == ''){
			alert('请输入要查找的关键字');
			$('#search_text').focus();
			return false;
		};
	});
	$('.channel_plist').slide({
		titCell: '.hd',
		targetCell: '.bd',
		defaultPlay: false,
		effect: 'slideDown'
	});
	$('#detail_content table').addClass('table table-bordered');
	//在线客服
	var offsettop = $('#float').offset().top;
	$(window).scroll(function() {
		$('#float').animate({
			top: offsettop + $(window).scrollTop() + "px"
		}, {
			duration: 600,
			queue: false
		});
	});
	$('#float').slide({
		type: "menu",
		titCell: '.wrap',
		targetCell: '.content',
		effect: 'fade',
		delayTime: 300,
		triggerTime: 100
	});

	$('.gotop').click(function() {
		$('html,body').animate({
			scrollTop: '0px'
		}, 100);
	});
});
