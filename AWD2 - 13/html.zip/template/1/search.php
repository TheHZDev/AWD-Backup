<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>搜索结果</title>
<?php include($dir.$t_path.'inc_head.php');?>
</head>
<body>
<?php include($dir.$t_path.'inc_header.php');?>
<div id="content">
	<div class="container">
		<div id="current_location">当前位置：<a href="index.php">首页</a> > 搜索结果</div>
		<ul class="list-group">
			<?php
			$sql = 'select id,d_name,d_picture,d_scontent,d_date from cms_detail where d_name like "%'.$key.'%" order by d_order desc , id desc';
			$pager = page_handle('page',20,sql_num_rows(sql_query($sql)));
			$result = sql_query($sql.' limit '.$pager[0].','.$pager[1].'');
			while($row = sql_fetch_array($result)){
			?>
			<li><span class="fr badge"><?php echo date('Y-m-d',$row['d_date']) ?> </span><a href="<?php echo d_url($row['id'])?>" target="_blank" title="<?php echo $row['d_name'];?>"><?php echo cut_str($row['d_name'],50);?></a></li>
			<?php
			}
			?>
		</ul>
		<div class="page_show"><?php echo page_show($pager[2],$pager[3],$pager[4],2);?> </div>
	</div>
</div>
<?php include($dir.$t_path.'inc_footer.php');?>
</body>
</html>
