<?php
//Mysql数据库信息
if(!defined('PCFINAL')) exit('Request Error!');
define('DATA_HOST', 'localhost');
define('DATA_USERNAME', 'cms');
define('DATA_PASSWORD', '7aed78676bf27528');
define('DATA_NAME', 'cms');
?>