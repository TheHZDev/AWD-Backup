<?php /* Smarty version 2.6.28, created on 2022-01-08 13:19:44
         compiled from Manage/addManage.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link type="text/css" rel="stylesheet" href="template/admin/css/style.css" />
<script type="text/javascript" src="template/admin/js/jquery.js"></script>
<script type="text/javascript" src="template/admin/js/main.js"></script>

</head>

<body>
<div class="dqnav">
<ul>
	<li>当前位置：</li>
	<li><a href="?m=index&a=main">后台首页</a></li>
	<li><span>&gt;</span></li>
	<li><a href="?m=manage&a=index">管理员列表</a></li>
	<li><span>&gt;</span></li>
	<li>增加管理员</li>
</ul>
</div>
<div class="mainBox">
    <div class="mainForm" id="mainForm">
    	<table cellpadding="0" border="0" cellspacing="0">
        	<form action="?m=manage&a=add" method="post">
        	<tr>
            	<td width="10%" align="right">用户名：</td>
            	<td width="90%"><input type="text" class="inputText" name="name" id="name" /> <span class="error"></span></td>
            </tr>
        	<tr>
            	<td width="10%" align="right">密码：</td>
            	<td width="90%"><input type="password" class="inputText" name="pwd" id="pwd" /> <span class="error"></span></td>
            </tr>
        	<tr>
            	<td width="10%" align="right">确认密码：</td>
            	<td width="90%"><input type="password" class="inputText" name="pwd2" id="pwd2" /> <span class="error"></span></td>
            </tr>
            <tr>
            	<td>&nbsp;</td>
            	<td><input type="submit" value="提交" class="inputSub" name="addManage" id="addManage" /></td>
            </tr>
            </form>
        </table>
    </div>
</div>
</body>
</html>