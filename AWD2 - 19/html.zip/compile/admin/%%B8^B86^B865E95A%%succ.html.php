<?php /* Smarty version 2.6.28, created on 2022-01-08 13:19:07
         compiled from succ.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>lmxcms网站管理系统首页 - 免费开源无授权</title>
<link type="text/css" rel="stylesheet" href="template/admin/css/style.css" />
<script type="text/javascript" src="template/admin/js/jquery.js"></script>
<script type="text/javascript" src="template/admin/js/main.js"></script>
<script type="text/javascript">
	setTimeout("redirect('<?php echo $this->_tpl_vars['url']; ?>
')",<?php echo $this->_tpl_vars['time']; ?>
);
</script>
</head>
<body class="errorBody">
    <div class='succ'>
        <h1><a href="<?php echo $this->_tpl_vars['url']; ?>
" title='点击返回'><span><?php echo $this->_tpl_vars['str']; ?>
</span></a></h1>
    </div>
</body>
</html>