<?php /* Smarty version 2.6.28, created on 2022-01-08 13:19:11
         compiled from footer.html */ ?>
<div class="footerBox width">
	<div class="footer">
        <p>我的网站 版权所有 2014 湘ICP备8888888<br />Powered by <a href="http://www.lmxcms.com">lmxcms</a> <?php echo $this->_tpl_vars['version']; ?>
 ©2014 <a href="http://www.lmxcms.com">www.lmxcms.com</a></p>
    </div>
</div>