<?php 
 if(!defined('LMXCMS')){exit();} 
 //本文件为缓存文件 无需手动更改
 return array (
  1 => 
  array (
    'mid' => '1',
    'mname' => '产品模型',
    'tab' => 'product_data',
    'content' => '',
  ),
  2 => 
  array (
    'mid' => '2',
    'mname' => '新闻模型',
    'tab' => 'news_data',
    'content' => '',
  ),
) 
?>