<?php 
//lmxcms安装程序控制器
class InstallAction extends Action{
    protected $url;
    public function __construct() {
        if(file_exists('install_ok.txt')){
            rewrite::js_back('lmxcms已经安装过了，如果要重新安装请删除根目录下install/install_ok.txt文件即可。');
        }
        $this->url = $this->siteurl();
        parent::__construct();
        //smarty配置
        $this->smarty->template_dir=ROOT_PATH.'install/tem/'; //模板路径
        $this->smarty->compile_dir=ROOT_PATH.'install/compile/'; //编译文件路径
        $this->smarty->cache_dir=ROOT_PATH.'install/cache/'; //缓存目录
        $this->smarty->assign('newurl',$this->url);
    }
    
    //取得网站地址
    protected function siteurl(){
        $url=str_replace('install/index.php','',$_SERVER['PHP_SELF']);
	$url=str_replace('install/','',$url);
	$url=str_replace('install','',$url);
	return $url;
    }
    
}
?>