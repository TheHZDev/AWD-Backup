<?php 
/**
 *  【梦想cms】 http://www.lmxcms.com
 * 
 *   用户自定义函数文件
 * 
 *   函数名建议以 usr_ 开头，避免与系统函数名冲突
 */

function usr_xxxx(){
    
}
?>