<?php 
/**
 *  【梦想cms】 http://www.lmxcms.com
 * 
 *   前台入口文件
 */
define('LMXCMS',TRUE);
define('RUN_TYPE','index');
require dirname(__FILE__).'/inc/config.inc.php';
require dirname(__FILE__).'/inc/run.inc.php';
?>