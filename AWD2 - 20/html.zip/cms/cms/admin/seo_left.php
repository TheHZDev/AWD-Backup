<!--左侧-->
	<div class="con_left">
    	<ul class="con_nav">
        	<li class="tit"><span>网站优化</span></li>
            <li><a href="seo_duozhan.php" class="lmseo_duozhan">霸屏多地方站</a></li>
            <li><a href="seo_shenhe.php" class="lmseo_shenhe">自动审核发布</a></li>
            <li><a href="seo_gengxin.php" class="lmseo_gengxin">自动采集发布</a></li>
            <li><a href="seo_wyc.php" class="lmseo_wyc">伪原创设置</a></li>
            <li><a href="seo_tuisong.php" class="lmseo_tuisong">搜索引擎推送</a></li>
            <li><a href="seo_paiming.php" class="lmseo_paiming">排名监控</a></li>
        </ul>
    </div>