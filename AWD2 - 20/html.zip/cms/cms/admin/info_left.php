<!--左侧-->
	<div class="con_left">
    	<ul class="con_nav">
        	<li class="tit"><span>设置中心</span></li>
            <li><a href="info.php" class="lminfo">基本设置</a></li>
            <li><a href="info_moxing.php" class="lminfo_moxing">模型管理</a></li>
            <li><a href="info_shuju.php" class="lminfo_shuju">数据维护</a></li>
            <!--<li><a href="info_anquan.php" class="lminfo_anquan">安全中心</a></li>-->
            <li><a href="info_admin.php" class="lminfo_admin">管理员</a></li>
        </ul>
    </div>