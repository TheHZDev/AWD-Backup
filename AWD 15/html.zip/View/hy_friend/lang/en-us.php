<?php
return array(
	'个人中心'=>'My Center',
	'退出账号'=>'Logout',
	'清空未读'=>'Clear Msg',
	'管理后台'=>'Admin',
	'关注列表'=>'Follow List',
	'系统'=>'System',
	'系统消息'=>'System Message',
	'搜索好友名'=>'Find Username',
	'粉丝列表'=>'Fans List',
	'陌生人'=>'Stranger',
);