<?php
return array(
	'name'=>'HYBBS 默认用户中心模板',
	'mess'=>'HYBBS 默认用户中心模板',
	'user'=>'krabs',
);