<?php
return array(
    "TITLE" => '标题',
    "CATEGORY" => '分类',
    "HITS" => '点击量',
    "KEYWORDS" => '关键字',
    "COMMENT_COUNT" => '评论量',
    "SOURCE" => '来源',
    "ABSTRACT" => '摘要',
    "THUMBNAIL" => "缩略图",
    "AUTHOR" => '作者',
    "PUBLISH_DATE" => '发布时间'
);