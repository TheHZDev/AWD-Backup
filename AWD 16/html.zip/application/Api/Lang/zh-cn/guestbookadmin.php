<?php
return array(
		"Name" => '姓名',
		"EMAIL" => '邮箱',
		"TITLE" => '留言标题',
		"CONTENT" => '留言内容',
		"TIME" => '留言时间',
);