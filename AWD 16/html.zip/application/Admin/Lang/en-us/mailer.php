<?php
return array(
		"SENDER_NAME" => 'Sender Name',
		"SENDER_EMAIL_ADDRESS" => 'Sender Email',
		"SENDER_SMTP_SERVER" => 'SMTP Server',
		"SMTP_MAIL_ADDRESS" => 'SMTP Email',
		"SMTP_MAIL_PASSWORD" => 'SMTP Email Password',
		"EMAIL_ACTIVATION" => 'Email Activation',
		"EMAIL_SUBJECT" => 'Email Subject',
		"EMAIL_TEMPLATE" => 'Email Template',
		"EMAIL_TEMPLATE_HELP_TEXT" =>'Please use {$link} instead of activation link, {$username} instead of username'
);