<?php
$webdb['module_pre']='ad_';
$webdb['Info_webname']='���ϵͳ';
$webdb['Info_webOpen']='1';
$webdb['module_close']='0';
$webdb['module_id']='24';
