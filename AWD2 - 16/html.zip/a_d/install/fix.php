<?php

return array(
	'name'=>'���ģ��',
	'pre'=>'ad_',
	'setup'=>2,
	'forbid_del'=>1,
);

?>