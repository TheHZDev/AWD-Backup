<?php

return array(
	'name'=>'v7���',
	'keywords'=>'default',
);

?>