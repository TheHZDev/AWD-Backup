<?php
require_once(get_member_tpl('head'));
?>