<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZ',
    'name' => 'Discuz!',
    'url' => 'http://localhost/dz7/bbs',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => ' ',
    ),
    'recvnote' => '1',
  ),
  2 => 
  array (
    'appid' => '2',
    'type' => 'OTHER',
    'name' => '����',
    'url' => 'http://localhost/dz7/test',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => ' ',
    ),
    'recvnote' => '1',
  ),
  3 => 
  array (
    'appid' => '3',
    'type' => 'UCHOME',
    'name' => '���˼�԰',
    'url' => 'http://localhost/dz7/uch',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'synlogin' => '1',
    'extra' => '',
    'recvnote' => '1',
  ),
  4 => 
  array (
    'appid' => '4',
    'type' => 'SUPESITE',
    'name' => 'SupeSite',
    'url' => 'http://localhost/dz7/ss',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => ' ',
    ),
    'recvnote' => '1',
  ),
  5 => 
  array (
    'appid' => '5',
    'type' => 'OTHER',
    'name' => 'qb',
    'url' => 'http://localhost/v6/do',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => ' ',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://localhost/dz7/uc',
);
