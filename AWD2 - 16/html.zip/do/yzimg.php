<?php
require_once(dirname(__FILE__)."/"."global.php");
require_once(ROOT_PATH."inc/yzimg.inc.php");
?>