<?php
			$searchcode="<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
  <form name=\"formsearch\" method=\"post\" action=\"$webdb[www_url]/search.php\">
    <tr> 
      <td height=\"14\"> �ؼ���:<input type=\"text\" name=\"keyword\" size=\"10\">
        <input type=\"submit\" name=\"Submit32\" value=\"����\">
        <input type=\"hidden\" name=\"searchTable\" value=\"article\">
      </td>
    </tr>
   
  </form>
</table>
                ";