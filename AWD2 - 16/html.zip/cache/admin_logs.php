<?php	
$logdb[]='1	admin	1639823746	112.236.225.155	http://42.193.116.184/admin/index.php?lfj=center&job=config	http://42.193.116.184/admin/index.php?lfj=center&action=config';
