<?php
require(dirname(__FILE__)."/do/index.php");
?>