<?php
require(dirname(__FILE__)."/do/".basename(__FILE__));
?>