<?php
!function_exists('html') && exit('ERR');

$db->query("TRUNCATE TABLE `{$pre}upfile`");

?>