<?php
!function_exists('html') && exit('ERR');
require_once(ROOT_PATH."inc/artic_function.php");
corntab_post('DE');
?>