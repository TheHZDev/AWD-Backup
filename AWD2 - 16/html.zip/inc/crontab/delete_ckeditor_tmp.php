<?php
!function_exists('html') && exit('ERR');

del_file(ROOT_PATH."$webdb[updir]/ck/_thumbs/");
?>