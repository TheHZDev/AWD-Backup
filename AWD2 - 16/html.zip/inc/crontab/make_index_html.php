<?php
!function_exists('html') && exit('ERR');

@file("$webdb[www_url]/index.php?MakeIndex=1");
?>