<?php
if($cType){
	$fidson_menu="$cType.fidson_menu.js";
}else{
	$fidson_menu="fidson_menu.js";
}
require(html("head",$head_tpl));
?>