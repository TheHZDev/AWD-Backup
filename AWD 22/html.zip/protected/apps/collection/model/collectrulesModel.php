<?php
class collectrulesModel extends baseModel{
	protected $table = 'collectrules';
}