<?php
class ordersModel extends baseModel{
	protected $table = 'orders';
}