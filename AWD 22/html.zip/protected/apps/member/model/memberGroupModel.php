<?php
class memberGroupModel extends baseModel{
	protected $table = 'member_group';
}