<?php return array (
  'name' => '最新默认模板2013-2-1',
  'author' => 'yx',
); ?>