<?php
class defaultApi extends baseApi{

}