<?php
//系统设置实体类
class SystemModel extends Model{
	private $title;
	private $url;
	private $thumb;
	private $webname;
	private $page_size;
	private $page_size_index;
	private $keywords;
	private $description;
	private $footer;
	private $index_main;
	//拦截器(__set)
	public function __set($_key, $_value) {
		$this->$_key = tool::setFormString($_value);
	}
	
	//拦截器(__get)
	public function __get($_key){
		return $this->$_key;
	}

	//查询系统设置
	public function system(){
		$_sql="SELECT *
					FROM
						my_system
					WHERE
						id=1
						LIMIT 1";
		return parent::select($_sql);
	}
	//系统设置
	public function setSystem(){
		$_sql="UPDATE
					my_system
				SET
					title='$this->title',
					url='$this->url',
					thumb='$this->thumb',
					keywords='$this->keywords',
					description='$this->description',
					footer='$this->footer',
					webname='$this->webname',
					page_size='$this->page_size',
					page_size_index='$this->page_size_index'
				WHERE
					id=1
				LIMIT  1";
		return parent::update($_sql);
		
	}
	//更新首页内容
	public function Upindex_main(){
		$_sql="UPDATE
					my_system
				SET
					index_main='$this->index_main'
				WHERE
					id=1
				LIMIT  1";
		return parent::update($_sql);
	
	}
	
}


?>