<?php
//单页实体类
class ArticleModel extends Model{
	private $id;
	private $title;
	private $inputkeyword;
	private $color;
	private $cid;
	private $attr;
	private $tag;
	private $thumb;
	private $author;
	private $source;
	private $info;
	private $html;
	private $html_temp;
	private $content;
	private $_limit='';
	//拦截器(__set)
	public function __set($_key, $_value) {
		$this->$_key = tool::setFormString($_value);
	}
	
	//拦截器(__get)
	public function __get($_key){
		return $this->$_key;
	}
	//文章总记录
	public function _total(){
		$_sql="SELECT
					 COUNT(*) as count
				FROM 
					my_article";
		return parent::total($_sql);
	}
	
	//后台搜索的记录数
	public function search_total(){
		$_sql="SELECT 
						COUNT(*) as count
					FROM
						my_article
					WHERE
						title LIKE '%$this->inputkeyword%'";
		return parent::total($_sql);
	}
	//前台搜索记录数
	public function s_total(){
		$_sql="SELECT
					COUNT(*) as count
				FROM
					my_article
				WHERE
					(title LIKE '%$this->inputkeyword%' OR info LIKE '%$this->inputkeyword%')";
		return parent::total($_sql);
	}
	//分类下的文章数
	public function art_total(){
		$_sql="SELECT
						COUNT(*) as count
					FROM
						my_article
					WHERE
						cid='$this->cid'";
		return parent::total($_sql);
	}
	//筛选非置顶的(全部)
	public function top_total(){
		$_sql="SELECT
					COUNT(*) as count
				FROM
					my_article
				WHERE
					cid IN ($this->cid)";
		return parent::total($_sql);
	}
	
	//limit
	public function setLimit($_limit) {
		$this->_limit = $_limit;
	}
	public function test(){
		return  $this->_limit;
	}
	//添加文章
	public function add_art(){
		$_sql="INSERT INTO
						my_article(
							title,
							color,
							cid,
							attr,
							tag,
							thumb,
							html,
							ishtml,
							author,
							source,
							info,
							content,
							time,
							updatetime
							)
						VALUES(
							'$this->title',
							'$this->color',
							'$this->cid',
							'$this->attr',
							'$this->tag',
							'$this->thumb',
							'$this->html".parent::nextId('my_article').".html',
							'0',
							'$this->author',
							'$this->source',
							'$this->info',
							'$this->content',
							NOW(),
							NOW()
							)";
		return parent::add($_sql);
	}
	//修改文章
	public function update_art(){
		$_sql="UPDATE
					my_article
				SET
					title='$this->title',
					color='$this->color',
					cid='$this->cid',
					attr='$this->attr',
					tag='$this->tag',
					thumb='$this->thumb',
					html='$this->html',
					author='$this->author',
					source='$this->source',
					info='$this->info',
					content='$this->content',
					updatetime=NOW()				
				WHERE
					id='$this->id'
				LIMIT  1";
		return parent::update($_sql);
	}
	//修改静态状态为0
	public function nohtml(){
		$_sql="UPDATE
					my_article
				SET
					ishtml=0
				WHERE
					id='$this->id'
				LIMIT  1";
		return parent::update($_sql);
	}
	//获取文档列表
	public function get_artList(){
		$_sql="SELECT *
					FROM
						my_article	
					WHERE 
						cid IN ($this->cid)				
					ORDER BY
						time DESC
					$this->_limit";
		return parent::select($_sql);
	}
	//查询所有文章(用于生成全部静态)
	public function artAll(){
		$_sql="SELECT 
						id,
						cid,
						html,
						updatetime
					FROM
						my_article
					ORDER BY
						time DESC";
		return parent::select($_sql);
	}
	//获取指定数量的文档
	public function get_artLists($_num){
		$_sql="SELECT 
						title,
						title t,
						html,
						time
					FROM
						my_article
					WHERE
						cid IN ($this->cid)
					ORDER BY
						time DESC
					LIMIT 0,$_num";
		return parent::select($_sql);
	}
	public function sidebar_list($_num){
			$_sql="SELECT
						title,
						title t,
						html,
						time
					FROM
						my_article
					ORDER BY
						time DESC
					LIMIT 0,$_num";
		return parent::select($_sql);
	}
	//上一篇：
	public function art_prev(){
		$_sql="SELECT * 
					FROM
						my_article 
					WHERE
						id<$this->id 
					AND 
						cid in ($this->cid) 
					ORDER BY 
						time DESC 
					LIMIT		 
						0,1";
		return parent::select($_sql);
	}
	//下一篇：
	public function art_next(){
		$_sql="SELECT *
					FROM
						my_article
					WHERE
						id>$this->id
					AND
						cid in ($this->cid)
					ORDER BY
						time ASC
					LIMIT
						0,1";
				return parent::select($_sql);
	}
	//文章相关内容
	public function art_xg($_sum){
		$_sql="SELECT *
					FROM
						my_article
					WHERE	
						(title LIKE '%$this->tag%' OR tag LIKE '%$this->tag%' OR info LIKE '%$this->tag%')
					AND
						cid IN ($this->cid)
					AND 
						id<>$this->id
					ORDER BY
						time DESC
					LIMIT
						0,$_sum";
		return parent::select($_sql);
	}
	//首页图片(推荐+有缩略图)
	public function home_pic($_num){
		$_sql="SELECT *
					FROM
						my_article
					WHERE
						attr LIKE '%推荐%'
					AND
						thumb <> ''	
					ORDER BY
						time DESC
					LIMIT 
						0,$_num";
		return parent::select($_sql);
	}
	//获取单一文档
	public function get_artOne(){
		$_sql="SELECT *
					FROM
						my_article
					WHERE
						id='$this->id'";
		return parent::select($_sql);
	}
	//后台搜索
	public function search(){
		$_sql="SELECT *
					FROM
						my_article	
					WHERE 
						title LIKE '%$this->inputkeyword%'			
					ORDER BY
						time DESC
					$this->_limit";
		return parent::select($_sql);
	}
	//查询一篇文章
	public function findOne(){
		$_sql="SELECT *
					FROM
						my_article
					WHERE
						id='$this->id'
					LIMIT
						1";
		return parent::select($_sql);
	}
	//删除单个文章
	public function delete_article(){
		$_sql="DELETE
					FROM
						my_article
					WHERE
						id='$this->id'";
		return parent::delete($_sql);
	}
	//删除多个文章
	public function delete_all(){
		$_sql="DELETE
					FROM
						article 
					WHERE
						 id IN ('$this->id')";
		return parent::delete($_sql);
	}
	//是否置顶
	public function is_top(){
		$_sql="SELECT *
					FROM
					 	my_article
					WHERE
						attr LIKE '%置顶%'
					AND
						id='$this->id'
					LIMIT
						1";
		return parent::select($_sql);
	}
	//是否推荐
	public function is_commend(){
		$_sql="SELECT *
					FROM
						my_article
					WHERE
						attr LIKE '%推荐%'
					AND
						id='$this->id'
					LIMIT
						1";
		return parent::select($_sql);
	}
	//是否加粗
	public function is_b(){
		$_sql="SELECT *
					FROM
						my_article
					WHERE
						attr LIKE '%加粗%'
					AND
						id='$this->id'
					LIMIT
						1";
		return parent::select($_sql);
	}
	//首页侧栏-推荐
	public function home_commend($_sum){
		$_sql="SELECT 
						title,
						title t,
						html
					FROM
						my_article
					WHERE
						attr LIKE '%推荐%'
					ORDER BY
						time DESC
					LIMIT 0,$_sum";
		return parent::select($_sql);
	}
	//首页侧栏-排行
	public function home_top($_sum){
		$_sql="SELECT 
						title,
						title t,
						html
					FROM
						my_article
					WHERE
						attr LIKE '%置顶%'
					ORDER BY
						time DESC
					LIMIT 0,$_sum";
		return parent::select($_sql);
	}
	//首页侧栏-图文
	public function home_tuwen($_sum){
		$_sql="SELECT *
					FROM
						my_article
					WHERE
						thumb <> ''	
					ORDER BY
						time DESC
					LIMIT 0,$_sum";
		return parent::select($_sql);
	}
	//内容页侧栏-推荐
	public function sidebar_commend($_sum){
		$_sql="SELECT
					title,
					title t,
					html
				FROM
					my_article
				WHERE
					attr LIKE '%推荐%'
				AND
					cid IN ($this->cid)
				ORDER BY
					time DESC
				LIMIT 0,$_sum";
		return parent::select($_sql);
	}
	//内容页侧栏-排行
		public function sidebar_top($_sum){
		$_sql="SELECT
					title,
					title t,
					html
				FROM
					my_article
				WHERE
					attr LIKE '%置顶%'
				AND
					cid IN ($this->cid)
			ORDER BY
				time DESC
			LIMIT 0,$_sum";
			return parent::select($_sql);
		}
		//内容页侧栏-图文
		public function sidebar_tuwen($_sum){
		$_sql="SELECT *
					FROM
						my_article
					WHERE
						thumb <> ''
					AND
						cid IN ($this->cid)
					ORDER BY
						time DESC
					LIMIT 0,$_sum";
			return parent::select($_sql);
			}
	//生成成功后更改状态
	public function update_html(){
		$_sql="UPDATE
					my_article
				SET
					ishtml=1
				WHERE
					id='$this->id'
				LIMIT  1";
		return parent::update($_sql);
	}
	//筛选非置顶的总记录
	public function notop_total(){
		$_sql="SELECT
					 COUNT(*) as count
				FROM
					my_article
				WHERE
					cid IN ($this->cid)";
		return parent::total($_sql);
	}
	//筛选非置顶的
	public function no_top(){
		$_sql="SELECT
					*
				FROM
					my_article
				WHERE
					cid IN ($this->cid)
				ORDER BY
					time DESC
				$this->_limit";
		return parent::select($_sql);
	}
	
	//前台搜索
	public function searchs(){
		$_sql="SELECT
					title,
					info,
					html,
					time
				FROM
					my_article
				WHERE
					(title LIKE '%$this->inputkeyword%' OR info LIKE '%$this->inputkeyword%')
				ORDER BY
					time DESC
				$this->_limit";
		return parent::select($_sql);
	}
	
}


?>