<?php
//链接实体类
class LinkModel extends Model{
	private $id;
	private $linkname;
	private $linkurl;
	private $sort;
	private $_limit='';
	//拦截器(__set)
	public function __set($_key, $_value) {
		$this->$_key = tool::setFormString($_value);
	}
	
	//拦截器(__get)
	public function __get($_key){
		return $this->$_key;
	}
	
	//链接总记录
	public function _total(){
		$_sql="SELECT
					 COUNT(*) as count
				FROM
					my_link";
		return parent::total($_sql);
	}
	//limit
	public function setLimit($_limit) {
		$this->_limit = $_limit;
	}
	//添加链接
	public function add_link(){
		$_sql="INSERT INTO
						my_link(
								linkname,
								linkurl,
								sort,
								time	
								)
						VALUES(
							    '$this->linkname',
							    '$this->linkurl',
								".parent::nextId('my_link').",
								NOW()
								)";
		return parent::add($_sql);
	}
	//修改链接
	public function update_link(){
		$_sql="UPDATE
					my_link
				SET
					linkname='$this->linkname',
					linkurl='$this->linkurl'
				WHERE
					id='$this->id'
				LIMIT 1";
		return parent::update($_sql);
	}


	//查询所有链接
	public function get_link(){
		$_sql="SELECT *
				 	FROM 
						my_link
					ORDER BY
						sort ASC
					$this->_limit";
		return parent::select($_sql);
	}
	//删除链接
	public function delete_link(){
		$_sql="DELETE
					FROM
						my_link
					WHERE
						id='$this->id'";
		return parent::delete($_sql);
	}
	//获取单一链接
	public function get_linkOne(){
		$_sql="SELECT *
					FROM
						my_link
					WHERE
						id='$this->id'";
		return parent::select($_sql);
	}
	//排序
	public function setLinkSort(){
		foreach ($this->sort as $_key=>$_value){
			$_sql.="UPDATE my_link SET sort='$_value' WHERE id='$_key';";
		}
		return parent::update($_sql);
	}
	
}


?>