<?php
require str_replace('\\','/',substr(dirname(__FILE__),0,-7)).'/config/run.inc.php';
?>