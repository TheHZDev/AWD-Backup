<?php /* Smarty version 2.6.26, created on 2021-06-11 17:50:57
         compiled from admin/public/main.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>后台管理首页</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/main.css" />
</head>
<body style="background:#EBF1F3;">
<div id="current"></p>当前位置 &gt; <a href="?" target="_parent">后台首页</a></div>
<div id="main">
<table class="info" cellspacing="1">
<tr><td colspan="2" class="title">登录信息</td></tr>
<tr><td width="150">登录IP</td><td><?php echo $this->_tpl_vars['_info']['ip']; ?>
 ( <?php echo $this->_tpl_vars['_info']['re_ip']; ?>
 )</td></tr>
<tr><td>登录次数</td><td><?php echo $this->_tpl_vars['_info']['count']; ?>
</td></tr>
<tr><td>上次登录时间</td><td><?php echo $this->_tpl_vars['_info']['time']; ?>
</td></tr>
<tr><td colspan="2" class="title">程序信息</td></tr>
<tr><td>程序版本</td><td><?php echo $this->_tpl_vars['_info']['ver']; ?>
</td></tr>
<tr><td>官方网站</td><td><a href="http://www.yccms.net" target="_blank">YCCMS.NET</a></td></tr>
<tr><td colspan="2" class="title">统计信息</td></tr>
<tr><td>文章数量</td><td><?php echo $this->_tpl_vars['_info']['arts']; ?>
 条</td></tr>
<tr><td>数据库大小</td><td><?php echo $this->_tpl_vars['_info']['mysql_size']; ?>
</td></tr>
<tr><td colspan="2" class="title">环境检测</td></tr>
<tr><td>文件读写</td><td><?php echo $this->_tpl_vars['_info']['fso']; ?>
</td></tr>
<tr><td>支持PDO</td><td><?php echo $this->_tpl_vars['_info']['pdo']; ?>
</td></tr>
<tr><td>GD函数库</td><td><?php echo $this->_tpl_vars['_info']['gd']; ?>
</td></tr>
<tr><td>支持CURL</td><td><?php echo $this->_tpl_vars['_info']['curl']; ?>
</td></tr>
<tr><td>allow_url_fopen</td><td><?php echo $this->_tpl_vars['_info']['allow']; ?>
</td></tr>
<tr><td colspan="2" class="title">服务器信息</td></tr>
<tr><td>网站域名</td><td><span class="green"><?php echo $this->_tpl_vars['_info']['name']; ?>
</span></td></tr>
<tr><td>服务器IP</td><td><?php echo $this->_tpl_vars['_info']['sip']; ?>
 ( <?php echo $this->_tpl_vars['_info']['server_ip']; ?>
 )</td></tr>
<tr><td>服务器端口</td><td><?php echo $this->_tpl_vars['_info']['port']; ?>
</td></tr>
<tr><td>服务器时间</td><td><?php echo $this->_tpl_vars['_info']['stime']; ?>
</td></tr>
<tr><td>服务器版本</td><td><?php echo $this->_tpl_vars['_info']['softwart']; ?>
</td></tr>
<tr><td>服务器操作系统</td><td><?php echo $this->_tpl_vars['_info']['os']; ?>
</td></tr>
<tr><td>PHP版本</td><td><?php echo $this->_tpl_vars['_info']['php']; ?>
</td></tr>
<tr><td>执行限制</td><td><?php echo $this->_tpl_vars['_info']['time_limit']; ?>
 秒&nbsp;(0秒为不限制)</td></tr>
<tr><td>网站物理路径</td><td><?php echo $this->_tpl_vars['_info']['path']; ?>
</td></tr>
</table>
</div>
</body>
</html>