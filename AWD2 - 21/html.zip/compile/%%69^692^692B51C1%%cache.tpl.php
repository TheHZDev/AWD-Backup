<?php /* Smarty version 2.6.26, created on 2018-08-12 23:08:47
         compiled from admin/public/cache.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>清理缓存</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/cache.css" />
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 清理编译缓存</div>
<div id="cache">
<form method="post" action="?a=admin&m=cleancache">
<dl>
<dt>提示:</dt>
<dd>默认情况下编译缓存文件由系统自动更新，不需要手工清理。如果修改了文件或者配置后发现内容没有及时更新，可使用本功能清理编译文件，系统将自动重新生成编译缓存。</dd>
<dd>编译缓存是由网站模版和表单预编译生成的php缓存文件,默认是根目录下的compile文件夹。</dd>
<dd class="no"><input type="submit" name="send" value="点击这里确认清理编译缓存文件" class="submit" /></dd>
</dl>
</form>
</div>
</body>
</html>