<?php /* Smarty version 2.6.26, created on 2018-08-15 22:15:56
         compiled from admin/public/arts_process.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>生成HTML</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/html.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 内容页生成进度</div>
<script>
function runprocess() {
	$.get('<?php echo $this->_tpl_vars['processurl']; ?>
&rand=' + Math.random(), recall);
}
function recall(strers) {
	//alert(strers);
	var returnvalue = strers.split("\t");
	var percent = returnvalue[0];
	var stepid = returnvalue[1];
	var title = returnvalue[2];
	if(typeof title != "undefined" && title != "" && strers.length < 100) $("#title").html("正在生成 : "+title);
	if(percent < 100 && percent > 0) {
		//if(stepid < step.length) {$("#step").html(step[stepid] + ": ");}
		$("#percentspan").html(percent);
		$("#processdiv").width(percent + "%");
	} else if(percent == 100){
		$("#percentspan").html("100");
		$("#title").html("已完成!").css({"color":"red","font-weight":"bold"});
		$("#processdiv").width("100%");
		setTimeout(function(){self.location.href='?a=html&m=arts&art=<?php echo $this->_tpl_vars['art']; ?>
'},2000)
		return true;
	}
	setTimeout("runprocess()", 10);
}
</script>
<div id="createhtml">
<table cellspacing="1" cellpadding="4" class="commontable" style="width:666px;">
	<tr class="header">
		<td colspan="3">正在执行</td>
	</tr>
	<tr>
		<td>
			<div style="border:1px solid #555;padding:0px;width:100%;height:20px;background:#FFF;">
				<div id="processdiv" style="width:0px;background:blue;height:20px;"></div>
			</div>
			<div style='width:150px;float:right;text-align:right;margin-top:5px;'>已完成<span id="percentspan">0.00</span> %&nbsp;</div>
			<div style='width:445px;margin-top:5px;'><span id='step'></span><span id='title'></span></div>
		</td>
	</tr>
</table>
</div>
<script>runprocess();</script>
</body>
</html>