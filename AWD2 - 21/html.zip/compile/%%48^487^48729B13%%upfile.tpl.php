<?php /* Smarty version 2.6.26, created on 2018-08-28 21:00:15
         compiled from admin/public/upfile.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>上传LOGO</title>
</head>
<body>

<form method="post" action="?a=call&m=upLoad" enctype="multipart/form-data" style="text-align:center;margin:30px;">
	<input type="hidden" name="MAX_FILE_SIZE" value="2097152" />
	<input type="file" name="pic" />
	<input type="submit" name="send" value="确定上传" />
</form>

</body>
</html>