<?php /* Smarty version 2.6.26, created on 2018-08-26 18:59:00
         compiled from index/public/sidebar.tpl */ ?>
<div id="sidebar">
<dl class="nav">
<dd><a href="../index.html">首　　页</a></dd>
<?php if ($this->_tpl_vars['IndexDan']): ?>
<?php $_from = $this->_tpl_vars['IndexDan']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['item']):
?>
<dd><a href="../<?php echo $this->_tpl_vars['item']->filename; ?>
"><?php echo $this->_tpl_vars['item']->dan_name; ?>
</a></dd>
<?php endforeach; endif; unset($_from); ?>
<?php endif; ?>
<?php if ($this->_tpl_vars['Nav']): ?>
<?php $_from = $this->_tpl_vars['Nav']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<dd><a href="../<?php echo $this->_tpl_vars['value']->nav_ename; ?>
"><?php echo $this->_tpl_vars['value']->nav_name; ?>
</a></dd>
<?php endforeach; endif; unset($_from); ?>
<?php endif; ?>
</dl>
<div id="search">
<form method="get" action="../search/">
<input type="text" id="search1" class="text" name="s" autocomplete="off" value="请输入搜索内容"  /><input type="submit" class="search" value=""/>
</form>
</div>
<div id="lists">
<h2><span>最近更新</span></h2>
<ul>
<?php $_from = $this->_tpl_vars['list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<li><a href="../<?php echo $this->_tpl_vars['value']->html; ?>
" target="_blank" title="<?php echo $this->_tpl_vars['value']->t; ?>
"><?php echo $this->_tpl_vars['value']->title; ?>
</a></li>
<?php endforeach; else: ?>
<li>NULL</li>
<?php endif; unset($_from); ?>
</ul>
</div><!--list结束--> 
</div><!--sidebar结束--> 