<?php /* Smarty version 2.6.26, created on 2018-08-18 22:26:31
         compiled from admin/backup/show.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>数据库备份</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/backup.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/article.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 数据库备份&nbsp;[<a href="?a=backup&m=backlist">查看备份</a>]</div>
<div id="backup" >
<form method="post" action="?a=backup&m=bak">
<table class="site">
<tr>
	<th></th>
	<th>表名</th>
	<th>记录数</th>
</tr>
<?php $_from = $this->_tpl_vars['tabs']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<tr>
	<td><input type="checkbox" value="<?php echo $this->_tpl_vars['key']; ?>
" name="tabname[]" checked/></td>
	<td><span class="tables"><?php echo $this->_tpl_vars['key']; ?>
</span></td>
	<td><?php echo $this->_tpl_vars['value']; ?>
</td>
</tr>
<?php endforeach; else: ?>
<tr>
	<td colspan="8" class="center"><p class="error">没有任何表!</p></td>
</tr>
<?php endif; unset($_from); ?>
<tr class="nobg">
	<td colspan="3" class="noline left"><input type="checkbox" onclick="CheckAll(this.form);" name="chkall"  checked/> 全选&nbsp;分卷大小 : <input type="text" name="fsize" value="2048" class="text"/>&nbsp;KB&nbsp;&nbsp;<input type="submit" name="send" value="备份数据" class="button" /></td>
</tr>
</table>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>数据库备份功能须服务器支持。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>