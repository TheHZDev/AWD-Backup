<?php /* Smarty version 2.6.26, created on 2018-08-19 09:56:10
         compiled from admin/public/login.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>后台登录</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/login.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/layer/layer.js"></script>
<script type="text/javascript" src="../public/js/ajax.js"></script>
<script type="text/javascript" src="../public/js/login.js"></script>

</head>
<body style="background:#1c77ac url(../view/admin/images/loginbg.png) no-repeat center top;overflow:hidden;">
<div id="login">
<form method="post" name="login" action="?a=login">
<input type="hidden" name="ajaxlogin" id="ajaxlogin" />
<input type="hidden" name="ajaxcode" id="ajaxcode" />
<dl>
<dd><input type="text" name="username" class="user" id="user" onblur="checkLogin();" value="<?php echo $_COOKIE['my_admin']; ?>
"/><span> *用户名</span></dd>
<dd><input type="password" name="password" class="pass" id="pass" onblur="checkLogin();" value="<?php echo $_COOKIE['my_password']; ?>
"/><span> *密码</span></dd>
<?php if (! $this->_tpl_vars['my_admin']): ?>
<dd class="ddcode"><input type="text" name="code"  class="code" id="code" onblur="checkCode();"/> <img src="?a=call&m=validateCode" title="看不清？点击刷新" onclick="javascript:this.src='?a=call&m=validateCode&tm='+Math.random()" class="codeimg"/><span> *验证码</span></dd>
<?php endif; ?>
<dd><input type="submit" value="" name="send" onclick="return checklogin();" class="submit"/>　　<input type="checkbox" name="checkbox" <?php if ($this->_tpl_vars['my_admin']): ?>checked="checked"<?php endif; ?>/> 在本机记住用户名和密码</dd>
<p><img src="../view/admin/images/yccms.png"/>&nbsp;Copyright © YCCMS.NET.</p>
</dl>
</form>
</div>

</body>
</html>