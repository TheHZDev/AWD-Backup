<?php /* Smarty version 2.6.26, created on 2018-08-18 22:22:34
         compiled from admin/backup/site.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'admin/backup/site.tpl', 32, false),)), $this); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>程序备份</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/backup.css" />
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 程序备份</div>
<div id="backup">
<form method="post" action="?a=backup&m=site">
<dl>
<dt>提示:</dt>
<dd>将网站程序进行打包备份,备份后请及时下载到本地备份，删除服务器备份,以节省服务器空间。</dd>
<?php echo $this->_tpl_vars['prompt']; ?>

<dd class="no"><input type="submit" name="site" value="点击这里确认程序备份" onclick="javasrcipt:alert('命令成功执行!可能需要几分钟,请稍候到本页面查看备份!')?true:true" class="button" /></dd>
</dl>
</form>
<table class="site">
<tr>
	<th>　文件名</th>
	<th>大小</th>
	<th>备份时间</th>
	<th>操作</th>
</tr>
<?php $_from = $this->_tpl_vars['backlist']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<tr>
	<td>　<span class="zip"><?php echo $this->_tpl_vars['value']['filename']; ?>
</span></td>
	<td><?php echo $this->_tpl_vars['value']['filesize']; ?>
</td>
	<td><?php echo ((is_array($_tmp=$this->_tpl_vars['value']['time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y-%m-%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y-%m-%d %H:%M:%S')); ?>
</a></td>
	<td><a href="../public/backup/site/<?php echo $this->_tpl_vars['value']['filename']; ?>
" title="下载程序备份">下载</a>　<a href="?a=backup&m=deletesite&filename=<?php echo $this->_tpl_vars['value']['filename']; ?>
" title="删除" onclick="return confirm('真的要删除这个程序备份吗?删除后不可恢复!!!') ? true : false">删除</a></td>
</tr>
<?php endforeach; else: ?>
<tr>
	<td colspan="4" class="center"><p class="error">没有程序备份!</p></td>
</tr>
<?php endif; unset($_from); ?>
<tr class="nobg">
	<td colspan="4" class="noline left"></td>
</tr>
</table>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>程序备份功能须服务器支持。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>