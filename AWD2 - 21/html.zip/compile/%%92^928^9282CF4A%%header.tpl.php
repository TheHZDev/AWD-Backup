<?php /* Smarty version 2.6.26, created on 2018-08-13 22:26:47
         compiled from index/public/header.tpl */ ?>
<div id="header">
<img src="<?php echo $this->_tpl_vars['sys_thumb']; ?>
" />	
</div><!--header结束--> 