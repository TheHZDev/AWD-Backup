<?php /* Smarty version 2.6.26, created on 2018-08-15 22:43:33
         compiled from admin/public/sitemap.tpl */ ?>
<?php echo '<?xml'; ?>
 version="1.0" encoding="UTF-8"<?php echo '?>'; ?>

<urlset
    xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
       http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<?php $_from = $this->_tpl_vars['art']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<url>
  <loc><?php echo $this->_tpl_vars['sys'][0]->url; ?>
/<?php echo $this->_tpl_vars['value']->html; ?>
</loc>
  <lastmod><?php echo $this->_tpl_vars['value']->updatetime; ?>
</lastmod>
  <changefreq>daily</changefreq>
  <priority>0.8</priority>
</url>
<?php endforeach; endif; unset($_from); ?>
</urlset>