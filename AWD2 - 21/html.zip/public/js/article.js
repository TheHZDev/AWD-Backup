$(function(){
	//编缉器配置xheditor
	$('#content').xheditor({
		upImgUrl:"?a=call&m=xhUp&type=xh",
		upImgExt:"jpg,jpeg,gif,png",
		html5Upload:false,
		tools:'Cut,Copy,Paste,Pastetext,|,Blocktag,Fontface,FontSize,Bold,Italic,Underline,Strikethrough,FontColor,BackColor,SelectAll,Removeformat,|,Align,List,Outdent,Indent,|,Link,Unlink,Anchor,Img,Hr,Emot,Table,|,Source,Preview,Fullscreen,Print,About'	
	});	
	$('#add').validate({
		   highlight:function(element,errorClass){
		   $(element).css('border','1px solid red');   
		   $(element).parent().find('span').html(' ').removeClass('succ'); 
		   },
		   unhighlight:function(element,errorClass){
		   $(element).css('border','1px solid #ccc');
		   $(element).parent().find('span').html(' ').addClass('succ');  
		   },
		   rules:{
			   	title:{
					required:true
				},
				  cid:{
					required:true
				},
				  tag:{
					required:true
				},
				 info:{
					required:true
				},
			  content:{
					required:true
				}
			},
		 messages:{
			 	title:{
					required:'请填写文章标题!'
				},
				  cid:{
					required:'请选择分类!'
				},
				  tag:{
					required:'请填写标签!'
				},
				 info:{
					required:'请填写简介/摘要!'
				},
			  content:{
					required:'请填写内容!'
				}
			}
		});	
});

//弹窗居中
function centerWindow(url, name, width, height) {
	var left = (screen.width - width) / 2;
	var top = (screen.height - height) / 2 - 50;
	window.open(url, name, 'width='+width+',height='+height+',top='+top+',left='+left);
}
//选择全部
function CheckAll(form) {
	  
	  for (var i = 0 ;i<form.elements.length; i++) {
	   var e = form.elements[i] ;  
	   if (e.name!='chkall') {
	   
	    e.checked = form.chkall.checked; 
	   }
	  }
	  
	 } 