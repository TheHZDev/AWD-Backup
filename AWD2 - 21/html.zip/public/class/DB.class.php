<?php
	//数据库连接类
	class DB{
		//pdo对象
		public  $_pdo = null;
		//用于存放实例化的对象
		static private $_instance = null;
		//公共静态方法获取实例化的对象
		static public function getInstance() {
			if (!(self::$_instance instanceof self)) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}
		//构造方法
		public function __construct() {
			try {
				$this->_pdo = new PDO(DB_DNS, DB_USER, DB_PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND=>'SET NAMES '.DB_CHARSET));
				$this->_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			} catch (PDOException $e) {
				exit('数据库连接错误:'.$e->getMessage());
			}
		}
	}

?>