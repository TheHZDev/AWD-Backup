<?php
//管理员控制器
class AdminAction extends Action{
	private $_art;
	public function __construct(){
		parent::__construct();
		$this->_art=new ArticleModel();
		$this->_model=new AdminModel();
	}
	//后台初始
	public function index(){
		if (isset($_SESSION['admin'])) {
			$this->_tpl->assign('admin', $_SESSION['admin']);
			$this->_tpl->display('admin/public/admin.tpl');
		} else {
			Tool::alertLocation(null, '?a=login');
		}
		
	}
	//修改密码
	public function update(){
		if(isset($_POST['send'])){
			if(validate::isNullString($_POST['username'])) Tool::t_back('用户名不能为空','?a=admin&m=update');
			if(validate::isNullString($_POST['password'])) Tool::t_back('密码不能为空!','?a=admin&m=update');
			if(!(validate::checkStrEquals($_POST['password'], $_POST['notpassword']))) Tool::t_back('两次密码不一致!','?a=admin&m=update');
			$this->_model->username=$_POST['username'];
			$this->_model->password=sha1($_POST['password']);
			$_edit=$this->_model->editAdmin();
			if($_edit){
				tool::layer_alert('密码修改成功!','?a=admin&m=update',6);
				}else{
				tool::layer_alert('密码未修改!','?a=admin&m=update',6);
			}
		}
		
			$this->_tpl->assign('admin', $_SESSION['admin']);
			$this->_tpl->display('admin/public/update.tpl');
	}
	
	//系统信息
	public function main(){
		$_ip=new Ip();
		$_info=array();
		$_info['ip']=@$_SERVER["REMOTE_ADDR"]; //客户IP
		$_re_ip=$_ip->getlocation($_info['ip']);
		$_info['re_ip']=$_re_ip['country'];
		$_info['count']=@$_SESSION['admin']['count'];//登录次数
		$_info['time']=@$_SESSION['admin']['time'];//上次登录时间
		$_info['ver']=@VERSION;
		$_info['name']=$_SERVER['SERVER_NAME'];//域名
		$_info['sip']='/'==DIRECTORY_SEPARATOR?@$_SERVER['SERVER_ADDR']:@gethostbyname($_SERVER['SERVER_NAME']);//服务器IP
		$_server_ip=$_ip->getlocation($_info['sip']);
		$_info['server_ip']=$_server_ip['country'];
		$_info['arts']=$this->_art->_total();//文章数
		$_info['allow']=(ini_get('allow_url_fopen') ? '<span style="color:green;font-weight:bold;">√ 支持</font>' : '<font style="color:red;font-weight:bold;">× 不支持</font>');
		$_info['gd']=(function_exists('gd_info') ? '<span style="color:green;font-weight:bold;">√ 支持</font>' : '<font style="color:red;font-weight:bold;">× 不支持</font>');
		$_info['curl']=(function_exists( 'curl_init' ) && function_exists( 'curl_exec' ) ? '<span style="color:green;font-weight:bold;">√ 支持</font>' : '<font style="color:red;font-weight:bold;">× 不支持</font>');
		$_info['pdo']=(class_exists( 'pdo' ) ? '<span style="color:green;font-weight:bold;">√ 支持</font>' : '<font style="color:red;font-weight:bold;">× 不支持</font>');
		$_info['fso']=(function_exists( 'file_put_contents' ) && function_exists( 'file_get_contents' ) ? '<span style="color:green;font-weight:bold;">√ 支持</font>' : '<font style="color:red;font-weight:bold;">× 不支持</font>');
		$_info['port']=$_SERVER['SERVER_PORT'];//服务器端口
		$_info['stime']=date('Y-m-d H:i:s',time());//服务器时间
		$_info['softwart']=$_SERVER['SERVER_SOFTWARE'];//服务器版本
		$_info['os']=php_uname(); //操作系统
		$_info['php']=phpversion();//php版本
		$_info['time_limit']=ini_get('max_execution_time');//超时时间
		$_info['path']=$_SERVER['DOCUMENT_ROOT'];//网站物理路径
		$_info['space_free']=Tool::sizeUnit(disk_free_space(ROOT_PATH));//空间剩余
		$_info['mysql_size']=Tool::CalcFullDatabaseSize(DB_NAME,DB::getInstance()->_pdo);//mysql数据库大小
		$this->_tpl->assign('_info',$_info);
		$this->_tpl->display('admin/public/main.tpl');
	}
	//后台退出
	public function logout() {
		if (isset($_SESSION['admin'])) session_destroy();
		Tool::alertLocation(null, '?a=login');
	}
	//清理编译缓存
	public function cleancache(){
		if(isset($_POST['send'])){
		$_dirPath=opendir(dirname(dirname(__FILE__)).'/compile//');
		$_fileDir=ROOT_PATH.'/compile/';
		$_cacheCount=count(scandir(dirname(dirname(__FILE__)).'/compile//')) - 2;
		$_dirName='';
		while(!!$_dirName=readdir($_dirPath)){
			if($_dirName!='.' && $_dirName!='..'){
				if(!unlink($_fileDir.$_dirName)){
					tool::layer_alert('缓存文件清理失败,请设权限为777!','?a=admin&m=cleancache',2);
				}
			}
		}
		tool::layer_alert(''.$_cacheCount.'个编译缓存清理完毕!','?a=admin&m=cleancache',6);
		}
		$this->_tpl->display('admin/public/cache.tpl');
	}
}



?>