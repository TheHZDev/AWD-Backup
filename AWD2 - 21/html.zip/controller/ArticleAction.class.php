<?php
//文章控制器
class ArticleAction extends Action{
	private $_total='';
	public function __construct(){
		parent::__construct();
		$this->_sys=new SystemModel();
		$this->_model=new ArticleModel();

	}
	
	//文章列表
	public function index(){
		$_nav = new NavModel();	
		$_sys=$this->_sys->system();
		//搜索
		if(isset($_GET['search'])){
			if(validate::isNullString($_GET['keywords'])) Tool::t_back('ERROR:关键字为空!!','?a=article');
			$this->_model->inputkeyword=$_GET['keywords'];
			parent::page($this->_model->search_total(),$_sys[0]->page_size);
			$_object=$this->_model->search();
			if ($_object) {
				foreach ($_object as $_value) {
					$_value->title = str_replace($this->_model->inputkeyword,'<span class="red">'.$this->_model->inputkeyword.'</span>',$_value->title);
				}
			}
		}else{
			
			if(empty($_GET['par_id'])){
				//$_nav->id=$_GET['par_id'];
				$_cid=$_nav->getAllNav();
				$this->_model->cid=tool::objArrOfStr($_cid,'id');
			}else{
				$this->_model->cid=$_GET['par_id'];
			}
			if($_nav->getAllNav()){
			parent::page(count($this->_model->get_artList()),$_sys[0]->page_size);
			$_object=$this->_model->get_artList();
			}else{
				$_object=NULL;
			}

		}
		
		if($_object){
		foreach($_object as $_value){
			$_nav->id =$_value->cid;
			$_fineone=$_nav->findone();
			$_value->cname=$_fineone[0]->nav_name;
			$_value->par_id=$_value->cid;
			$_value->par_name=$_fineone[0]->nav_name;
			$this->_model->id=$_value->id;
			//置顶显示
			$_value->top=$this->_model->is_top();
			$_value->top?$_value->top=true:$_value->top=false;
			//推荐显示
			$_value->commend=$this->_model->is_commend();
			$_value->commend?$_value->commend=true:$_value->commend=false;
			//是否加粗
			$_value->b=$this->_model->is_b();
			$_value->b?$_value->b=true:$_value->b=false;
			
			}	
		//tool::subStr($_object, 'title', 10, 'utf-8');
		}
		Tool::getFormString($_object, 'title');
		$this->_tpl->assign('artList',$_object);
		$this->_tpl->display('admin/article/show.tpl');
	}
	
	//添加文章
	public function add(){
		if(isset($_POST['send'])){
			$this->getPost();
			//得到大父类目录名
			$_nav=new NavModel();
			$_nav->id=$this->_model->cid;
			$_parent=$_nav->findOne();
			$this->_model->html=$_parent[0]->nav_ename.'/';
					
			if($this->_model->add_art()){
				tool::layer_alert('文章添加成功!','?a=article&m=index',6);
			}else{
				tool::layer_alert('文章添加成功!','?a=article&m=index',5);
			}
			
		}
		$this->title_color();
		$this->nav();
		$this->_tpl->assign('admin', $_SESSION['admin']);
		$this->_tpl->display('admin/article/add.tpl');
	}
	//getpost
	private function getPost(){
		if (isset($_POST['attr'])) {
			$this->_model->attr = implode(',',$_POST['attr']);
		} else {
			$this->_model->attr = '无';
		}
		$this->_model->title=$_POST['title'];
		$this->_model->color=$_POST['color'];
		$this->_model->cid=$_POST['cid'];
		$this->_model->tag=$_POST['tag'];
		$this->_model->thumb=$_POST['thumb'];
		$this->_model->author=$_POST['author'];
		$this->_model->source=$_POST['source'];
		$this->_model->info=$_POST['info'];
		$this->_model->content=$_POST['content'];
	}
	//修改文章
	public function update(){
		if(isset($_POST['send'])){
			$this->_model->id=$_POST['id'];
			$this->getPost();
			//得到大父类目录名
			$_nav=new NavModel();
			$_nav->id=$this->_model->cid;
			$_parent=$_nav->findOne();
			//得到文章路径
			$this->_model->html=$_parent[0]->nav_ename.'/'.$this->_model->id.'.html';
			//将静态改为否
			$this->_model->nohtml();
			//删除旧文件
			$html=$_SESSION['html_temp'];
			if($html==NULL){
				$html='0.html';
			}
			tool::delete_file($html);
			if($this->_model->update_art()){
				tool::layer_alert('文章修改成功!',$_POST['prev_url'],6);
			}
		}
		if(isset($_GET['id'])){
			$this->_model->id=$_GET['id'];
			$_art=$this->_model->get_artOne();
			$_SESSION['html_temp']=$_art[0]->html;
			if($_art){
				$this->_tpl->assign('id',StripSlashes($_art[0]->id));
				$this->_tpl->assign('title',StripSlashes($_art[0]->title));
				$this->_tpl->assign('color',$_art[0]->color);
				$this->_tpl->assign('tag',StripSlashes($_art[0]->tag));
				$this->_tpl->assign('thumb',$_art[0]->thumb);
				$this->_tpl->assign('author',StripSlashes($_art[0]->author));
				$this->_tpl->assign('source',StripSlashes($_art[0]->source));
				$this->_tpl->assign('info',StripSlashes($_art[0]->info));
				$this->_tpl->assign('content',StripSlashes($_art[0]->content));
				$this->_tpl->assign('prev_url',tool::getPrevPage());
				$this->nav($_art[0]->cid);
				$this->attr($_art[0]->attr);
			}else{
				tool::layer_alert('ERROR:不存在的内容!','?a=article&m=index',7);
			}
		}
		$this->title_color();
		$this->_tpl->display('admin/article/update.tpl');
	}
	//删除单个文章
	public function delete(){
		if(isset($_GET['id'])){
			$this->_model->id=$_GET['id'];
			$_findOne=$this->_model->findOne();
			$html=$_findOne[0]->html;
			if($html==NULL){
				$html='0.html';
			}
			//先删除静态文件
			if(tool::delete_file($html)){
				if($this->_model->delete_article()){
					Tool::alertLocation(null, tool::getPrevPage());
				}else{
					tool::layer_alert('删除失败!','?a=article&m=index',7);
				}
			}
		}
	}
	//删除多个文章
	public function delall(){
		if(isset($_POST['send'])){
			if(validate::isNullString($_POST['showid'])) tool::layer_alert('没有选择任何内容!','?a=article&m=index',7);
			//$this->_model->id=implode(',',$_POST['showid']);
			//echo $this->_model->id;
			foreach ($_POST['showid'] as $_value){
				$this->_model->id=$_value;
				$_findOne=$this->_model->findOne();
				$html=$_findOne[0]->html;
				if($html==NULL){
					$html='0.html';		
				}
				//先删除静态文件
				if(file_exists(ROOT_PATH.'/'.$html)){
				if(!unlink(ROOT_PATH.'/'.$html)){
					tool::layer_alert('静态文件删除失败,请设权限为777!','?a=article&m=index',5);
				}
				}
				$this->_model->delete_article();
				header('Location:'.tool::getPrevPage());
			}
		}
	}

	//nav
	private function nav($_n = 0) {
		$_nav = new NavModel();
		if($_nav->getAllNav()){
		foreach ($_nav->getAllNav() as $_object) {
					if ($_n == $_object->id) $_selected = 'selected="selected"';
					$_html .= '<option '.$_selected.' value="'.$_object->id.'">'.$_object->nav_name.'</option>'."\r\n";
					$_selected = '';
		}
		}
		$this->_tpl->assign('nav',$_html);
	}
	//attr
	private function attr($_attr) {
		$_attrArr = array('加粗');
		$_attrS = explode(',',$_attr);
		$_attrNo = array_diff($_attrArr,$_attrS);
		if ($_attrS[0] != '无') {
			foreach ($_attrS as $_value) {
				$_html .= '<input type="checkbox" checked="checked" name="attr[]" value="'.$_value.'" />&nbsp;'.$_value.'&nbsp;';
			}
		}
		foreach ($_attrNo as $_value) {
			$_html .= '<input type="checkbox" name="attr[]" value="'.$_value.'" />&nbsp;'.$_value.'&nbsp;';
		}
		$this->_tpl->assign('attr',$_html);
	}
	
	//选择标题颜色
	private function title_color(){
		function getcolor($arr) {
			global $color_style;
			$color = $html = '';
			if ( preg_match( "/^#[0-9a-zA-Z]{6}$/", $arr['value'] ) ) $color = $arr['value'];
			if ( !$color_style ) {
				$color_style = 1;
				$html .= '<script type="text/javascript" src="../public/js/color.js"></script>';
			} else {
				++$color_style;
			}
			$html .= '<input type="hidden" name="' . $arr['name'] . '" id="color_input_' . $color_style . '" value="' . $color . '"/><img src="../view/admin/images/color.gif" width="21" height="18" align="absmiddle" id="color_img_' . $color_style . '" style="cursor:pointer;background:' . $color . '" onclick="color_show(' . $color_style . ', $(\'#color_input_' . $color_style . '\').val(), this);"/>';
			return  $html;
		}
		$this->_tpl->register_function('getcolor','getcolor');
	}
	

}



?>