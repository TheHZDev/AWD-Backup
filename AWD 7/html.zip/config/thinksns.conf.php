<?php

/*
 * ThinkSNS 拓展信息配置
 *
 * @var array
 **/
return array(

    /* ThinkSNS v4 */
    'VERSION' => '4.6.0', // # ThinkSNS 版本
    'UPURL'   => 'http://demo.thinksns.com/upgrade/entry.php', // # 升级地址

    'exchange_type' => 5, //智播积分兑换比例 20161030 bs
);
