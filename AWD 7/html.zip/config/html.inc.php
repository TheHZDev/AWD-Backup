<?php
/*
 * 页面静态化规则，重新更新后需要清缓存
 */
return array(
    'html' => array(
        // 'public/Register/index' => true, // 注册
        'public/Passport/login' => true, // 登录
    ),
);
