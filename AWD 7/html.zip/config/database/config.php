<?php

// 数据库配置文件 - 临时

return array(
    'collation' => 'utf8_unicode_ci',
);
