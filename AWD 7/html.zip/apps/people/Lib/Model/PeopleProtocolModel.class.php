<?php
/**
     * ***ProtocolModel
     * 提供给TS核心调用的协议类.
     */
class PeopleProtocolModel extends Model
{
    // 假删除用户数据
    public function deleteUserAppData($uidArr)
    {
    }

    // 恢复假删除的用户数据
    public function rebackUserAppData($uidArr)
    {
    }

    // 彻底删除用户数据
    public function trueDeleteUserAppData($uidArr)
    {
    }
}
