<?php

if (!defined('SITE_PATH')) {
    exit();
}
