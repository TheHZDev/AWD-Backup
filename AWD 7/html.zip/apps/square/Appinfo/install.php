<?php

if (!defined('SITE_PATH')) {
    exit();
}

header('Content-Type: text/html; charset=utf-8');
