<?php

echo 'thinksns';
