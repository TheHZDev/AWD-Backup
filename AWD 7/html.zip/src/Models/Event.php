<?php

namespace Ts\Models;

use Ts\Bases\Model;

/**
 * 活动模型.
 *
 * @author bs
 **/
class Event extends Model
{
    protected $table = 'event_list';

    protected $primaryKey = 'eid';
} // END class Feed extends Model
