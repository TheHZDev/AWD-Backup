<?php

namespace Ts\Models;

use Ts\Bases\Model;

/**
 * 活动关注模型.
 *
 * @author bs
 **/
class EventStar extends Model
{
    protected $table = 'event_star';

    protected $primaryKey = 'eid';
} // END class Feed extends Model
