<?php

namespace Ts\Models;

use Ts\Bases\Model;

/**
 * 地区模型.
 *
 * @author bs
 **/
class Area extends Model
{
    protected $table = 'area';

    protected $primaryKey = 'area_id';
} // END class Feed extends Model
