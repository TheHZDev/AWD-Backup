<?php
return array (
  'ZB_config' => 
  array (
    'version' => '1',
    'cash_exchange_ratio_list' => '1:100,2.5:200,4:300',
  ),
);
?>