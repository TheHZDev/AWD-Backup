<?php
return array (
  'announcement' => 
  array (
    'is_open' => '1',
    'content' => '欢迎使用SociaxTeam',
  ),
  'nav' => 
  array (
    'navi_name' => '123',
    'attach' => '',
    'app_name' => '',
    'url' => '123',
    'target' => 'appoint',
    'status' => 'appoint',
    'position' => '',
    'guest' => 'appoint',
    'is_app_navi' => 'appoint',
    'parent_id' => '123',
    'order_sort' => '123',
  ),
  'seo_user_profile' => 
  array (
    'name' => '个人主页',
    'title' => '{uname}的空间',
    'keywords' => '{uname}',
    'des' => '{lastFeed}',
    'node' => '',
    'sub' => '保存',
  ),
  'seo_feed_detail' => 
  array (
    'name' => '分享详情页',
    'title' => '{uname}的分享',
    'keywords' => '{uname}',
    'des' => '{content}',
    'node' => '',
    'sub' => '保存',
  ),
  'seo_feed_topic' => 
  array (
    'name' => '话题页',
    'title' => '{topicName}',
    'keywords' => '{topicName}',
    'des' => '{topicDes}',
    'node' => '',
    'sub' => '保存',
  ),
  'invite' => 
  array (
    'send_email_num' => '3',
    'send_link_num' => '3',
  ),
  'audit' => 
  array (
    'open' => '1',
    'replace' => '**',
  ),
  'attachimage' => 
  array (
    'attach_max_size' => '2',
    'attach_allow_extension' => 'png,gif,jpg,jpeg',
    'auto_thumb' => '1',
  ),
  'attach' => 
  array (
    'attach_path_rule' => 'Y/md/H/',
    'attach_max_size' => '100',
    'attach_allow_extension' => 'png,jpeg,zip,rar,doc,xls,ppt,docx,xlsx,pptx,pdf,jpg,gif,mp3',
  ),
  'register' => 
  array (
    'register_type' => 'open',
    'account_type' => 'all',
    'email_suffix' => '',
    'captcha' => '',
    'register_audit' => '0',
    'need_active' => '0',
    'personal_open' => '0',
    'personal_required' => 
    array (
      0 => 'face',
      1 => 'tag',
      2 => 'intro',
    ),
    'tag_num' => '5',
    'interester_rule' => 
    array (
      0 => 'tag',
    ),
    'avoidSubmitByReturn' => '',
    'interester_recommend' => '',
    'default_follow' => '',
    'each_follow' => '',
    'default_user_group' => 
    array (
      0 => '3',
    ),
    'welcome_notify' => '',
  ),
  'feed' => 
  array (
    'weibo_nums' => '140',
    'weibo_type' => 
    array (
      0 => 'face',
      1 => 'at',
      2 => 'image',
      3 => 'video',
      4 => 'file',
      5 => 'topic',
    ),
    'weibo_uploadvideo_open' => '0',
    'weibo_premission' => 
    array (
      0 => 'repost',
      1 => 'comment',
    ),
    'weibo_send_info' => '新注册的童鞋如果体验社区功能欢迎到任务中心去做任务哦~',
    'weibo_default_topic' => '',
    'weibo_at_me' => '0',
  ),
  'email' => 
  array (
    'email_sendtype' => 'smtp',
    'email_host' => 'smtp.admin.com',
    'email_ssl' => '0',
    'email_port' => '25',
    'email_account' => 'admin@admin.com',
    'email_password' => 'admin',
    'email_sender_name' => 'ThinkSNS官方社区',
    'email_sender_email' => 'admin@admin.com',
    'email_test' => '',
  ),
  'sms' => 
  array (
    'sms_server' => 'http://106.ihuyi.cn/webservice/sms.php?method=Submit',
    'sms_param' => 'account=admin&password=admin&mobile={tel}&content={message}',
    'success_code' => '<code>2</code>',
    'send_type' => 'post',
    'service' => 'ihuyi',
  ),
  'cloudimage' => 
  array (
    'cloud_image_open' => '0',
    'cloud_image_api_url' => 'http://v0.api.upyun.com',
    'cloud_image_bucket' => 'thinksns_v4',
    'cloud_image_form_api_key' => 'asdPKsdjfshnjfsPQ7cVBRasfd',
    'cloud_image_prefix_urls' => 'http://www.thinksns.com',
    'cloud_image_admin' => 'admin',
    'cloud_image_password' => 'admin',
  ),
  'cloudattach' => 
  array (
    'cloud_attach_open' => '0',
    'cloud_attach_api_url' => 'http://v0.api.upyun.com',
    'cloud_attach_bucket' => 'thinksns',
    'cloud_attach_form_api_key' => 'ajskdhnajkshbfdajjkdhnakjsndjkans',
    'cloud_attach_prefix_urls' => 'http://www.thinksns.com',
    'cloud_attach_admin' => 'admin',
    'cloud_attach_password' => 'admin',
  ),
  'seo_login' => 
  array (
    'name' => '登录页',
    'title' => 'Bugku CTF-AWD圈',
    'keywords' => 'Bugku yyds',
    'des' => 'Bugku yyds',
    'node' => '',
    'sub' => '提交',
  ),
  'site' => 
  array (
    'site_closed' => '1',
    'site_name' => 'CTF圈子',
    'site_slogan' => 'bugku',
    'site_header_keywords' => 'bugku',
    'site_header_description' => 'bugku',
    'site_company' => '',
    'site_footer' => '©2021 Bugku All Rights Reserved.',
    'site_footer_des' => '',
    'attach' => '',
    'site_logo' => '83',
    'undefined_ids' => '|',
    'site_qr_code' => '82',
    'sina_weibo_link' => 'http://weibo.com/bugku',
    'login_bg' => '45095',
    'site_closed_reason' => '大伙儿不要害怕，我是来测试功能的，一会儿就给你们恢复，这个页面太丑了我要换一个。',
    'sys_domain' => 'admin,thinksns,kefu,liuxiaoqing,hujintao,liaosunan,xijinping,zhishisoft',
    'sys_nickname' => '管理员,超级管理员,法轮功,胡锦涛,江泽民,邓小平,小秘书,刘晓庆,廖素南,共产党,党,习近平,李宇春,政府,小胡祖宗,国民党,admin,智士软件,thinksns',
    'sys_email' => 'admin@bugku .com',
    'home_page' => '0',
    'sys_version' => '2015050501',
    'site_online_count' => '1',
    'site_rewrite_on' => '0',
    'web_closed' => '1',
    'site_analytics_code' => '',
  ),
);
?>