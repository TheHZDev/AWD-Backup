<?php
return array (
  'weibaAdminAuditConfig' => 
  array (
    'follower_open' => 1,
    'follower' => 5,
    'level_open' => 1,
    'level' => 5,
    'weiba_post_open' => 1,
    'weiba_post' => 5,
  ),
  'weibaAuditConfig' => 
  array (
    'apply_weiba_open' => 1,
    'follower_open' => 0,
    'follower' => 0,
    'level_open' => 0,
    'level' => 0,
    'weiba_post_open' => 0,
    'weiba_post' => 0,
    'manager_open' => 0,
  ),
);
?>