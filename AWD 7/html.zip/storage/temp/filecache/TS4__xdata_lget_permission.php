<?php
return array (
  18 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_post' => '1',
      ),
    ),
  ),
  12 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
        'feed_post' => '1',
        'feed_comment' => '1',
        'feed_report' => '1',
        'feed_share' => '1',
      ),
    ),
  ),
  25 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
      ),
      'admin' => 
      array (
        'comment_del' => '1',
      ),
    ),
  ),
  27 => 
  array (
    'manage' => 
    array (
      'normal' => 
      array (
        'enter' => '1',
      ),
      'admin' => 
      array (
        'support' => '1',
      ),
    ),
    'support' => 
    array (
      'admin' => 
      array (
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  26 => 
  array (
    'manage' => 
    array (
      'normal' => 
      array (
        'enter' => '1',
      ),
      'admin' => 
      array (
        'support' => '1',
      ),
    ),
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
      ),
    ),
  ),
  28 => 
  array (
    'manage' => 
    array (
      'normal' => 
      array (
        'enter' => '1',
      ),
      'admin' => 
      array (
        'support' => '1',
      ),
    ),
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'support_updateversion' => '1',
      ),
    ),
  ),
  29 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  30 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  31 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  32 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  33 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  34 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  35 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  36 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  37 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  38 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  40 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  39 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_create' => '1',
        'support_deldraft' => '1',
        'support_submit' => '1',
        'manage' => '1',
      ),
    ),
  ),
  41 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  42 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'support_create' => '1',
        'manage' => '1',
      ),
    ),
  ),
  43 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  44 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  45 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_create' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'manage' => '1',
      ),
    ),
  ),
  46 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewlog' => '1',
        'support_changeversion' => '1',
        'manage' => '1',
        'support_audit' => '1',
      ),
    ),
  ),
  47 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  48 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'support_create' => '1',
        'manage' => '1',
      ),
    ),
  ),
  49 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  50 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  51 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'support_create' => '1',
        'manage' => '1',
      ),
    ),
  ),
  52 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  53 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  54 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'support_create' => '1',
        'manage' => '1',
      ),
    ),
  ),
  55 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  56 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  57 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'support_create' => '1',
        'manage' => '1',
      ),
    ),
  ),
  58 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  59 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  60 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'support_create' => '1',
        'manage' => '1',
      ),
    ),
  ),
  61 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  62 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  63 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_create' => '1',
        'support_update' => '1',
        'support_deldraft' => '1',
        'support_submit' => '1',
        'manage' => '1',
      ),
    ),
  ),
  64 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
        'support_changeversion' => '1',
      ),
    ),
  ),
  69 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  70 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  71 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  72 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  74 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  73 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_create' => '1',
        'support_update' => '1',
        'support_deldraft' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'manage' => '1',
      ),
    ),
  ),
  75 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  76 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  77 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  78 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  79 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  80 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  81 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  82 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  83 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  84 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  85 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_create' => '1',
        'support_update' => '1',
        'support_deldraft' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'manage' => '1',
      ),
    ),
  ),
  86 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
        'support_changeversion' => '1',
      ),
    ),
  ),
  87 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  88 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  89 => false,
  90 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  91 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  92 => false,
  93 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  94 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  95 => false,
  96 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  97 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  98 => false,
  99 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  100 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  101 => false,
  102 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  104 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_update' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_changeversion' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  103 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewversion' => '1',
        'support_updateversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_create' => '1',
        'support_viewlog' => '1',
        'manage' => '1',
      ),
    ),
  ),
  105 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  106 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  107 => false,
  108 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  110 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_submit' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
        'support_changeversion' => '1',
      ),
    ),
  ),
  109 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_create' => '1',
        'support_update' => '1',
        'support_deldraft' => '1',
        'support_submit' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'manage' => '1',
      ),
    ),
  ),
  111 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  112 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'support_update' => '1',
        'manage' => '1',
        'support_create' => '1',
      ),
    ),
  ),
  113 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_viewversion' => '1',
        'support_viewlog' => '1',
        'support_audit' => '1',
        'support_setstatus' => '1',
        'manage' => '1',
        'support_changeversion' => '1',
      ),
    ),
  ),
  114 => 
  array (
    'support' => 
    array (
      'normal' => 
      array (
        'support_viewfeedback' => '1',
      ),
      'admin' => 
      array (
        'support_setfeedbackstatus' => '1',
        'manage' => '1',
      ),
    ),
  ),
  115 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_create' => '1',
        'support_submit' => '1',
        'support_deldraft' => '1',
        'manage' => '1',
        'support_seereject' => '1',
        'support_seesuccess' => '1',
        'support_seewaiting' => '1',
      ),
    ),
  ),
  116 => 
  array (
    'support' => 
    array (
      'admin' => 
      array (
        'support_update' => '1',
        'support_audit' => '1',
        'support_viewlog' => '1',
        'support_updateversion' => '1',
        'support_viewversion' => '1',
        'support_setstatus' => '1',
        'support_changeversion' => '1',
        'manage' => '1',
        'support_seerelease' => '1',
        'support_seereject' => '1',
        'support_seesuccess' => '1',
        'support_seewaiting' => '1',
      ),
    ),
  ),
  17 => 
  array (
  ),
  4 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
      ),
    ),
  ),
  5 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
        'send_message' => '1',
        'read_data' => '1',
        'invite_user' => '1',
        'search_info' => '1',
        'comment_del' => '1',
        'feed_post' => '1',
        'feed_comment' => '1',
        'feed_report' => '1',
        'feed_share' => '1',
        'feed_del' => '1',
      ),
    ),
    'weiba' => 
    array (
      'normal' => 
      array (
        'weiba_post' => '1',
        'weiba_reply' => '1',
        'weiba_del' => '1',
        'weiba_del_reply' => '1',
        'weiba_edit' => '1',
        'weiba_apply_manage' => '1',
      ),
    ),
  ),
  6 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
        'send_message' => '1',
        'read_data' => '1',
        'invite_user' => '1',
        'search_info' => '1',
        'comment_del' => '1',
        'feed_post' => '1',
        'feed_comment' => '1',
        'feed_report' => '1',
        'feed_share' => '1',
        'feed_del' => '1',
      ),
    ),
    'weiba' => 
    array (
      'normal' => 
      array (
        'weiba_post' => '1',
        'weiba_reply' => '1',
        'weiba_del' => '1',
        'weiba_del_reply' => '1',
        'weiba_edit' => '1',
        'weiba_apply_manage' => '1',
      ),
    ),
  ),
  7 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
        'send_message' => '1',
        'read_data' => '1',
        'invite_user' => '1',
        'search_info' => '1',
        'comment_del' => '1',
        'feed_post' => '1',
        'feed_comment' => '1',
        'feed_report' => '1',
        'feed_share' => '1',
        'feed_del' => '1',
      ),
    ),
    'weiba' => 
    array (
      'normal' => 
      array (
        'weiba_post' => '1',
        'weiba_reply' => '1',
        'weiba_del' => '1',
        'weiba_del_reply' => '1',
        'weiba_edit' => '1',
        'weiba_apply_manage' => '1',
      ),
    ),
  ),
  8 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
        'send_message' => '1',
        'read_data' => '1',
        'invite_user' => '1',
        'search_info' => '1',
        'comment_del' => '1',
        'feed_post' => '1',
        'feed_comment' => '1',
        'feed_report' => '1',
        'feed_share' => '1',
        'feed_audit' => '1',
        'feed_del' => '1',
      ),
    ),
  ),
  '' => 
  array (
  ),
  2 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
        'read_data' => '1',
        'invite_user' => '1',
        'send_message' => '1',
        'search_info' => '1',
        'comment_del' => '1',
        'feed_del' => '1',
        'feed_post' => '1',
        'feed_comment' => '1',
        'feed_report' => '1',
        'feed_share' => '1',
      ),
      'admin' => 
      array (
        'feed_del' => '1',
        'comment_del' => '1',
      ),
    ),
    'weiba' => 
    array (
      'normal' => 
      array (
        'weiba_post' => '1',
        'weiba_reply' => '1',
        'weiba_del' => '1',
        'weiba_del_reply' => '1',
        'weiba_edit' => '1',
        'weiba_apply_manage' => '1',
      ),
    ),
    'channel' => 
    array (
      'admin' => 
      array (
        'channel_recommend' => '1',
      ),
    ),
  ),
  1 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
        'read_data' => '1',
        'invite_user' => '1',
        'send_message' => '1',
        'search_info' => '1',
        'comment_del' => '1',
        'feed_del' => '1',
        'feed_post' => '1',
        'feed_comment' => '1',
        'feed_report' => '1',
        'feed_share' => '1',
      ),
      'admin' => 
      array (
        'feed_del' => '1',
        'comment_del' => '1',
        'message_del' => '1',
        'admin_login' => '1',
        'feed_recommend' => '1',
      ),
    ),
    'weiba' => 
    array (
      'normal' => 
      array (
        'weiba_post' => '1',
        'weiba_reply' => '1',
        'weiba_del' => '1',
        'weiba_del_reply' => '1',
        'weiba_edit' => '1',
        'weiba_apply_manage' => '1',
      ),
      'admin' => 
      array (
        'weiba_del' => '1',
        'weiba_edit' => '1',
        'weiba_global_top' => '1',
        'weiba_marrow' => '1',
        'weiba_top' => '1',
        'weiba_recommend' => '1',
      ),
    ),
    'channel' => 
    array (
      'admin' => 
      array (
        'channel_recommend' => '1',
      ),
    ),
    'vtask' => 
    array (
      'admin' => 
      array (
        'vtask_recommend' => '1',
      ),
    ),
  ),
  3 => 
  array (
    'core' => 
    array (
      'normal' => 
      array (
        'feed_view' => '1',
        'read_data' => '1',
        'invite_user' => '1',
        'send_message' => '1',
        'search_info' => '1',
        'comment_del' => '1',
        'feed_del' => '1',
        'feed_post' => '1',
        'feed_comment' => '1',
        'feed_report' => '1',
        'feed_share' => '1',
      ),
    ),
    'weiba' => 
    array (
      'normal' => 
      array (
        'weiba_post' => '1',
        'weiba_reply' => '1',
        'weiba_del' => '1',
        'weiba_del_reply' => '1',
        'weiba_edit' => '1',
        'weiba_apply_manage' => '1',
      ),
    ),
  ),
);
?>