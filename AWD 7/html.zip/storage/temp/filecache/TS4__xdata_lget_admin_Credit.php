<?php
return array (
  'set' => 
  array (
    'weibo' => 
    array (
      'add' => 
      array (
        'experience' => '5',
        'gold' => '2',
      ),
      'share' => 
      array (
        'experience' => '5',
        'gold' => '2',
      ),
      'reply' => 
      array (
        'experience' => '5',
        'gold' => '2',
      ),
    ),
  ),
  'level' => 
  array (
    0 => 
    array (
      'level' => 1,
      'name' => 'LV1',
      'image' => '72',
      'start' => '0',
      'end' => '10',
    ),
    1 => 
    array (
      'level' => 2,
      'name' => 'LV2',
      'image' => '73',
      'start' => '11',
      'end' => '100',
    ),
    2 => 
    array (
      'level' => 3,
      'name' => 'LV3',
      'image' => '74',
      'start' => '101',
      'end' => '500',
    ),
    3 => 
    array (
      'level' => 4,
      'name' => 'LV4',
      'image' => '75',
      'start' => '501',
      'end' => '1000',
    ),
    4 => 
    array (
      'level' => 5,
      'name' => 'LV5',
      'image' => '76',
      'start' => '1001',
      'end' => '5000',
    ),
    5 => 
    array (
      'level' => 6,
      'name' => 'LV6',
      'image' => '77',
      'start' => '5001',
      'end' => '6000',
    ),
    6 => 
    array (
      'level' => 7,
      'name' => 'LV7',
      'image' => '78',
      'start' => '6001',
      'end' => '7000',
    ),
    7 => 
    array (
      'level' => 8,
      'name' => 'LV8',
      'image' => '79',
      'start' => '7001',
      'end' => '8000',
    ),
    8 => 
    array (
      'level' => 9,
      'name' => 'LV9',
      'image' => '80',
      'start' => '8001',
      'end' => '9000',
    ),
    9 => 
    array (
      'level' => 10,
      'name' => 'LV10',
      'image' => '81',
      'start' => '9001',
      'end' => '1000000',
    ),
  ),
);
?>