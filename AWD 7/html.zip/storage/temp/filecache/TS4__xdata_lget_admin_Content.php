<?php
return array (
  'video_config' => 
  array (
    'ffmpeg_path' => '',
    'video_server' => '',
    'video_ext' => 'mp4',
    'video_size' => '20',
    'video_transfer_async' => '1',
  ),
);
?>