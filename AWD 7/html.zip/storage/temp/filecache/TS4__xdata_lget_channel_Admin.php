<?php
return array (
  'index' => 
  array (
    'is_audit' => '0',
    'default_category' => '40',
    'show_type' => '1',
  ),
);
?>