<?php
return array (
  'platformMeta' => '',
  'sina_wb_akey' => '2256583756',
  'bindemail' => 0,
);
?>