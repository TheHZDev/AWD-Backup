<?php
return array (
  'cachetype' => 'File',
  'cachesetting' => '',
);
?>