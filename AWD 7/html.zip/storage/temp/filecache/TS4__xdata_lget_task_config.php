<?php
return array (
  'task_switch' => '1',
);
?>