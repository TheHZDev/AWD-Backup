<?php
return array (
  'findPeopleConfig' => 
  array (
    'findPeople' => 
    array (
      0 => 'tag',
      1 => 'area',
      2 => 'verify',
      3 => 'official',
    ),
  ),
  'verifyConfig' => 
  array (
    'avoidSubmitByReturn' => '',
    'top_user' => '2',
  ),
);
?>