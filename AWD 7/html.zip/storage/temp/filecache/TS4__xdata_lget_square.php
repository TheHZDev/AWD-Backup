<?php
return array (
  'channel' => '0',
  'channelid' => '',
  'weiba' => '0',
  'weibaid' => '',
  'relateduser' => '0',
  'user_recommend_uid' => '',
  'editSubmit' => '1',
);
?>