<?php
return array (
  '' => 
  array (
    'weiba/Index/index' => true,
    'weiba/Index/detail' => true,
    'weiba/Index/postDetail' => true,
    'weiba/Index/postList' => true,
    'weiba/Index/weibaList' => true,
    'square/Index/index' => true,
    'people/Index/*' => true,
    'develop/Index/*' => true,
    'develop/Public/*' => true,
    'channel/Index/*' => true,
    'blog/Index/index' => true,
  ),
);
?>