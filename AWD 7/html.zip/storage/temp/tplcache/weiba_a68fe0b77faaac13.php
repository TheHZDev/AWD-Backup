<div class="right-box clearfix" model-node="related_list">
  <fieldset class="inter-line mb20">
    <a href="javascript:;" event-node="change_related_group" rel="0" event-args="uid=<?php echo ($uid); ?>&limit=<?php echo ($limit); ?>" id="changerelated_group" class="right"><i class="ico-refresh"></i></a>
    <legend class="inter-txt"><?php echo (getshort($title,20)); ?></legend>
  </fieldset>
  <ul model-node="related_ul_group" class="rect-circle">
  </ul>
  <a class="big-gray-btn more" href="<?php echo U('weiba/index/weibaList');?>">查看所有吧>></a>
</div>
<script type="text/javascript">
$(function (){
	setTimeout(function (){
		$('#changerelated_group').click();
		$('#changerelated_group').attr('rel', 1);
	},100)
});
// 事件绑定
M.addEventFns({
    // 换一换操作
    change_related_group: {
        click: function() {
            var args = M.getEventArgs(this);
            var _model = M.getModels('related_ul_group');
			var rel = $('#changerelated_group').attr('rel');
            $.post(U('widget/RelatedGroup/changeRelate'), {uid:args.uid, limit:args.limit, rel:rel}, function(data) {
                $(_model[0]).html(data);
                M($(_model)[0]);
            }, 'json');
            return false ;
        }
    }
});
</script>