<?php foreach ($userList as $userData) { ?>
<li class="mb20" style="margin-left:10px;">
	<div class="user left">
		<a href="<?php echo ($userData['space_url']); ?>" title="<?php echo ($userData['uname']); ?>" class="face">
			<img src="<?php echo ($userData['avatar_middle']); ?>" alt="<?php echo ($userData['uname']); ?>" event-node="face_card" uid="<?php echo ($userData['uid']); ?>">
		</a>
		<a class="name mb10" href="<?php echo ($userData['space_url']); ?>" title="<?php echo ($userData['uname']); ?>"><?php echo ($userData['uname']); ?></a>
	</div>
</li>
<?php } ?>