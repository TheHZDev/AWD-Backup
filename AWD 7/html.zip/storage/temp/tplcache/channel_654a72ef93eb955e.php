<?php echo W('SendWeibo',array('title'=>$title,'channel'=>'channel','isrefresh'=>'1','post_event'=>'post_feed_box','initHtml'=>$initHtml,'prompt'=>$prompt,'actions'=>$actions));?>

<input type="hidden" autocomplete="off" value="<?php echo ($cid); ?>" id="contribute" />

<script type="text/javascript">
var boxmodule = function() {
	M(document.getElementById('tsbox'));
};

if("undefined" == typeof(loadmore) || loadmore == 0) {
	var loadmore = '0';
	var loadnew = '0';	 
	core.loadFile(THEME_URL+'/js/module.weibo.js',boxmodule);
} else {
	boxmodule();
}
</script>