<div class="right-box clearfix login-status-box" model-node="">
        <h1 class="login-tit"><span class="login-tit-letter"><?php echo ($GLOBALS['ts']['site']['site_name']); ?></span>帐号登录</h1>
        <form id="ajax_login_form" method="POST" action="<?php echo U('public/Passport/doLogin');?>">
          <div class="login-info clearfix mb20">
            <div class="input-outer">
              <input type="text" name="login_email" class="text" onfocus=" if(this.value=='输入邮箱或用户名登录') this.value=''" onblur="if(this.value=='') this.value='输入邮箱或用户名登录'" value="输入邮箱或用户名登录"/>
            </div>
            <div class="input-outer">
              <label class="l-login login_password" style="color:#888;">输入密码</label>
              <input type="password" name="login_password" class="text" style=" position:absolute; z-index:100;" onfocus="$('.login_password').hide()" onblur="if(this.value=='') $('.login_password').show()" value=""/>
            </div>
            <div class="mb15">
              <a class="login-but mr20"  href="javascript:;" onclick="$('#ajax_login_form').submit();" >登录</a>
            </div>
            <div id="js_login_input" style="display:none" class="error-box"></div>
            <div class="no-account"><span class="left">没有账号，<a onclick="javascript:window.open('<?php echo U('public/Register');?>','_self')">点击注册</a></span><span class="right"><a href="<?php echo U('public/Passport/findPassword');?>">忘记密码？</a></span></div>
          </div>
          <div class="login-ft-wrap">
            <div class="login-ft">
            <div class="login-ft-head">使用第三方账号登录</div>
            <?php echo Addons::hook('login_input_footer');?>
          </div>
          </div>
        </form>
</div>
<script src="__THEME__/js/login.js" type="text/javascript"></script> 
<script type="text/javascript">
$(function(){
    //回车自动提交
    $('body').keypress(function(event){
        if(event.which==13){
        	$('#ajax_login_form').submit();
        }
    });
})
</script>