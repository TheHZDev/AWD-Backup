<?php if(($editable)  ==  "1"): ?><input event-node="input_date" event-args="min=<?php echo ($required); ?>&error=<?php echo L('PUBLIC_SELECT_DATE');?>" type="text" name="<?php echo ($name); ?>" value="<?php echo ($value); ?>" readonly="readonly" />
<?php else: ?>
<?php echo ($value); ?><?php endif; ?>