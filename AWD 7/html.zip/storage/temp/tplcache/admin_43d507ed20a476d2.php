<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="<?php echo APPS_URL;?>/admin/_static/admin.css" rel="stylesheet" type="text/css">
<script>
/**
 * 全局变量
 */
var SITE_URL  = '<?php echo SITE_URL; ?>';
var THEME_URL = '__THEME__';
var APPNAME   = '<?php echo APP_NAME; ?>';
var UPLOAD_URL ='<?php echo UPLOAD_URL;?>';
var MID		  = '<?php echo $mid; ?>';
var UID		  = '<?php echo $uid; ?>';
var _CP       = '<?php echo C("COOKIE_PREFIX");?>';
var SYS_VERSION = '<?php echo $site["sys_version"]; ?>';
// Js语言变量
var LANG = new Array();
</script>
<script type="text/javascript" src="__THEME__/js/jquery.js"></script>
<script type="text/javascript" src="__THEME__/js/core.js"></script>
<script src="__THEME__/js/module.js"></script>
<script src="__THEME__/js/common.js"></script>
<script src="__THEME__/js/module.common.js"></script>
<script src="__THEME__/js/module.weibo.js"></script>
<script type="text/javascript" src="<?php echo APPS_URL;?>/admin/_static/admin.js?t=11"></script>
<script type="text/javascript" src = "__THEME__/js/ui.core.js"></script>
<script type="text/javascript" src = "__THEME__/js/ui.draggable.js"></script>
<?php /* 非admin应用的后台js脚本统一写在  模板风格对应的app目录下的admin.js中*/
if(APP_NAME != 'admin' && file_exists(APP_PUBLIC_PATH.'/admin.js')){ ?>
<script type="text/javascript" src="<?php echo APP_PUBLIC_URL;?>/admin.js"></script>
<?php } ?>
<?php if(!empty($langJsList)) { ?>
<?php if(is_array($langJsList)): ?><?php $i = 0;?><?php $__LIST__ = $langJsList?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$vo): ?><?php ++$i;?><?php $mod = ($i % 2 )?><script src="<?php echo ($vo); ?>"></script><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>
<?php } ?>
</head>
<body>
<div id="container" class="so_main">
  <div class="page_tit"><?php echo L('PUBLIC_MAILTITLE_ADMIN');?> - <?php echo ($nodeInfo["nodeinfo"]); ?></div>


   <!-- START TAB框 -->
  <?php if(!empty($pageTab)): ?>
  <div class="tit_tab">
    <ul>
    <?php !$_REQUEST['tabHash'] && $_REQUEST['tabHash'] =  $pageTab[0]['tabHash']; ?>
    <?php if(is_array($pageTab)): ?><?php $i = 0;?><?php $__LIST__ = $pageTab?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$t): ?><?php ++$i;?><?php $mod = ($i % 2 )?><li><a href="<?php echo ($t["url"]); ?>&tabHash=<?php echo ($t["tabHash"]); ?>" <?php if($t['tabHash'] == $_REQUEST['tabHash']){ echo 'class="on"';} ?>><?php echo ($t["title"]); ?></a></li><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>
    </ul>
  </div>
  <?php endif; ?>
  <!-- END TAB框 -->

<div class="list">
  <form action="<?php echo U('admin/Config/saveConfigData');?>" method='POST'>
    <input type="hidden" class="s-txt" value="admin_Config" name="systemdata_list">
    <input type="hidden" class="s-txt" value="<?php echo ($systemdata_key); ?>" name="systemdata_key">
    <input type="hidden" class="s-txt" value="编辑SEO" name="pageTitle">
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
      
      <tr>
          <td width="100px">页面名称：</td>
          <td><label><?php echo ($name); ?></label></td>
          <input type="hidden" class="s-txt" value="<?php echo ($name); ?>" name="name">
      </tr>
      <tr>
          <td width="100px">标题：</td>
          <td><input id="form_title" class="s-txt" type="text" style="width:200px" value="<?php echo ($title); ?>" name="title"></td>
      </tr>
      <tr>
          <td>关键字：</td>
          <td><input type="text" style="width:200px" class="s-txt" value="<?php echo ($keywords); ?>" id="form_keywords" name="keywords"></td>
      </tr>
      <tr>
          <td>页面描述：</td>
          <td><textarea cols="80" rows="10" id="form_des" name="des"><?php echo ($des); ?></textarea></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
          <td><p><?php echo ($note); ?></p></td>
      </tr>
  </table>
    
    <div class="page_btm">
      <input name="node" value='<?php echo ($nodeInfo["node"]); ?>' type='hidden'>
      <input class="btn_b" value="<?php echo L('PUBLIC_SAVE');?>" name='sub' type="submit">
    </div>
  </form>
</div>
</div>
<?php if(!empty($onload)){ ?>
<script type="text/javascript">
/**
 * 初始化对象
 */
//表格样式
$(document).ready(function(){
    <?php foreach($onload as $v){ echo $v,';';} ?>
});
</script>
<?php } ?>

<?php if(ACTION_NAME == 'feed'): ?>
<script type="text/javascript">
core.loadFile(THEME_URL+'/js/plugins/core.weibo.js', function () {
	setTimeout(function () {
        // 重写方法
        core.weibo.showBigImage = function (a, b) {
            var $parent = $('#tr' + a).find('div[model-node="feed_list"]');
            $parent.find('div').each(function () {
                var relVal = $(this).attr('rel');
                if (relVal == 'small') {
                    $(this).hide();
                } else if (relVal == 'big') {
                    $(this).show();
                }
            });
        };
	}, 1000);
});
</script>
<?php endif; ?>
<?php if(!empty($appJsList) && is_array($appJsList)) { ?>
<?php foreach ($appJsList as $jsUrl) { ?>
<script type="text/javascript" src="<?php echo APP_PUBLIC_URL;?>/<?php echo ($jsUrl); ?>?v=<?php echo ($site["sys_version"]); ?>"></script>
<?php } ?>
<?php } ?>
</body>
</html>