<div id="set-data" data-title="系统消息"></div>
<div class="common">
    <ul class="notice">
      <?php if(is_array($list["data"])): ?><?php $i = 0;?><?php $__LIST__ = $list["data"]?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$vo): ?><?php ++$i;?><?php $mod = ($i % 2 )?><li <?php echo ($vo['is_read']==1?'':' class="unread"'); ?>><?php echo ($vo["body"]); ?>(<?php echo friendlyDate($vo['ctime']);?>)</li><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>
    </ul>
    <div class="pagelist"><?php echo ($list["html"]); ?></div>
</div>
<script>
$('.pagelist a').click(function(){
    if(typeof core.message.openUrl == 'function'){
        core.message.openUrl($(this).attr('href'), false);
    }
    return false;
});
</script>