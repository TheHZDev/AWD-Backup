<?php if(is_array($data)): ?><?php $i = 0;?><?php $__LIST__ = $data?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$vo): ?><?php ++$i;?><?php $mod = ($i % 2 )?><div class="box" id="feed_<?php echo ($vo["feed_id"]); ?>">

        <?php if($vo['type'] == 'postimage'): ?>
        <div class="pic">
            <ul><li><a onclick="core.weibo.showBigImage(<?php echo ($vo['feed_id']); ?>, 1);" href="javascript:;"><img width="<?php echo ($vo["width"]); ?>" height="<?php echo ($vo["height"]); ?>" src="<?php echo ($vo["attachInfo"]); ?>" alt="<?php echo (t($vo["body"])); ?>" /></a></li></ul>
            <?php if(count($vo['attach_id']) > 1): ?>
            <div class="pic-more" style="font-size:12px;"><a href="<?php echo U('public/Profile/feed', array('feed_id'=>$vo['feed_id'],'uid'=>$vo['user_info']['uid']));?>" target="_blank">点击查看全部图片</a></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if($vo['type'] == 'postvideo'): ?>
        <div class="pic">
            <a href="<?php echo U('public/Profile/feed', array('feed_id'=>$vo['feed_id'],'uid'=>$vo['user_info']['uid']));?>" target="_blank"></a>
            <ul><li><a href="<?php echo U('public/Profile/feed', array('feed_id'=>$vo['feed_id'],'uid'=>$vo['user_info']['uid']));?>"><img width="<?php echo ($vo["width"]); ?>" height="<?php echo ($vo["height"]); ?>" src="<?php echo ($vo["flashimg"]); ?>" alt="<?php echo (t($vo["body"])); ?>" /></a></li></ul>
        </div>
        <?php endif; ?>

        <div class="channel-list-l">
            <div class="channel-user-conntent mb10 feed_list">
                <?php if($vo['type'] == 'blog_post'): ?>
	                <?php if(!empty($vo['api_source']['pic_url'])): ?>
		                <div class="feed_img">
		                    <a href="<?php echo ($vo["api_source"]["source_url"]); ?>"><img src="<?php echo ($vo["api_source"]["pic_url"]); ?>" width="236" height="<?php echo ($vo["api_source"]["pic_height"]); ?>"/></a>
		                </div>
	                <?php endif; ?>
	                <div class="feed_txt">
	                    <p><img src="<?php echo ($vo["user_info"]["avatar_tiny"]); ?>" height="20px" width="20px" style="border-radius:50%;margin-top:-4px"/>&nbsp;<?php echo ($vo["user_info"]["space_link"]); ?>：发表了一篇知识到<a href="<?php echo ($vo["api_source"]["source_url"]); ?>">[<?php echo ($vo["api_source"]["category_name"]); ?>]</a></p>
	                    <h5><?php echo ($vo["api_source"]["title"]); ?></h5>
	                    <p><?php echo (getshort($vo["api_source"]["content"],138,'...')); ?><a href="<?php echo ($vo["api_source"]["source_url"]); ?>" target="_blank" class="f-red">&nbsp;&nbsp;查看全文>></a></p>
	                </div>
                <?php elseif($vo['type'] == 'weiba_post'): ?>
	                <?php if(!empty($vo['api_source']['pic_url']) && $vo['api_source']['pic_height'] != 0): ?>
		                <div class="feed_img">
		                    <a href="<?php echo ($vo["api_source"]["source_url"]); ?>"><img src="<?php echo ($vo["api_source"]["pic_url"]); ?>" width="236" height="<?php echo ($vo["api_source"]["pic_height"]); ?>"/></a>
		                </div>
	                <?php endif; ?>
	                <div class="feed_txt">
	                    <p><img src="<?php echo ($vo["user_info"]["avatar_tiny"]); ?>" height="20px" width="20px" style="border-radius:50%;margin-top:-4px"/>&nbsp;<?php echo ($vo["user_info"]["space_link"]); ?>：发表了一篇帖子到<a href="<?php echo ($vo["api_source"]["weiba_url"]); ?>">[<?php echo ($vo["api_source"]["weiba_name"]); ?>]</a></p>
	                    <h5><a href="<?php echo ($vo["api_source"]["source_url"]); ?>"><?php echo ($vo["api_source"]["title"]); ?></a></h5>
	                    <p><?php echo (getshort($vo["api_source"]["content"],138,'...')); ?><a href="<?php echo ($vo["api_source"]["source_url"]); ?>" target="_blank" class="f-red">&nbsp;&nbsp;查看全文>></a></p>
	                </div>
                <?php elseif($vo['type'] == 'event_post'): ?>
	                <?php if(!empty($vo['api_source']['pic_url'])): ?>
		                <div class="feed_img">
		                    <a href="<?php echo ($vo["api_source"]["source_url"]); ?>"><img src="<?php echo ($vo["api_source"]["pic_url"]); ?>" width="236" /></a>
		                </div>
	                <?php endif; ?>
                <div class="feed_txt">
                    <p><img src="<?php echo ($vo["user_info"]["avatar_tiny"]); ?>" height="20px" width="20px" style="border-radius:50%;margin-top:-4px"/>&nbsp;<?php echo ($vo["user_info"]["space_link"]); ?>：发起了一个活动</p>
                    <h5><?php echo ($vo["api_source"]["title"]); ?></h5>
                    <p>活动时间：<?php echo (date('y-m-d H:i:s', $vo["api_source"]["start_time"])); ?>至<?php echo (date('y-m-d H:i:s', $vo["api_source"]["end_time"])); ?></p>
                    <p>活动地点：<?php echo ($vo["api_source"]["address"]); ?></p>
                    <p>发起人：<?php echo ($vo["api_source"]["source_user_info"]["uname"]); ?></p>
                    <p>参与人数：(<?php echo ($vo["api_source"]["join_count"]); ?>)</p>
                    <p><a href="<?php echo ($vo["api_source"]["source_url"]); ?>">查看详情>></a></p>
                </div>
                <?php elseif($vo['type'] == 'vote_post'): ?>
	                <?php if(!empty($vo['api_source']['pic_url'])): ?>
		                <div class="feed_img">
		                    <a href="<?php echo ($vo["api_source"]["source_url"]); ?>"><img src="<?php echo ($vo["api_source"]["pic_url"]); ?>" width="236" /></a>
		                </div>
	                <?php endif; ?>
                <div class="feed_txt">
                    <p><img src="<?php echo ($vo["user_info"]["avatar_tiny"]); ?>" height="20px" width="20px" style="border-radius:50%;margin-top:-4px"/>&nbsp;<?php echo ($vo["user_info"]["space_link"]); ?>：发起了一个投票</p>
                    <h5><?php echo ($vo["api_source"]["title"]); ?></h5>
                    <?php if(is_array($vo["api_source"]["vote_opts"])): ?><?php $i = 0;?><?php $__LIST__ = array_slice($vo["api_source"]["vote_opts"],0,4) ?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$v): ?><?php ++$i;?><?php $mod = ($i % 2 )?><p><span class="square"></span><?php echo getShort($v['name'], 23, '...');?></p><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>
                    <p>发起时间：<?php echo (date('y-m-d H:i', $vo["api_source"]["ctime"])); ?></p>
                    <p>参与人数：(<?php echo ($vo["api_source"]["vote_num"]); ?>)</p>
                    <p><a href="<?php echo ($vo["api_source"]["source_url"]); ?>">参与投票>></a></p>
                </div>
                <?php elseif($vo['type'] == 'photo_post'): ?>
	                <?php if(!empty($vo['api_source']['cover_image_path'])): ?>
		                <div class="feed_img">
		                    <a href="<?php echo ($vo["api_source"]["source_url"]); ?>"><img src="<?php echo ($vo["api_source"]["cover_image_path"]); ?>" width="<?php echo ($vo["width"]); ?>" height="<?php echo ($vo["height"]); ?>"/></a>
		                </div>
	                <?php endif; ?>
	                <div class="feed_txt">
	                    <p><img src="<?php echo ($vo["user_info"]["avatar_tiny"]); ?>" height="20px" width="20px" style="border-radius:50%;margin-top:-4px"/>&nbsp;<?php echo ($vo["user_info"]["space_link"]); ?>：上传了<?php echo ($vo["api_source"]["photo_upload_count"]); ?>张图片到相册<a href="<?php echo ($vo["api_source"]["album_url"]); ?>">[<?php echo ($vo["api_source"]["title"]); ?>]</a></p>
	                </div>
                <?php else: ?>
	                <div class="feed_txt">
	                    <p><img src="<?php echo ($vo["user_info"]["avatar_tiny"]); ?>" height="20px" width="20px" style="border-radius:50%;margin-top:-4px"/>&nbsp;<?php echo ($vo["user_info"]["space_link"]); ?>：<?php echo (format($vo["body"],true)); ?></p>
	                
	                <?php if($vo['type'] == 'postfile'): ?>
		                <ul>
		                    <?php if(is_array($vo["attachInfo"])): ?><?php $i = 0;?><?php $__LIST__ = $vo["attachInfo"]?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$v): ?><?php ++$i;?><?php $mod = ($i % 2 )?><li>
		                            <i class="ico-<?php echo ($v["extension"]); ?>-small"></i>
		                            <a href="<?php echo U('widget/Upload/down',array('attach_id'=>$v['attach_id']));?>" title="<?php echo ($v["name"]); ?>"><?php echo (getshort($v["name"], 10, '...')); ?></a>
		                        </li><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>
		                </ul>
	                <?php endif; ?>
                <?php endif; ?>
                </div>
            </div>

            <div class="channel-user-share">
                <?php echo W('FeedManage',array('feed_id'=>$vo['feed_id'],'feed_uid'=>$vo['user_info']['uid'],'manage_class'=>'right f9 dp-cs'));?>
			<span>
				<?php if(in_array('repost',$weibo_premission) && CheckPermission('core_normal','feed_share')): ?>
                <?php $vo['app_row_id'] == 0 && $vo['app_row_id'] = $vo['feed_id']; ?>
				<a event-node="share" event-args="sid=<?php echo ($vo["app_row_id"]); ?>&stable=<?php echo ($vo["app_row_table"]); ?>&curtable=feed&curid=<?php echo ($vo["feed_id"]); ?>&initHTML=&appname=public&cancomment=1" href="javascript:;"><i class="ico-forward"></i>(<?php echo ($vo["repost_count"]); ?>)</a>
				<?php endif; ?>
				<?php echo W('Collection',array('sid'=>$vo['feed_id'],'stable'=>'feed','sapp'=>$vo['app'],'ico'=>'ico-favorites','tpl'=>'ico'));?>
				<?php if(in_array('comment',$weibo_premission)): ?>
				<a href="<?php echo U('public/Profile/feed', array('feed_id'=>$vo['feed_id'],'uid'=>$vo['user_info']['uid']));?>"><i class="ico-comment"></i>(<?php echo ($vo["comment_count"]); ?>)</a>
				<?php endif; ?>
			</span>
            </div>
        </div>

    </div><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>