<?php if(($editable)  ==  "1"): ?><?php $list = explode('|',$default_value); ?>
<select name="<?php echo ($name); ?>">
	<?php if(is_array($list)): ?><?php $i = 0;?><?php $__LIST__ = $list?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$v): ?><?php ++$i;?><?php $mod = ($i % 2 )?><option name="<?php echo ($v); ?>"<?php if($value==$v){ ?> selected="selected"<?php } ?>><?php echo ($v); ?></option><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>
</select>
<?php else: ?>
<?php echo ($value); ?><?php endif; ?>