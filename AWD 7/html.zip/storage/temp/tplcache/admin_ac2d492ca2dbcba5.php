<style type="text/css">
.ico-top, .ico-btm {background: url("__THEME__/admin/image/ico_top_btm.gif") no-repeat scroll 0 0 transparent;height:14px;width:12px;}
.ico-top, .ico-btm {display: inline-block;vertical-align: middle;}
.ico-top {background-position: -12px 0;}
.ico-btm {background-position: -24px 0;}
.ico-top:hover {background-position: 0 0;}
.ico-btm:hover {background-position: -35px 0;}
</style>

<div class="Toolbar_inbox">
  <a href="<?php echo Addons::adminPage('addFeedTop');?>" class="btn_a"><span>添加置顶</span></a>
</div>
<div class="list">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <th class="line_l">标题</th>
      <th class="line_l">置顶分享ID</th>
      <th class="line_l" width="50%">内容</th>
      <th class="line_l">是否置顶</th>
      <th class="line_l">创建时间</th>
      <th class="line_l">操作</th>
    </tr>
    <?php if(is_array($list["data"])): ?><?php $i = 0;?><?php $__LIST__ = $list["data"]?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$vo): ?><?php ++$i;?><?php $mod = ($i % 2 )?><tr overstyle='on' id="ad_space_<?php echo ($vo["id"]); ?>" rel="<?php echo ($vo["id"]); ?>">
      <td><?php echo ($vo["title"]); ?></td>
	  <td><?php echo ($vo["feed_id"]); ?></td>
      <td><?php echo (format($vo["feed_info"]["body"],true)); ?></td>
      <td><?php if(($vo["status"])  ==  "0"): ?>是<?php else: ?>否<?php endif; ?></td>
      <td><?php echo (date("Y-m-d H:i",$vo["ctime"])); ?></td>
      <td>
	    <a href="<?php echo Addons::adminPage('editFeedTop', array('id'=>$vo['id']));?>">编辑</a>
		&nbsp;
		<?php if($vo['status'] == 1){ ?>
        <a href="javascript:;" onclick="FeedTop('<?php echo ($vo["id"]); ?>')">置顶</a>
		<?php }else{ ?>
		<a href="javascript:;" onclick="delFeedTop('<?php echo ($vo["id"]); ?>')">取消置顶</a>
		<?php } ?>
		&nbsp;
		<a href="javascript:;" onclick="del('<?php echo ($vo["id"]); ?>')">删除</a>
      </td>
    </tr><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>
  </table>
</div>
<div class="Toolbar_inbox">
  <a href="<?php echo Addons::adminPage('addFeedTop');?>" class="btn_a"><span>添加置顶</span></a>
</div>

<script type="text/javascript">
/**
 * 鼠标移动表格效果
 * @return void
 */
$(document).ready(function() {
  $("tr[overstyle='on']").hover(
    function () {
      $(this).addClass("bg_hover");
    },
    function () {
      $(this).removeClass("bg_hover");
    }
  );  
});

var delFeedTop = function(id)
{
  // 验证数据
  if(id == '') {
    ui.error('请选择取消置顶的分享');
    return false;
  }
  // 取消置顶操作
 $.post("<?php echo Addons::adminUrl('doDelFeedTop');?>", {id:id}, function(res) {
      if(res.status == 1) {
        ui.success(res.info);
		setTimeout("location.reload()",'1000');
      } else {
        ui.error(res.info);
      }
      return false;
    }, 'json');
    return false;
};

var del= function(id)
{
  // 验证数据
  if(id == '') {
    ui.error('请选择即将要删除的置顶分享');
    return false;
  }
  // 删除操作
 $.post("<?php echo Addons::adminUrl('doDel');?>", {id:id}, function(res) {
      if(res.status == 1) {
        ui.success(res.info);
		setTimeout("location.reload()",'1000');
      } else {
        ui.error(res.info);
      }
      return false;
    }, 'json');
    return false;
};

var FeedTop = function(id)
{
  // 验证数据
  if(id == '') {
    ui.error('请选择置顶的分享');
    return false;
  }
  // 取消置顶操作
 $.post("<?php echo Addons::adminUrl('doFeedTop');?>", {id:id}, function(res) {
      if(res.status == 1) {
        ui.success(res.info);
		setTimeout("location.reload()",'1000');
      } else {
        ui.error(res.info);
      }
      return false;
    }, 'json');
    return false;
};

</script>