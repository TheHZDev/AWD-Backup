<dt class="face">
	<a title="<?php echo ($user_info["uname"]); ?>" href="<?php echo ($user_info["space_url"]); ?>"><img src="<?php echo ($user_info["avatar_middle"]); ?>" /></a><?php if($user_info['group_icon_only']['user_group_icon_url']): ?><a href="javascript:;" title="<?php echo ($user_info['group_icon_only']['user_group_name']); ?>" class="group_icon_only"><img alt="<?php echo ($user_info['group_icon_only']['user_group_name']); ?>" src="<?php echo ($user_info['group_icon_only']['user_group_icon_url']); ?>" ></a><?php endif; ?>
</dt>
<dd class="content">
	<?php echo W('FeedManage',array('feed_id'=>$feed_id,'feed_uid'=>$uid));?>
	<em class="hover right">
		<?php if(($actions["delete"])  ==  "true"): ?><a href="javascript:void(0)" event-node ='delFeed' event-args='feed_id=<?php echo ($feed_id); ?>&uid=<?php echo ($uid); ?>'><?php echo L('PUBLIC_STREAM_DELETE');?></a>&nbsp;&nbsp;<?php endif; ?>
	</em>
	<p class="hd"><?php echo ($title); ?></p>
	
	<div class="contents clearfix"><?php if(($body)  !=  ""): ?><?php echo (format($body,true)); ?><?php endif; ?></div>
	<p class="info">
		<span class="right">
        
			<?php if(in_array('comment',$weibo_premission)): ?>
			<?php if(($actions["comment"])  ==  "true"): ?><?php $cancomment_old = empty($app_row_id) ? 0 : 1; ?>
			<?php $cancomment = intval(CheckPermission('core_normal','feed_comment')); ?>
			<a event-node="comment" href="javascript:void(0)" event-args='row_id=<?php echo ($feed_id); ?>&app_uid=<?php echo ($uid); ?>&to_comment_id=0&to_uid=0&app_name=<?php echo ($app); ?>&table=feed&app_row_id=<?php echo ($app_row_id); ?>&app_row_table=<?php echo ($app_row_table); ?>&cancomment=<?php echo ($cancomment); ?>&cancomment_old=<?php echo ($cancomment_old); ?>'><?php echo L('PUBLIC_STREAM_COMMENT');?></a><?php endif; ?>
			<?php endif; ?>
            <?php if(in_array('repost',$weibo_premission)): ?>
			<i class="vline">|</i>
			<?php if(($actions["repost"])  ==  "true"): ?><?php if(CheckPermission('core_normal','feed_share')){ ?>
			<?php $sid = !empty($app_row_id)? $app_row_id : $feed_id; ?>
			<?php echo W('Share',array('sid'=>$sid,'stable'=>$app_row_table,'initHTML'=>'','current_table'=>'feed','current_id'=>$feed_id,'nums'=>$repost_count,'appname'=>$app,'is_repost'=>$is_repost,'enode'=>'open_share'));?>
			<?php } ?><?php endif; ?>
			<?php endif; ?>
			<?php if(($actions["favor"])  ==  "true"): ?><i class="vline">|</i>
			<?php echo W('Collection',array('sid'=>$feed_id,'stable'=>'feed','sapp'=>$app));?><?php endif; ?><i class="vline">|</i>
            <?php echo W('Digg', array('feed_id'=>$feed_id, 'digg_count'=>0, 'diggArr'=>array()));?>
		</span>
		<span>
			<a class="date" date="<?php echo time();?>" href="<?php echo U('public/Profile/feed', array('feed_id'=>$feed_id, 'uid'=>$uid));?>">
			<em>刚刚</em><em style="display:none;">查看详情</em>
			</a>
			<span><?php echo ($from); ?></span>
			<?php if(CheckPermission('core_normal','feed_del')){ ?>
			<?php } ?>
		</span>
	</p>
    <div class="infopen"><div class="trigon"></div></div>
    <div class="forward_box">
    	<div class="bdsharebuttonbox share_feedlist clearfix" data-tag="share_feedlist">
            <a href="javascript:;" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博">新浪微博</a>
            <a href="javascript:;" class="bds_weixin" data-cmd="weixin" title="分享到微信">微信</a>
            <a href="javascript:;" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博">腾讯微博</a>
            <a href="javascript:;" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间">QQ空间</a>
            <a href="javascript:;" class="bds_renren" data-cmd="renren" title="分享到人人网">人人网</a>
            <a href="javascript:;" class="bds_douban" data-cmd="douban" title="分享到豆瓣网">豆瓣网</a>
            <?php echo W('Share',array('sid'=>$sid,'stable'=>$app_row_table,'initHTML'=>'','current_table'=>'feed','current_id'=>$feed_id,'nums'=>$repost_count,'appname'=>$app,'is_repost'=>$is_repost, 'text'=>'我的主页', 'title'=> '分享到我的主页', 'class'=>'repost'));?>
            <a href="javascript:;" class="bds_count" data-cmd="count"></a>
        </div>
    </div>
	<div model-node="comment_detail" class="repeat clearfix" style="display:none;"></div>
</dd>
<dt class="xline"></dt>