<?php

echo replaceUrl(t($body));