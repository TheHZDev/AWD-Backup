<?php $navs = '';
    foreach($types as $k => $v){
        $navs .= '<a href="'.U('public/WebMessage/zan',array('type'=>$k,'ismy'=>(int)$ismy)).'" class="boxopenurl'.($type==$k?' current':'').'">'.$v.'</a>';
    }
    $btn = '<a href="'.U('public/WebMessage/zan').'" class="link boxopenurl'.(!$ismy?' current':'').'">收到的赞</a><a href="'.U('public/WebMessage/zan', array('ismy'=>1)).'" class="link boxopenurl'.($ismy?' current':'').'">发出的赞</a>'; ?>
<div id="set-data" data-title="点赞" data-navs='<?php echo ($navs); ?>' data-btn='<?php echo ($btn); ?>'></div>
<div class="common">
    <?php if($list['data']): ?>
    <ul class="comment">
      <?php if(is_array($list["data"])): ?><?php $i = 0;?><?php $__LIST__ = $list["data"]?><?php if( count($__LIST__)==0 ) : echo "" ; ?><?php else: ?><?php foreach($__LIST__ as $key=>$vo): ?><?php ++$i;?><?php $mod = ($i % 2 )?><li>
        <div class="face"><a href="<?php echo ($vo["space"]); ?>"><img src="<?php echo ($vo["face"]); ?>" /><?php if(!$ismy && $i <= $unreadCount[$type]): ?><i></i><?php endif; ?></a></div>
        <div class="detail">
          <div class="name"><a href="<?php echo ($vo["space"]); ?>"><?php echo ($vo["uname"]); ?></a><span><?php echo (friendlydate($vo["ctime"])); ?></span></div>
          <div class="ctzan <?php echo ($ismy?'click_zan':''); ?>" data-id="<?php echo ($vo["data_id"]); ?>" data-type="<?php echo ($vo["data_type"]); ?>"><i></i></div>
        </div>
        <div class="link"><a href="<?php echo ($vo['source_url']?$vo['source_url']:'javascript:;'); ?>"><?php if($vo['source_image']): ?><img src="<?php echo ($vo["source_image"]); ?>" /><?php if($vo['source_isvideo']): ?><i></i><?php endif; ?><?php else:echo $vo['source_content'];endif; ?></a></div>
      </li><?php endforeach; ?><?php endif; ?><?php else: echo "" ;?><?php endif; ?>
    </ul>
    <div class="pagelist"><?php echo ($list["html"]); ?></div>
    <?php else: ?>
    <div class="empty-list"><?php echo ($ismy?'你还没有点过赞哦~':'你还没有收到点赞哦~'); ?></div>
    <?php endif; ?>
</div>
<script>
(function(){
    core.message.setMessageNumber('zan', '<?php echo ($surplusCount); ?>');
})();
$('.boxopenurl,.pagelist a').click(function(){
    if(typeof core.message.openUrl == 'function'){
        core.message.openUrl($(this).attr('href'), false);
    }
    return false;
});
</script>