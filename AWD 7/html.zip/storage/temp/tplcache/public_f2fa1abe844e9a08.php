<?php if(($editable)  ==  "1"): ?><input event-node="input_text" event-args="min=<?php echo ($required); ?>&error=请输入<?php echo ($field_name); ?>。" type="text" name="<?php echo ($name); ?>" value="<?php echo ($value); ?>" />
<?php else: ?>
<?php echo ($value); ?><?php endif; ?>