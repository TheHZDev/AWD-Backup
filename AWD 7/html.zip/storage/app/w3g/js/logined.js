/**
 * Created by boooo on 14-2-8.
 */
if(!window.TS){var TS;}
TS.cache.logged=true;