<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/11/22
 */
return [
    'Article list' => '文章列表',
    'No search found' => '没有找到搜索内容',
    'Search' => '搜索',
    'Message content must be filled out' => '留言内容必须填写',
    'The e-mail format is incorrect' => '邮箱格式错误'
];