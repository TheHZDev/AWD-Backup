<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/9/29
 */
define('APP_PATH', __DIR__ . '/application/');
require __DIR__ . '/catfish/start.php';