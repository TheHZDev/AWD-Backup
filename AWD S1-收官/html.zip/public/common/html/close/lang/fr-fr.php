<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'The site needs to take a break!' => 'Site Web ont besoin d\'une pause!',
    'In the system maintenance, please come again tomorrow' => 'La maintenance du système, s\'il vous plaît revenez demain',
    'Temporarily closed' => 'fermeture temporaire'
];