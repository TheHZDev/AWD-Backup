<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'The site needs to take a break!' => 'ウェブサイトには休憩が必要！',
    'In the system maintenance, please come again tomorrow' => 'システムメンテナンス、明日戻って来てください',
    'Temporarily closed' => '一時的に閉鎖'
];