<?php
//000000003600a:1:{s:5:"menu1";a:2:{i:0;a:6:{s:2:"id";s:1:"1";s:9:"parent_id";s:1:"0";s:5:"label";s:6:"首页";s:6:"target";s:5:"_self";s:4:"href";s:21:"/index.php/index.html";s:4:"icon";s:0:"";}i:1;a:7:{s:2:"id";s:1:"2";s:9:"parent_id";s:1:"0";s:5:"label";s:5:"Bugku";s:6:"target";s:6:"_blank";s:4:"href";s:22:"https://ctf.bugku.com/";s:4:"icon";s:0:"";s:8:"zidingyi";s:1:"1";}}}
?>