<?php
//000000003600a:12:{s:7:"rewrite";i:0;s:13:"notAllowLogin";i:0;s:10:"closeSlide";i:0;s:11:"openMessage";i:1;s:12:"closeComment";i:0;s:4:"datu";i:0;s:14:"everyPageShows";i:10;s:3:"ico";s:59:"/data/uploads/20210724/081b616226f37c909c9b4a9f7ea1f112.ico";s:10:"timeFormat";s:11:"Y-m-d H:i:s";s:6:"guanbi";i:0;s:12:"closeSitemap";i:0;s:8:"closeRSS";i:0;}
?>