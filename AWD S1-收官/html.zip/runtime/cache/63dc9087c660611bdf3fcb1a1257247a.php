<?php
//000000003600a:1:{i:0;s:12:"announcement";}
?>