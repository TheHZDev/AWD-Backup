<?php
//000000003600a:1:{i:0;a:4:{s:6:"plugin";s:12:"announcement";s:5:"pname";s:12:"Announcement";s:6:"isShow";b:1;s:12:"jurisdiction";i:3;}}
?>