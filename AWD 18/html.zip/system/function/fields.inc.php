<?php
$_fields=array (
  'option' => '下拉菜单',
  'radio' => '单选按钮',
  'checkbox' => '多选按钮',
  'editor' => '编辑器',
  'image' => '图片',
  'moreimage' => '多图上传',
  'files' => '附件',
  'text' => '单行文本',
  'textarea' => '多行文本',
);
?>