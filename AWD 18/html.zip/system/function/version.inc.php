<?php
define('CMS_VERSION','v 3.0.1');
define('CMS_RELEASE','201300916');
?>