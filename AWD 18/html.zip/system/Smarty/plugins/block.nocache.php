<?php
function smarty_block_nocache($param,$content,$smarty){
	return $content;
}
?>