<?php
$_config=array (
  'name' => '幻灯片模块',
  'folder' => 'flash',
  'author' => 'XDcms',
  'url' => 'http://www.xdcms.cn',
  'time' => '2012-06-18',
);
?>