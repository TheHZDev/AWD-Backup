<?php
$_config=array (
  'name' => '会员模块',
  'folder' => 'member',
  'author' => 'XDcms',
  'url' => 'http://www.xdcms.cn',
  'time' => '2012-04-07',
);
?>