<?php
$_config=array (
  'name' => '客服QQ模块',
  'folder' => 'qq',
  'author' => 'XDcms',
  'url' => 'http://www.xdcms.cn',
  'time' => '2012-06-18',
);
?>