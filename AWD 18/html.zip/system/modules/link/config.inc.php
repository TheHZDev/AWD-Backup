<?php
$_config=array (
  'name' => '友情链接模块',
  'folder' => 'link',
  'author' => 'XDcms',
  'url' => 'http://www.xdcms.cn',
  'time' => '2012-06-18',
);
?>