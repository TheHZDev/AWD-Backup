<?php
$_config=array (
  'name' => '独立表单模块',
  'folder' => 'form',
  'author' => 'XDcms',
  'url' => 'http://www.xdcms.cn',
  'time' => '2012-06-18',
);
?>