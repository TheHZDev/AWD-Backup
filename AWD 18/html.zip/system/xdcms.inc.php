<?php
 define('CMS_URL','/');
 define('TP_FOLDER','xdcms');
 define('TP_CACHE',false);
?>