<?php /* Smarty version Smarty-3.0.8, created on 2021-06-04 07:52:49
         compiled from "/www/admin/localhost_80/wwwroot/system/templates/admin/left.html" */ ?>
<?php /*%%SmartyHeaderCode:10718435960b96b51067e93-17584107%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'af1d355e0abf9f6f6865625b3bd953e97b2e1708' => 
    array (
      0 => '/www/admin/localhost_80/wwwroot/system/templates/admin/left.html',
      1 => 1347934514,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10718435960b96b51067e93-17584107',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>XDcms企业管理系统--后台管理</title>
<link href="admin/css/left.css" rel="stylesheet" type="text/css" />
<script src="admin/js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="admin/js/MenuTree.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		$('#menu').menuTree();
	});
</script>
</head>

<body>
<div class="top"></div>
<div id="menu" class="menuTree">
<?php echo $_smarty_tpl->getVariable('menu')->value;?>

</div>
</body>
</html>
