<?php /* Smarty version Smarty-3.0.8, created on 2021-06-04 07:52:48
         compiled from "/www/admin/localhost_80/wwwroot/system/templates/admin/index.html" */ ?>
<?php /*%%SmartyHeaderCode:168864989660b96b50de9604-10922371%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92e2ca5c8d1e9cad1b07799124560e3786bcf632' => 
    array (
      0 => '/www/admin/localhost_80/wwwroot/system/templates/admin/index.html',
      1 => 1347808296,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '168864989660b96b50de9604-10922371',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $_smarty_tpl->getVariable('config')->value["sitename"];?>
后台管理系统_Powered by XDcms</title>
<link rel="stylesheet" type="text/css" href="css/css.css">
</head>
<frameset rows="119,*" cols="*" frameborder="no" border="0" framespacing="0">
  <frame src="index.php?m=xdcms&c=index&f=top&l=<?php echo $_smarty_tpl->getVariable('lang')->value;?>
" name="top" scrolling="No" noresize="noresize" id="top" title="top" />
  <frameset cols="197,*" frameborder="no" border="0" framespacing="0">
    <frame src="index.php?m=xdcms&c=index&f=left&l=<?php echo $_smarty_tpl->getVariable('lang')->value;?>
" name="left" scrolling="no" noresize="noresize" id="left" title="left" style="margin:0px;padding:0px;border:0px;"/>
    <frame src="index.php?m=xdcms&c=index&f=main&l=<?php echo $_smarty_tpl->getVariable('lang')->value;?>
" name="main" id="main" title="main" />
  </frameset>
</frameset>
<noframes><body>
</body></noframes>
</html>
