<?php /* Smarty version Smarty-3.0.8, created on 2021-06-04 07:52:49
         compiled from "/www/admin/localhost_80/wwwroot/system/templates/admin/main.html" */ ?>
<?php /*%%SmartyHeaderCode:199352815360b96b5102a0d0-16785425%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '341e7522c8ac5185ecfe0a19d327570bfd83eeb5' => 
    array (
      0 => '/www/admin/localhost_80/wwwroot/system/templates/admin/main.html',
      1 => 1377831752,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '199352815360b96b5102a0d0-16785425',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include '/www/admin/localhost_80/wwwroot/system/Smarty/plugins/modifier.date_format.php';
?><?php $_template = new Smarty_Internal_Template("admin/header.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<div class="xdcms_copy">
	<div class="weather"></div>
    <h5><?php echo $_smarty_tpl->getVariable('adminuser')->value;?>
 您好,欢迎使用XDcms企业网站管理系统,您目前使用的是免费版<span>(www.xdcms.cn)</span> <a href="http://www.xdcms.cn/buy/buycom/" target="_blank">购买授权</a> <a href="http://www.iszzz.com" target="_blank">官方论坛</a></h5>
</div>
<div class="xdcms_index_log">服务器所在时间：<?php echo smarty_modifier_date_format($_smarty_tpl->getVariable('server')->value["time"],'%Y-%m-%d %H:%M:%S');?>
</div>
<ul class="quick">
	<li><a href="index.php?m=xdcms&c=creathtml&f=update_index"><img src="admin/images/quick_1.gif" /><br />生成首页</a></li>
    <li><a href="index.php?m=xdcms&c=language"><img src="admin/images/quick_2.gif" /><br />SEO设置</a></li>
    <li><a href="index.php?m=xdcms&c=category"><img src="admin/images/quick_3.gif" /><br />栏目管理</a></li>
    <li><a href="index.php?m=xdcms&c=setting"><img src="admin/images/quick_4.gif" /><br />网站设置</a></li>
    <li><a href="index.php?m=xdcms&c=data"><img src="admin/images/quick_5.gif" /><br />数据备份</a></li>
    <li><a href="index.php?m=xdcms&c=update_cache"><img src="admin/images/quick_6.gif" /><br />更新缓存</a></li>
</ul>
<div class="xdcms_manage_sumbit"><a href="index.php?m=xdcms&c=index&f=left&id=3" target="left">进入网站内容管理</a></div>
<div class="xdcms_manage_sumbit"><a href="http://www.iszzz.com/thread-300-1-1.html" target="_blank">学习管理视频教程</a></div>
<div class="clear"></div>
<div class="xdcms_copy t30">
	<div class="lamp"></div>
    <h5>Xdcms开发介绍</h5>
</div>
<ul class="xdcms_about">
	<li>软件版本：<?php echo $_smarty_tpl->getVariable('server')->value["cms_version"];?>
 <a href="http://www.iszzz.com/thread-323-1-1.html" target="_blank"><font color="#FF0000">[点击查看最新版本]</font></a></li>
    <li>插件开发：XDcms插件开发小组</li>
    <li>授权购买：QQ<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=771352113&site=qq&menu=yes">771352113</a> </li>
    <li>产品开发：南宁旭东网络科技有限公司<a href="http://www.xdcms.cn" target="_blank" class="sumbit_link">访问官网</a> </li>
    <li><a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=6874dd2400d8c25d6fc1335c735ee2c1e04f44a47aee7dcb961a4bc92c1cc34b"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="XDcms①" title="XDcms①"></a></li>
</ul>
<div class="xdcms_data">
	<h5>版权声明：《XDcms企业网站管理系统》系南宁旭东网络技术有限公司自主开发的产品，拥有该软件的所有权利，未经授权不得用于任何商业用途！</h5>
    <dl>
    	<dd>PHP程序版本：<?php echo $_smarty_tpl->getVariable('server')->value["version"];?>
</dd>
        <dd>Mysql版本：<?php echo $_smarty_tpl->getVariable('server')->value["mysql_version"];?>
</dd>
        <dd>最大上传限制：<?php echo $_smarty_tpl->getVariable('server')->value["upload"];?>
</dd>
    </dl>
</div>
<script src="<?php echo $_smarty_tpl->getVariable('notice')->value;?>
"></script>
</body>
</html>
