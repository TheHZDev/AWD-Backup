<?php /* Smarty version Smarty-3.0.8, created on 2021-06-04 07:52:49
         compiled from "/www/admin/localhost_80/wwwroot/system/templates/admin/header.html" */ ?>
<?php /*%%SmartyHeaderCode:95184378560b96b5104bca9-23835799%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '85f57e2ef58295a584d41e047aeea8a30a436f68' => 
    array (
      0 => '/www/admin/localhost_80/wwwroot/system/templates/admin/header.html',
      1 => 1346037152,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '95184378560b96b5104bca9-23835799',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>XDcms企业管理系统--后台管理</title>
<link rel="stylesheet" type="text/css" href="admin/css/main.css">
<script type="text/javascript" src="admin/js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="admin/js/admin.js"></script>
<script type="text/javascript" src="admin/js/block.js"></script>
<script type="text/javascript" src="admin/js/jquery.simplemodal.js"></script>
<script type="text/javascript" src="admin/js/popup.js"></script>
</head>

<body>
<div id='confirm'>
	<div class='header'><span>提示信息！</span></div>
	<p class='message'></p>
	<div class='buttons'>
		<div class='no simplemodal-close'>取消</div><div class='yes'>确定</div>
	</div>
</div>