<?php /* Smarty version Smarty-3.0.8, created on 2021-06-04 08:01:20
         compiled from "/www/admin/localhost_80/wwwroot/system/templates/xdcms/member/left.html" */ ?>
<?php /*%%SmartyHeaderCode:73352158860b96d50833a00-84456858%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '768f34848cb02eec4cab71c3070c320fae3117bb' => 
    array (
      0 => '/www/admin/localhost_80/wwwroot/system/templates/xdcms/member/left.html',
      1 => 1346036626,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '73352158860b96d50833a00-84456858',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
    <!-- 二级导航 -->
    <div id="body3_l">
        <div class="body3_l1">会员中心</div>
        <div class="body3_l2">
            <ul>
                <li><div class="body3_l2_t">&nbsp;<a href="/index.php?m=member">会员中心</a></div></li>
                <li><div class="body3_l2_t">&nbsp;<a href="/index.php?m=member&f=edit">修改资料</a></div></li>
                <li><div class="body3_l2_t">&nbsp;<a href="/index.php?m=member&f=password">修改密码</a></div></li>
                <li><div class="body3_l2_t">&nbsp;<a href="/index.php?m=member&f=register">会员注册</a></div></li>
                <li><div class="body3_l2_t">&nbsp;<a href="/index.php?m=member&f=logout">安全退出</a></div></li>
            </ul> 
        </div>
    </div>
    <!-- 二级导航 END  -->