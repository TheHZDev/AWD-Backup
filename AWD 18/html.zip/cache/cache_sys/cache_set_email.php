<?php
$_email=array (  'mailobject' => '1',  'mailserver' => 'smtp.163.com',  'mailport' => '25',  'password' => '123456',  'mailadd' => 'admin@163.com',  'username' => 'admin@163.com',);
?>