<?php
$_contact=array (  'master' => '管理员',  'email' => 'service@91736.com',  'contact' => '管理员',  'telephone' => '0771-1234567',  'fax' => '0771-1234567',  'mobilephone' => '13333333333',  'address' => '广西南宁市东葛路',);
?>