<?php
$_language=array (
  0 => 
  array (
    'id' => '1',
    'title' => '中文',
    'dir' => '',
    'seo_title' => 'XDcms企业网站管理系统',
    'seo_key' => '企业网站系统',
    'seo_des' => 'XDcms企业网站管理系统是由南宁旭东网络科技有限公司独立开发的企业网站管理系统',
    'sitename' => 'XDcms',
    'copyright' => '南宁旭东网络科技有限公司 2012 版权所有 桂ICP备03023960号<br>Copyright 2012 XuDong network technology Co., LT ',
  ),
  1 => 
  array (
    'id' => '2',
    'title' => 'English',
    'dir' => 'en',
    'seo_title' => 'XDcms Enterprise web site management system',
    'seo_key' => 'Enterprise web site management system',
    'seo_des' => 'Enterprise web site management system',
    'sitename' => 'XDcms',
    'copyright' => 'Copyright 2012 XuDong network technology Co., LTPowered by 91736 ',
  ),
);
?>