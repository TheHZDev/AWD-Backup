<?php
$_field=array (
  0 => 
  array (
    'fieldid' => '3',
    'field' => 'truename',
    'name' => '姓名',
    'formtype' => 'text',
    'width' => '12',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '1',
    'is_fixed' => '0',
    'is_register' => '1',
  ),
  1 => 
  array (
    'fieldid' => '2',
    'field' => 'sex',
    'name' => '性别',
    'formtype' => 'radio',
    'width' => '0',
    'height' => '0',
    'initial' => '男,女,保密',
    'explain' => '',
    'sort' => '2',
    'is_fixed' => '0',
    'is_register' => '0',
  ),
  2 => 
  array (
    'fieldid' => '4',
    'field' => 'phone',
    'name' => '联系电话',
    'formtype' => 'text',
    'width' => '15',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '3',
    'is_fixed' => '0',
    'is_register' => '0',
  ),
  3 => 
  array (
    'fieldid' => '6',
    'field' => 'email',
    'name' => '安全邮箱',
    'formtype' => 'text',
    'width' => '30',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '4',
    'is_fixed' => '1',
    'is_register' => '1',
  ),
  4 => 
  array (
    'fieldid' => '5',
    'field' => 'address',
    'name' => '联系地址',
    'formtype' => 'text',
    'width' => '40',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '5',
    'is_fixed' => '0',
    'is_register' => '0',
  ),
);
?>