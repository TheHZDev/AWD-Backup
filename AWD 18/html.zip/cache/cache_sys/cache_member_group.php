<?php
$_member_group=array (
  0 => 
  array (
    'groupid' => '1',
    'name' => '��ͨ��Ա',
  ),
);
?>