<?php
$_field=array (
  0 => 
  array (
    'fieldid' => '1',
    'modelid' => '1',
    'field' => 'content',
    'name' => '详细内容',
    'formtype' => 'editor',
    'width' => '0',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '0',
    'is_fixed' => '1',
  ),
);
?>