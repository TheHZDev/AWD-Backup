<?php
$_form=array (
  0 => 
  array (
    'id' => '7',
    'form_name' => '在线留言',
    'form_table' => 'message',
    'is_lock' => '1',
    'is_fixed' => '0',
    'is_email' => '0',
    'is_code' => '1',
  ),
  1 => 
  array (
    'id' => '8',
    'form_name' => '投递简历',
    'form_table' => 'resume',
    'is_lock' => '1',
    'is_fixed' => '0',
    'is_email' => '0',
    'is_code' => '0',
  ),
);
?>