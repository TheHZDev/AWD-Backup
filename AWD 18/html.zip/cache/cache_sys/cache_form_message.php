<?php
$_field=array (
  0 => 
  array (
    'fieldid' => '16',
    'formid' => '7',
    'field' => 'truename',
    'name' => '姓名',
    'formtype' => 'text',
    'width' => '15',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '0',
    'is_fixed' => '0',
  ),
  1 => 
  array (
    'fieldid' => '17',
    'formid' => '7',
    'field' => 'telephone',
    'name' => '电话',
    'formtype' => 'text',
    'width' => '20',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '0',
    'is_fixed' => '0',
  ),
  2 => 
  array (
    'fieldid' => '18',
    'formid' => '7',
    'field' => 'address',
    'name' => '地址',
    'formtype' => 'text',
    'width' => '35',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '0',
    'is_fixed' => '0',
  ),
  3 => 
  array (
    'fieldid' => '19',
    'formid' => '7',
    'field' => 'content',
    'name' => '详细内容',
    'formtype' => 'textarea',
    'width' => '45',
    'height' => '6',
    'initial' => '',
    'explain' => '',
    'sort' => '0',
    'is_fixed' => '0',
  ),
);
?>