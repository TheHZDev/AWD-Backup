<?php
$_field=array (
  0 => 
  array (
    'fieldid' => '16',
    'modelid' => '3',
    'field' => 'moreimage',
    'name' => '多图上传',
    'formtype' => 'moreimage',
    'width' => '0',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '1',
    'is_fixed' => '0',
  ),
  1 => 
  array (
    'fieldid' => '4',
    'modelid' => '3',
    'field' => 'content',
    'name' => '详细说明',
    'formtype' => 'editor',
    'width' => '0',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '2',
    'is_fixed' => '0',
  ),
);
?>