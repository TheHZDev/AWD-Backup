<?php
$_field=array (
  0 => 
  array (
    'fieldid' => '14',
    'modelid' => '5',
    'field' => 'files',
    'name' => '上传文件',
    'formtype' => 'files',
    'width' => '0',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '0',
    'is_fixed' => '0',
  ),
  1 => 
  array (
    'fieldid' => '15',
    'modelid' => '5',
    'field' => 'content',
    'name' => '详细说明',
    'formtype' => 'editor',
    'width' => '0',
    'height' => '0',
    'initial' => '',
    'explain' => '',
    'sort' => '0',
    'is_fixed' => '0',
  ),
);
?>