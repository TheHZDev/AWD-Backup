<?php
$_model=array (
  0 => 
  array (
    'id' => '1',
    'model_name' => '单页模型',
    'model_table' => 'single',
    'is_lock' => '1',
    'is_fixed' => '1',
  ),
  1 => 
  array (
    'id' => '2',
    'model_name' => '新闻模型',
    'model_table' => 'news',
    'is_lock' => '1',
    'is_fixed' => '0',
  ),
  2 => 
  array (
    'id' => '3',
    'model_name' => '产品模型',
    'model_table' => 'product',
    'is_lock' => '1',
    'is_fixed' => '0',
  ),
  3 => 
  array (
    'id' => '4',
    'model_name' => '招聘模型',
    'model_table' => 'job',
    'is_lock' => '1',
    'is_fixed' => '0',
  ),
  4 => 
  array (
    'id' => '5',
    'model_name' => '下载模型',
    'model_table' => 'download',
    'is_lock' => '1',
    'is_fixed' => '0',
  ),
);
?>