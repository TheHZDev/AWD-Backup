<?php
$_config=array (
  'is_modify' => 1,
  'siteurl' => '/',
  'template' => 'xdcms',
  'caching' => 'false',
  'createhtml' => NULL,
  'cookie' => NULL,
  'logourl' => 'system/templates/xdcms/images/logo.gif',
);
?>