<?php
$_menu=array (
  0 => 
  array (
    'menuid' => '1',
    'parentid' => '0',
    'title' => '后台首页',
    'url' => 'index.php?m=xdcms&c=index&f=left&id=1',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  1 => 
  array (
    'menuid' => '2',
    'parentid' => '0',
    'title' => '系统设置',
    'url' => 'index.php?m=xdcms&c=index&f=left&id=2',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  2 => 
  array (
    'menuid' => '3',
    'parentid' => '0',
    'title' => '内容管理',
    'url' => 'index.php?m=xdcms&c=index&f=left&id=3',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  3 => 
  array (
    'menuid' => '4',
    'parentid' => '0',
    'title' => '模块管理',
    'url' => 'index.php?m=xdcms&c=index&f=left&id=4',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  4 => 
  array (
    'menuid' => '5',
    'parentid' => '0',
    'title' => '模板管理',
    'url' => 'index.php?m=xdcms&c=index&f=left&id=5',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  5 => 
  array (
    'menuid' => '6',
    'parentid' => '0',
    'title' => '文件管理',
    'url' => 'index.php?m=xdcms&c=index&f=left&id=6',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  6 => 
  array (
    'menuid' => '7',
    'parentid' => '1',
    'title' => '常用操作',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  7 => 
  array (
    'menuid' => '8',
    'parentid' => '7',
    'title' => '后台首页',
    'url' => 'index.php?m=xdcms&c=index&f=main',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  8 => 
  array (
    'menuid' => '9',
    'parentid' => '7',
    'title' => '更新首页',
    'url' => 'index.php?m=xdcms&c=creathtml&f=update_index',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  9 => 
  array (
    'menuid' => '10',
    'parentid' => '7',
    'title' => '添加栏目',
    'url' => 'index.php?m=xdcms&c=category&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  10 => 
  array (
    'menuid' => '11',
    'parentid' => '7',
    'title' => '管理栏目',
    'url' => 'index.php?m=xdcms&c=category',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  11 => 
  array (
    'menuid' => '12',
    'parentid' => '7',
    'title' => '内容模型管理',
    'url' => 'index.php?m=xdcms&c=model',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  12 => 
  array (
    'menuid' => '13',
    'parentid' => '7',
    'title' => '更新全站缓存',
    'url' => 'index.php?m=xdcms&c=update_cache',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  13 => 
  array (
    'menuid' => '14',
    'parentid' => '1',
    'title' => '个人信息',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  14 => 
  array (
    'menuid' => '15',
    'parentid' => '14',
    'title' => '修改密码',
    'url' => 'index.php?m=xdcms&c=index&f=edit',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  15 => 
  array (
    'menuid' => '23',
    'parentid' => '16',
    'title' => '添加栏目',
    'url' => 'index.php?m=xdcms&c=category&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  16 => 
  array (
    'menuid' => '24',
    'parentid' => '16',
    'title' => '管理栏目',
    'url' => 'index.php?m=xdcms&c=category',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  17 => 
  array (
    'menuid' => '25',
    'parentid' => '17',
    'title' => '添加模型',
    'url' => 'index.php?m=xdcms&c=model&f=model_add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  18 => 
  array (
    'menuid' => '26',
    'parentid' => '17',
    'title' => '管理模型',
    'url' => 'index.php?m=xdcms&c=model',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  19 => 
  array (
    'menuid' => '27',
    'parentid' => '18',
    'title' => '添加管理员',
    'url' => 'index.php?m=xdcms&c=admin&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  20 => 
  array (
    'menuid' => '28',
    'parentid' => '18',
    'title' => '管理员列表',
    'url' => 'index.php?m=xdcms&c=admin',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  21 => 
  array (
    'menuid' => '29',
    'parentid' => '19',
    'title' => '数据库备份',
    'url' => 'index.php?m=xdcms&c=data',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  22 => 
  array (
    'menuid' => '30',
    'parentid' => '19',
    'title' => '数据库恢复',
    'url' => 'index.php?m=xdcms&c=data&f=data_file',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  23 => 
  array (
    'menuid' => '31',
    'parentid' => '20',
    'title' => '添加关键词',
    'url' => 'index.php?m=xdcms&c=keywords&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  24 => 
  array (
    'menuid' => '32',
    'parentid' => '20',
    'title' => '管理关键词',
    'url' => 'index.php?m=xdcms&c=keywords',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  25 => 
  array (
    'menuid' => '33',
    'parentid' => '21',
    'title' => '基本信息',
    'url' => 'index.php?m=xdcms&c=setting',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  26 => 
  array (
    'menuid' => '34',
    'parentid' => '21',
    'title' => '联系方式',
    'url' => 'index.php?m=xdcms&c=setting&f=contact',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  27 => 
  array (
    'menuid' => '35',
    'parentid' => '21',
    'title' => '邮件设置',
    'url' => 'index.php?m=xdcms&c=setting&f=email',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  28 => 
  array (
    'menuid' => '36',
    'parentid' => '22',
    'title' => '添加菜单',
    'url' => 'index.php?m=xdcms&c=menu&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  29 => 
  array (
    'menuid' => '37',
    'parentid' => '22',
    'title' => '管理菜单',
    'url' => 'index.php?m=xdcms&c=menu',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  30 => 
  array (
    'menuid' => '38',
    'parentid' => '4',
    'title' => '碎片管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  31 => 
  array (
    'menuid' => '39',
    'parentid' => '38',
    'title' => '添加碎片',
    'url' => 'index.php?m=xdcms&c=block&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  32 => 
  array (
    'menuid' => '40',
    'parentid' => '38',
    'title' => '管理碎片',
    'url' => 'index.php?m=xdcms&c=block',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  33 => 
  array (
    'menuid' => '41',
    'parentid' => '4',
    'title' => '幻灯片管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  34 => 
  array (
    'menuid' => '42',
    'parentid' => '4',
    'title' => '客服QQ管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  35 => 
  array (
    'menuid' => '43',
    'parentid' => '4',
    'title' => '友情链接管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  36 => 
  array (
    'menuid' => '44',
    'parentid' => '4',
    'title' => '会员管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  37 => 
  array (
    'menuid' => '45',
    'parentid' => '41',
    'title' => '添加幻灯',
    'url' => 'index.php?m=flash&c=admin&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  38 => 
  array (
    'menuid' => '46',
    'parentid' => '41',
    'title' => '管理幻灯',
    'url' => 'index.php?m=flash&c=admin',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  39 => 
  array (
    'menuid' => '47',
    'parentid' => '42',
    'title' => '添加客服',
    'url' => 'index.php?m=qq&c=admin&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  40 => 
  array (
    'menuid' => '48',
    'parentid' => '42',
    'title' => '管理客服',
    'url' => 'index.php?m=qq&c=admin',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  41 => 
  array (
    'menuid' => '49',
    'parentid' => '43',
    'title' => '添加链接',
    'url' => 'index.php?m=link&c=admin&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  42 => 
  array (
    'menuid' => '50',
    'parentid' => '43',
    'title' => '管理链接',
    'url' => 'index.php?m=link&c=admin',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  43 => 
  array (
    'menuid' => '51',
    'parentid' => '44',
    'title' => '会员列表',
    'url' => 'index.php?m=member&c=admin',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  44 => 
  array (
    'menuid' => '52',
    'parentid' => '44',
    'title' => '模型配置',
    'url' => 'index.php?m=member&c=admin&f=field',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  45 => 
  array (
    'menuid' => '53',
    'parentid' => '44',
    'title' => '会员组管理',
    'url' => 'index.php?m=member&c=group',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  46 => 
  array (
    'menuid' => '54',
    'parentid' => '5',
    'title' => '模板管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  47 => 
  array (
    'menuid' => '55',
    'parentid' => '54',
    'title' => '模板列表',
    'url' => 'index.php?m=xdcms&c=template',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  48 => 
  array (
    'menuid' => '56',
    'parentid' => '5',
    'title' => '数据调用',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  49 => 
  array (
    'menuid' => '57',
    'parentid' => '56',
    'title' => '调用说明',
    'url' => 'index.php?m=xdcms&c=template&f=calls',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  50 => 
  array (
    'menuid' => '58',
    'parentid' => '6',
    'title' => '生成html',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  51 => 
  array (
    'menuid' => '59',
    'parentid' => '6',
    'title' => '更新URL',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  52 => 
  array (
    'menuid' => '60',
    'parentid' => '58',
    'title' => '更新首页',
    'url' => 'index.php?m=xdcms&c=creathtml&f=update_index',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  53 => 
  array (
    'menuid' => '61',
    'parentid' => '58',
    'title' => '更新栏目页',
    'url' => 'index.php?m=xdcms&c=categorytree&f=category_tree',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  54 => 
  array (
    'menuid' => '62',
    'parentid' => '58',
    'title' => '更新内容页',
    'url' => 'index.php?m=xdcms&c=categorytree&f=show_tree',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  55 => 
  array (
    'menuid' => '63',
    'parentid' => '59',
    'title' => '更新URL',
    'url' => 'index.php?m=xdcms&c=categorytree',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  56 => 
  array (
    'menuid' => '64',
    'parentid' => '4',
    'title' => '自定义表单管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  57 => 
  array (
    'menuid' => '65',
    'parentid' => '64',
    'title' => '管理表单',
    'url' => 'index.php?m=form&c=admin',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  58 => 
  array (
    'menuid' => '66',
    'parentid' => '4',
    'title' => '模块管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  59 => 
  array (
    'menuid' => '67',
    'parentid' => '66',
    'title' => '模块列表',
    'url' => 'index.php?m=xdcms&c=module',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  60 => 
  array (
    'menuid' => '68',
    'parentid' => '18',
    'title' => '管理员组管理',
    'url' => 'index.php?m=xdcms&c=admin&f=admin_group',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  61 => 
  array (
    'menuid' => '69',
    'parentid' => '18',
    'title' => '添加管理员组',
    'url' => 'index.php?m=xdcms&c=admin&f=admin_group_add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  62 => 
  array (
    'menuid' => '70',
    'parentid' => '21',
    'title' => '上传设置',
    'url' => 'index.php?m=xdcms&c=setting&f=upload',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  63 => 
  array (
    'menuid' => '74',
    'parentid' => '6',
    'title' => 'URL规则管理',
    'url' => '###',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  64 => 
  array (
    'menuid' => '75',
    'parentid' => '74',
    'title' => '添加规则',
    'url' => 'index.php?m=xdcms&c=urlrule&f=add',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  65 => 
  array (
    'menuid' => '76',
    'parentid' => '74',
    'title' => '规则管理',
    'url' => 'index.php?m=xdcms&c=urlrule',
    'sort' => '0',
    'is_show' => '1',
    'groupid' => '',
  ),
  66 => 
  array (
    'menuid' => '21',
    'parentid' => '2',
    'title' => '网站配置',
    'url' => '###',
    'sort' => '1',
    'is_show' => '1',
    'groupid' => '',
  ),
  67 => 
  array (
    'menuid' => '71',
    'parentid' => '2',
    'title' => '版本管理',
    'url' => '###',
    'sort' => '1',
    'is_show' => '1',
    'groupid' => '',
  ),
  68 => 
  array (
    'menuid' => '73',
    'parentid' => '71',
    'title' => '添加版本',
    'url' => 'index.php?m=xdcms&c=language&f=add',
    'sort' => '1',
    'is_show' => '1',
    'groupid' => '',
  ),
  69 => 
  array (
    'menuid' => '16',
    'parentid' => '2',
    'title' => '栏目管理',
    'url' => '###',
    'sort' => '2',
    'is_show' => '1',
    'groupid' => '',
  ),
  70 => 
  array (
    'menuid' => '72',
    'parentid' => '71',
    'title' => '版本列表',
    'url' => 'index.php?m=xdcms&c=language',
    'sort' => '2',
    'is_show' => '1',
    'groupid' => '',
  ),
  71 => 
  array (
    'menuid' => '17',
    'parentid' => '2',
    'title' => '模型管理',
    'url' => '###',
    'sort' => '3',
    'is_show' => '1',
    'groupid' => '',
  ),
  72 => 
  array (
    'menuid' => '18',
    'parentid' => '2',
    'title' => '管理员设置',
    'url' => '###',
    'sort' => '4',
    'is_show' => '1',
    'groupid' => '',
  ),
  73 => 
  array (
    'menuid' => '19',
    'parentid' => '2',
    'title' => '数据库管理',
    'url' => '###',
    'sort' => '5',
    'is_show' => '1',
    'groupid' => '',
  ),
  74 => 
  array (
    'menuid' => '20',
    'parentid' => '2',
    'title' => '关键词链接',
    'url' => '###',
    'sort' => '6',
    'is_show' => '1',
    'groupid' => '',
  ),
  75 => 
  array (
    'menuid' => '22',
    'parentid' => '2',
    'title' => '后台菜单管理',
    'url' => '###',
    'sort' => '7',
    'is_show' => '1',
    'groupid' => '',
  ),
);
?>