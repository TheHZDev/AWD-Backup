<?php
$_upload=array (
  'isopen' => '1',
  'imagesize' => '500',
  'imageallowed' => 'gif,jpg,jpeg,png',
  'filesize' => '2048',
  'fileallowed' => 'rar,zip,doc',
  'watermark' => '100',
  'pos' => '9',
  'font' => '5',
  'width' => '300',
  'color' => '#FF0000',
  'text' => 'xdcms.cn',
  'image' => 'uploadfile/xdcms.png',
);
?>