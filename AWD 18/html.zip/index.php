<?php
//中文
if(!file_exists("data/config.inc.php")){header("location:install/index.php");exit();}
require dirname(__FILE__).'/system/common.inc.php';
?>