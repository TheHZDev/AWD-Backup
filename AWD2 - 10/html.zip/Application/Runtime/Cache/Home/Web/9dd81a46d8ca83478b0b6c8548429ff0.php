<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=7">
<title><?php echo ($webtitle); ?></title>
<meta name="copyright" content="<?php echo ($weburl); ?>" />
<meta name="keywords" content="<?php echo ($keywords); ?>">
<meta name="description" content="<?php echo ($description); ?>">
<meta name="ROBOTS" content="NOIMAGEINDEX">
<link rel="alternate" href="<?php echo ($rssurl); ?>" type="application/rss+xml" title="rss" />
<link rel="stylesheet" type="text/css" href="<?php echo ($tplpath); ?>/style/style.css" />
</head>
<body>
<div id="header">
	<div class="wrapper">
		<h1 class="logo"><a href="<?php echo ($weburl); ?>"><img src="<?php echo ($webpath); echo ($weblogo); ?>" /></a></h1>
		<div class="search">
            <form name="search" id="searchform" action="<?php echo ($webdir); echo U('Search/index');?>" method="post" target="_blank">
                <input type="text" placeholder="输入影片名称、演员" id="searchTxt" autocomplete="off" name="keyword">
                <button type="submit">搜索</button>
            </form>
            <div class="queryList clearfix" id="js-query-data" style="display: none;">
            	<ul id="js-calldata-list"></ul>
                <div class="prevList" id="js-calldata-preview"></div>
             </div>
		</div>
		<div class="operht">
			<div class="userlog">
            	<?php if(empty($user['id'])): ?><a href="<?php echo ($user['userlogin']); ?>">登录</a>
                <a href="<?php echo ($user['userreg']); ?>">注册</a>
                <?php else: ?>
                <p class="loged">
                    <a href="<?php echo ($user['userurl']); ?>" class="u"><?php echo ($user['username']); ?></a>
                	<a href="<?php echo ($user['userlogout']); ?>">退出</a>
                </p><?php endif; ?>
	    	</div>
			<div class="history">
				<span class="kick">播放记录</span>
		  		<dl class="hisCont">
					<dt>播放记录</dt>
					<dd id="hisStatu">
						<ul><li id="noHis">您还没有观看记录~</li></ul>
					</dd>
				</dl>
			</div>
		</div>
	</div>
</div>
<div id="navis">
    <ul>
    	<li><a href="<?php echo ($webpath); ?>" title="首页">首页</a></li>
    <?php $__NAV__ = D('Tag')->getNav(0,"",0,"id,title,name,pid,link"); if(is_array($__NAV__)): $i = 0; $__LIST__ = $__NAV__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nav): $mod = ($i % 2 );++$i;?><li <?php if(($nav['id'] == $cid) OR ($nav['id'] == $pid)): ?>class="active"<?php endif; ?>><a href="<?php echo ($nav['url']); ?>" title="<?php echo ($nav['title']); ?>"><?php echo ($nav['title']); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
		<li class="more" style="margin-right: 0px">
            <span><a href="<?php echo U('Home/Other/index/tpl/top');?>" title="排行榜">排行榜</a></span>
            <span><a href="javascript:;" title="收藏本站" id="collet">收藏本站</a></span>
        </li>
    </ul>
</div>
<div class="wrapper">
	<div class="brecam">您的当前位置：<?php echo ($ctitle); ?><i>&gt;</i><?php echo ($title); ?></div>
    <div class="comwrap clearfix">
		<div class="continfo">
			<div class="player">
				<iframe id="playeriframe" name="playeriframe" src="" MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no width="100%" height="100%" allowfullscreen="ture"></iframe><script language="javascript">var playerobj=document.getElementById("playeriframe");playerobj.src="/index.php?s=/home/player/player/pid/<?php echo I('pid');?>/n/<?php echo I('n');?>.html";</script>
			</div>
			<dl class="playurl">
				<dt>
					<span>播放地址</span>
					<ul>
                    	<?php $__PLAYLIST__ = D('Tag')->playlistTag($id,''); if(is_array($__PLAYLIST__)): $i = 0; $__LIST__ = $__PLAYLIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$player): $mod = ($i % 2 );++$i;?><li <?php if(($i) == "1"): ?>class="current"<?php endif; ?>>
							<em><?php echo ($player['title']); ?></em>
						</li><?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
				</dt>
                <?php $__PLAYLIST__ = D('Tag')->playlistTag($id,''); if(is_array($__PLAYLIST__)): $i = 0; $__LIST__ = $__PLAYLIST__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$player): $mod = ($i % 2 );++$i;?><dd <?php if(($i) == "1"): ?>style="display:block;"<?php endif; ?>>
                        <?php if(is_array($player['movie_url'])): $i = 0; $__LIST__ = $player['movie_url'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$url): $mod = ($i % 2 );++$i;?><a history="<?php echo ($i); ?>" href="<?php echo ($url['url']); ?>" target="_blank" rel="nofollow"><?php echo ($url['title']); ?></a><?php endforeach; endif; else: echo "" ;endif; ?>
                    </dd><?php endforeach; endif; else: echo "" ;endif; ?>
			</dl>
            <div class="comwrap">
				<?php echo hook('SocialComment');?>
			</div>
        </div>
    </div>
    <div id="bde">
    <!-- 广告位：首页横幅960*90 -->
    </div>
</div>
<div id="footer">
	<div class="wrapper clearfix">
		<p class="bhr"></p>
		<ul class="fl">
			<li><a href="http://www.lfdycms.com">雷风官网</a> | </li>
			<li><a href="http://bbs.lfdycms.com">雷风论坛</a> | </li>
			<li><a href="http://www.lfdycms.com">网站开发</a></li>
		</ul>
		<p class="fr">(C)2005- 2013 <?php echo ($webname); ?> <?php echo ($weburl); ?></p>
        <p class="fr"><?php echo ($icp); ?></p>
	</div>
</div>
<div id="gotop" style="opacity: 0;"><a href="javascript:;" title="回顶部">回顶部</a></div>
<script type="text/javascript" src="<?php echo ($tplpath); ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo ($tplpath); ?>/js/jquery.lazyload.min.js"></script>
<script type="text/javascript" src="<?php echo ($tplpath); ?>/js/common.source.js"></script>
</body>
</html>