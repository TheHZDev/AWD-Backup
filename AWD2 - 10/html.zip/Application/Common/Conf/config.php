<?php
return array(
    'AUTOLOAD_NAMESPACE' => array('Addons' => ADDON_PATH), //扩展模块列表
    /* 数据库配置 */
    'DB_TYPE'   => 'mysql', // 数据库类型
    'DB_HOST'   => '127.0.0.1', // 服务器地址
    'DB_NAME'   => 'cms', // 数据库名
    'DB_USER'   => 'cms', // 用户名
    'DB_PWD'    => '3dc981b411ed9690',  // 密码
    'DB_PORT'   => '3306', // 端口
    'DB_PREFIX' => 'lf_', // 数据库表前缀
);