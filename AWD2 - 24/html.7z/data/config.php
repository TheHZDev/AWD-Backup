<?php
$dbhost   = "127.0.0.1";

$dbname   = "cms";

$dbuser   = "cms";

$dbpass   = "cms123";

$pre    = "blue_";

$cookiedomain = '';

$cookiepath = '/';

define('BLUE_CHARSET','gb2312');

define('BLUE_VERSION','v1.6');

?>