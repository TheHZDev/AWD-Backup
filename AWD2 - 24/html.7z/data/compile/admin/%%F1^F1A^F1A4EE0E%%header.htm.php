<?php /* Smarty version 2.6.22, created on 2022-02-26 18:24:02
         compiled from header.htm */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $this->_tpl_vars['current_act']; ?>
 - BlueCMS��������</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $this->_tpl_vars['charset']; ?>
" />
<link href="css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../templates/default/css/jquery.js"></script>
</head>
<body>