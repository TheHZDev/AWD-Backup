<?php /* Smarty version 2.6.22, created on 2022-02-26 18:24:02
         compiled from footer.htm */ ?>
<div id="footer">
Powered By <span class="bluecms"><a href="http://www.bluecms.net" target="_blank">BlueCMS</a></span>&nbsp;<span class="version"><?php echo $this->_tpl_vars['version']; ?>
</span>
</div>
</body>
</html>