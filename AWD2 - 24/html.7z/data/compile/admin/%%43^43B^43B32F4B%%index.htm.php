<?php /* Smarty version 2.6.22, created on 2022-02-26 18:24:10
         compiled from index.htm */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>BlueCMS��������</title>
</head>
<frameset rows="76,*" frameborder="no" border="0" framespacing="0" >
        <frame src="index.php?act=top" name="topFrame" id="topFrame" scrolling="no" noresize>
        <frameset cols="176,*" name="bodyFrame" id="bodyFrame" frameborder="no" border="0" framespacing="0"  >
            <frame src="index.php?act=menu" name="menuFrame" id="menuFrame" scrolling="yes" noresize>
            <frame src="index.php?act=main" name="mainFrame" id="mainFrame" scrolling="auto" noresize>
        </frameset>
    </frameset>
    <noframes>
        <body>����������֧�ֿ��</body>
    </noframes>
</html>