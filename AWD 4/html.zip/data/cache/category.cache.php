<?php
$cache=unserialize(stripslashes('a:1:{i:1;a:4:{s:11:\"category_id\";s:1:\"1\";s:12:\"category_pid\";s:1:\"0\";s:13:\"category_name\";s:9:\"日用品\";s:14:\"category_order\";s:1:\"1\";}}'));
?>