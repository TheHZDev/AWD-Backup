<?php
$cache=unserialize(stripslashes('a:1:{i:1;a:3:{s:8:\"class_id\";s:1:\"1\";s:10:\"class_name\";s:12:\"网站公告\";s:11:\"class_order\";s:1:\"0\";}}'));
?>