<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $seo['title'] ?></title>
<meta name="keywords" content="<?php echo $seo['keywords'] ?>" />
<meta name="description" content="<?php echo $seo['description'] ?>" />
<link type="text/css" rel="stylesheet" href="<?php echo $pe['host_tpl'] ?>css/style.css" />
<script type="text/javascript" src="<?php echo $pe['host_root'] ?>include/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $pe['host_root'] ?>include/js/global.js"></script>
<style type="text/css">
body{background:#3C7DBE;}
.login{background:url(<?php echo $pe['host_tpl'] ?>images/login_bg.png) no-repeat; width:315px; height:225px; margin:0 auto; margin-top:15px;}
.login_tt{font-size:26px; color:#fff; width:315px; margin:0 auto; margin-top:180px; font-weight:bold; text-align:center}
.input1{padding:36px 0 0 90px; font-size:14px; color:#888;}
.input1 input{width:140px; height:28px; margin-left:5px; border:0; line-height:28px;}
.input2{padding:27px 0 0 90px;font-size:14px; color:#888;}
.input2 input{width:140px; height:28px; margin-left:5px; border:0; line-height:28px;}
.login_btn{margin:25px 0 0 55px;}
.login_btn input{background:url(<?php echo $pe['host_tpl'] ?>images/login_btn.gif) no-repeat; width:216px; height:43px; border:0; cursor:pointer;}
.copyright{text-align:center; color:#BECAD6;}
.copyright a,.copyright a:hover{color:#BECAD6;}
</style>
</head>
<body>
<div class="login_tt"><span class="num"></span>商城管理系统</div>
<form method="post">
<div class="login">	
	<div class="input1">账号:<input type="text" name="info[admin_name]" /></div>
	<div class="input2">密码:<input type="password" name="info[admin_pw]" /></div>
	<div class="login_btn"><input type="submit" name="pesubmit" value=" " /></div>
</div>
</form>
<div class="copyright">Copyright <span class="num">©</span> 2021-2022 <a href="#" target="_blank">Bugku</a> awd赛事</div>
</body>
<script type="text/javascript">
$(function(){
$(":submit").click(function(){
	if ($(":input[name='info[admin_name]']").val() == '') {
		alert('帐号不能为空！')
		return false;
	}
	if ($(":input[name='info[admin_pw]']").val() == '') {
		alert('密码不能为空！')
		return false;
	}
	return true;
})
})
</script>
</html>