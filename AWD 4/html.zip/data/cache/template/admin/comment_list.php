<?php include(pe_tpl('header.html'));?>
<div class="right">
	<div class="now">
		<div class="now_l"></div>
		<div class="now_m"><?php echo $menutitle ?></div>
		<div class="now_r"></div>
		<div class="clear"></div>
	</div>
	<div class="search">
		<div class="fr searbox">
			<form method="get">
				<input type="hidden" name="mod" value="<?php echo $_g_mod ?>" />
				商品名称：<input type="text" name="name" value="<?php echo $_g_name ?>" class="inputtext inputtext_150" />
				评价详情：<input type="text" name="text" value="<?php echo $_g_text ?>" class="inputtext inputtext_150" />
				用户名：<input type="text" name="user_name" value="<?php echo $_g_user_name ?>" class="inputtext inputtext_100" />
				<input type="submit" value="搜索" class="input2" />
			</form>
		</div>
		<div class="clear"></div>
	</div>
	<form method="post" id="form">
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="list mat5">
	<tr>
		<td class="bgtt" width="10"><input type="checkbox" name="checkall" onclick="pe_checkall(this, 'comment_id')" /></td>
		<td class="bgtt" width="50">ID号</td>
		<td class="bgtt">评价详情</td>
		<td class="bgtt" width="80">用户名</td>
		<td class="bgtt" width="70">操作</td>
	</tr>
	<?php foreach($info_list as $v):?>
	<tr>
		<td><input type="checkbox" name="comment_id[]" value="<?php echo $v['comment_id'] ?>" /></td>
		<td><?php echo $v['comment_id'] ?></td>
		<td class="aleft">
			<p><a href="<?php echo pe_url('product-'.$v['product_id']) ?>" target="_blank" class="cblue"><?php echo $v['product_name'] ?></a></p>
			<p><span class="cgreen">评价<?php if($v['comment_text']):?>[<?php echo pe_date($v['comment_atime'],'Y-m-d') ?>]<?php endif;?>：</span><span class="c888"><?php echo $v['comment_text'] ?></span></p>
		</td>
		<td><a href="http://www.ip138.com/ips.asp?ip=<?php echo $v['user_ip'] ?>" target="_blank"><?php echo $v['user_name'] ?></a></td>
		<td>
			<a href="admin.php?mod=comment&act=edit&id=<?php echo $v['comment_id'] ?>&<?php echo pe_fromto() ?>" class="admin_edit">详情</a>
			<a href="admin.php?mod=comment&act=del&id=<?php echo $v['comment_id'] ?>" class="admin_del" onclick="return pe_cfone(this, '删除')">删除</a>
		</td>
	</tr>
	<?php endforeach;?>
	<tr>
		<td class="bgtt" align="center"><input type="checkbox" name="checkall" onclick="pe_checkall(this, 'comment_id')" /></td>
		<td class="bgtt" colspan="4">
			<span class="fl"><button href="admin.php?mod=comment&act=del" onclick="return pe_cfall(this, 'comment_id', 'form', '批量删除')">批量删除</button></span>
			<span class="fenye"><?php echo $db->page->html ?></span>
		</td>
	</tr>
	</table>
	</form>
</div>
<?php include(pe_tpl('footer.html'));?>