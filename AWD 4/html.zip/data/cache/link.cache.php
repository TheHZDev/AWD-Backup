<?php
$cache=unserialize(stripslashes('a:1:{i:0;a:4:{s:7:\"link_id\";s:1:\"1\";s:9:\"link_name\";s:8:\"BugkuCTF\";s:8:\"link_url\";s:29:\"http://https://ctf.bugku.com/\";s:10:\"link_order\";s:1:\"1\";}}'));
?>