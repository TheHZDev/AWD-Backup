<?php
$pe['db_host'] = 'localhost'; //数据库主机地址
$pe['db_name'] = 'cms'; //数据库名称
$pe['db_user'] = 'admin'; //数据库用户名
$pe['db_pw'] = '211679491d0462e3'; //数据库密码
$pe['db_coding'] = 'utf8';
$pe['url_model'] = 'pathinfo'; //url模式,可选项(pathinfo/pathinfo_safe/php)
define('dbpre','pe_'); //数据库表前缀
?>