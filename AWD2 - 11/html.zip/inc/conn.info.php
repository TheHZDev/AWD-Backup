<?php
$DB_HOST='localhost';
$DB_USER='cms';
$DB_PWD='f72fb5e12d0a7618';
$DB_NAME='cms';
?>
