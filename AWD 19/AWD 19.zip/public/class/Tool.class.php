<?php

//工具类
class Tool{
	//
	static public function layer_alert($msg='',$url='',$icon=''){
		$str='<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>';
		$str.='<script type="text/javascript" src="../public/layer/layer.js"></script>';//加载jquery和layer
		$str.='<script>$(function(){layer.alert("'.$msg.'",{offset: ["75px"],icon:'.$icon.',shade: 0.1,title:"信息提示"},function(){self.location.href="'.$url.'"})});</script>';//主要方法
		echo $str;
		exit();
	}
	
// 	static public function layer_confirm($msg='',$url='',$icon=''){
// 		$str='<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>';
// 		$str.='<script type="text/javascript" src="../public/layer/layer.js"></script>';//加载jquery和layer
// 		$str.='<script>$(function(){layer.comfirm("'.$msg.'",{offset: ["75px"],icon:'.$icon.',time:'.($time*1000).',shade: 0.1});setTimeout(function(){self.location.href="'.$url.'"},2000)});</script>';//主要方法
// 		//$str.='<script>alert("aaa");</script>';
// 		echo $str;
// 		exit();
// 	}
	//简单提示返回
	static public function t_back($_info,$_url){
		echo "<span style='color:red'>".$_info."</span>&nbsp<a href='$_url' >返回</a>";
		exit();
	}
	//弹窗跳转
	static public function alertLocation($_info, $_url) {
		if (!empty($_info)) {
			echo "<script type='text/javascript'>alert('$_info');location.href='$_url';</script>";
			exit();
		} else {
		header('Location:'.$_url);
		exit();
	}
	}
	
	//弹窗返回
	static public function alertBack($_info) {
	echo "<script type='text/javascript'>alert('$_info');history.back();</script>";
	exit();
	}
	
	//弹窗关闭
	static public function alertClose($_info) {
	echo "<script type='text/javascript'>alert('$_info');close();</script>";
	exit();
	}
	//弹窗
	static public function alert($_info) {
		echo "<script type='text/javascript'>alert('$_info');close();</script>";
	}
	//得到上一页
	static public function getPrevPage() {
		return empty($_SERVER["HTTP_REFERER"]) ? '###' : $_SERVER["HTTP_REFERER"];
	}
	//表单提交字符转义
	static public function setFormString($_string) {
		if (!get_magic_quotes_gpc()) {
			if (Validate::isArray($_string)) {
				foreach ($_string as $_key=>$_value) {
					$_string[$_key] = self::setFormString($_value);	//不支持就用代替addslashes();
				}
			} else {
				return addslashes($_string); //mysql_real_escape_string($_string, $_link);
			}
		}
		return $_string;
	}

	//转义过滤
	static public function setRequest() {
		if (isset($_GET)) $_GET = Tool::setFormString($_GET);
		if (isset($_POST)) $_POST = Tool::setFormString($_POST);
	}
	//反转义
	static public function getFormString($_object,$_field){
		if ($_object) {
			foreach ($_object as $_value) {
				$_value->$_field = StripSlashes($_value->$_field);
			}
		}
	}
	//html过滤
	static public function setHtmlString($_data) {
		$_string = '';
		if (Validate::isArray($_data)) {
			if (Validate::isNullArray($_data)) return $_data;
			foreach ($_data as $_key=>$_value) {
				$_string[$_key] = self::setHtmlString($_value);  //递归
			}
		} elseif (is_object($_data)) {
			foreach ($_data as $_key=>$_value) {
				$_string->$_key = self::setHtmlString($_value);  //递归
			}
		} else {
			$_string = htmlspecialchars($_data);
		}
		return $_string;
	}
	//mysql数据库大小
	public static function CalcFullDatabaseSize($database, $db) {
		$_sql = "SHOW TABLE STATUS FROM ".$database." LIKE '".DB_FREFIX."%'";
		$_stmt=$db->query($_sql);
		$_stmt->setFetchMode(PDO::FETCH_OBJ);
		$_data=$_stmt->fetchall();
		$_size=0;
		foreach ($_data as &$row){
			$_size += ($row->Data_length+$row->Index_length);
			//$row['Data_free'] = get_byte($row['Data_free']);
			//$row['Data_length'] = get_byte($row['Data_length']);
		}
		return self::sizeUnit($_size);
	
	}

	//计算数据大小
	public static function sizeUnit($filesize) {
        $SU = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
        $n = 0;
        while ($filesize >= 1024) {
            $filesize /= 1024;
            $n++;
        }
        return round($filesize, 2) . ' ' . $SU[$n];
	}
	//判断目录是否为空
	
	public static function is_empty_dir($fp){
		$H = @opendir($fp);
		$i=0;
		while(readdir($H)){
			$i++;
		}
		closedir($H);
		if($i>2){
			return false;
		}else{
			return true;  //true
		}
	}
	//创建目录
	public static function create_folder($dirname){
		$dirname=ROOT_PATH.'/'.$dirname;
		if(!file_exists($dirname)){
			if (!mkdir($dirname)) {
				Tool::alertBack('ERROR：'.$dirname.'目录创建失败,请设权限为777！');
			}else{
				return true;
			}
		}else{
			tool::alertBack($dirname.'目录已经存在!请换一个名字.');
		}
	}
	//修改目录
	public static function edit_folder($_old,$_new){
		$_old=ROOT_PATH.'/'.$_old;
		$_new=ROOT_PATH.'/'.$_new;
		if(file_exists($_old)){
			if (!rename($_old,$_new)) {
				Tool::alertBack('ERROR：'.$_old.'目录重命名失败,请设权限为777！');
			}else{
				return true;
			}
		}else{
			tool::alertBack($_old.'目录不存在!');
		}
	}
	//删除目录
	public static function delete_folder($dirname){
		$dirname=ROOT_PATH.'/'.$dirname;
		if(file_exists($dirname)){
			if(self::is_empty_dir($dirname)){
				if (!rmdir($dirname)) {
					Tool::alertBack('ERROR：'.$dirname.'目录删除失败,请先确认权限!');
				}else{
					return true;
				}
			}else{
				Tool::alertBack('ERROR：'.$dirname.'目录删除失败,请先删除该目录下的文件,或你也可以手动进行删除!');
			}
			
		}else{
			return true;
		}
	}
	//删除文件
	public static function delete_file($filename){
		$filename=ROOT_PATH.'/'.$filename;
		if(file_exists($filename)){
			if (!unlink($filename)) {
				Tool::alertBack('ERROR：'.$filename.'文件删除失败,请设权限为777！');
			}else{
				return true;
			}
		}else{
			return true;
		}
	}
	//生成静态
	static public function makeHtmlFile($_filename, $content) {     //目录不存在就创建
		if (!file_exists (dirname($_filename))) {
			if (!@mkdir (dirname($_filename), 0777)) {
				die($_filename."目录创建失败！");
			}
		}
		if(!$fp = fopen($_filename, "w")){
			echo "文件打开失败！";
			return false;
		}
		if(!fwrite($fp, $content)){
			echo "文件写入失败！";
			fclose($fp);
			return false;
		}
		fclose($fp);
		//chmod($_filename,0666);
	}
	//将对象数组转换成字符串，并且去掉最后的逗号
	static public function objArrOfStr(&$_object,$_field) {
		if ($_object) {
			foreach ($_object as $_value) {
				$_html .= $_value->$_field.',';
			}
		}
		return substr($_html,0,strlen($_html)-1);
	}
	//日期转换
	static public function objDate(&$_object,$_field) {
		if ($_object) {
			foreach ($_object as $_value) {
				$_value->$_field = date('m-d',strtotime($_value->$_field));
			}
		}
	}
	//字符串截取
	static public function subStr(&$_object,$_field,$_length,$_encoding) {
		if ($_object) {
			if (is_array($_object)) {
				foreach ($_object as $_value) {
					if (mb_strlen($_value->$_field,$_encoding) > $_length) {
						$_value->$_field = mb_substr($_value->$_field,0,$_length,$_encoding).'...';
					}
				}
			} else {
				if (mb_strlen($_object,$_encoding) > $_length) {
					return mb_substr($_object,0,$_length,$_encoding).'...';
				} else {
					return $_object;
				}
			}
		}
	}
static public function akunlink($filename) {
		if(file_exists($filename) && is_writable($filename)) return unlink($filename);
		return false;
	}
	
static public function addtasks($key, $tasks) {
	if(empty($tasks)) return false;
	$file = str_replace('[key]', $key, TASKFILE);
	$offsetfile = str_replace('[key]', $key, TASKFILEOFFSET);
	if(!file_exists($offsetfile)) touch($offsetfile);
	$fp = fopen($file, 'a');
	flock($fp, LOCK_EX);
	foreach($tasks as $task) {
		if(is_array($task)) $task = serialize($task);
		$task = str_replace("\n", '#\n#', $task);
		fwrite($fp, $task."\n");
	}
	flock($fp, LOCK_UN);
	fclose($fp);
}
static function addtask($key, $task) {
	if(substr($key, 0, 1) === '*') $key = substr($key, 1);
	$file = str_replace('[key]', $key, TASKFILE);
	$offsetfile = str_replace('[key]', $key, TASKFILEOFFSET);
	if(!file_exists($offsetfile)) touch($offsetfile);
	$fp = fopen($file, 'a');
	flock($fp, LOCK_EX);
	if(is_array($task)) $task = serialize($task);
	$task = str_replace("\n", '#\n#', $task);
	fwrite($fp, $task."\n");
	flock($fp, LOCK_UN);
	fclose($fp);
}

static public function deletetask($key) {
	$file = str_replace('[key]', $key, TASKFILE);
	$offsetfile = str_replace('[key]', $key, TASKFILEOFFSET);
	@self::akunlink($offsetfile);
	@self::akunlink($file);
}
static public function readfromfile($filename) {
	if(substr($filename, 0, 7) != 'http://' && !is_readable($filename)) return '';
	if(PHP_VERSION < '4.3.0') {
		if(!$fp = fopen($filename, 'r')) {
			return false;
		} else {
			flock($fp, LOCK_EX);
			$return = '';
			while (!feof($fp)) {
				$return .= fgets($fp, 4096);
			}
			fclose($fp);
			return $return;
		}
	} else {
		return file_get_contents($filename);
	}
}
static public function nb($number) {
	return number_format($number, 2, '.', '');
}
static public function gettaskpercent($key) {
	$file = str_replace('[key]', $key, TASKFILE);
	$offsetfile = str_replace('[key]', $key, TASKFILEOFFSET);

	if(!file_exists($file)) return 100;

	$total = filesize($file);
	if(!file_exists($offsetfile)) return 0;
	$current = self::readfromfile($offsetfile);
	if($current >= $total) {
		@self::akunlink($file);
		@self::akunlink($offsetfile);
		return 99.99;
	}
	return min(99.99, self::nb($current * 100 / $total));
}
static public function ak_mkdir($dirname) {
	$dirname = str_replace('\\', '/', $dirname);
	$a_path = explode('/', $dirname);
	if(count($a_path) == 0) {
		return mkdir($dirname);
	} else {
		array_pop($a_path);
		$path = @implode('/', $a_path);
		if(!is_dir($path.'/')) self::ak_mkdir($path);
		if(!file_exists($dirname)) return @mkdir($dirname);
	}
}
static public function thetime() {
	global $timedifference;
	return time() + $timedifference * 3600;
}
static public function createpathifnotexists($path) {
	if(!file_exists($path)) self::ak_mkdir($path);
}
static public function ak_touch($file) {
	$dir = dirname($file);
	self::ak_mkdir($dir);
	return touch($file, self::thetime());
}
static public function gettask($key, $num = 0, $test = 0) {
	$pid=0;
	$cc_pid_path=PID_PATH;
	if($num == 0) {
		$onereturn = 1;
		$num = 1;
	} elseif($num == -1) {
		$num = PHP_INT_MAX;
	}
	if(substr($key, 0, 1) === '*') {
		$key = substr($key, 1);
		$cc = 1;
		self::createpathifnotexists($cc_pid_path);
		self::createpathifnotexists("$cc_pid_path/$key");
	}
	$file = str_replace('[key]', $key, TASKFILE);
	if(!file_exists($file)) {
		self::akunlink("$cc_pid_path/$key/$pid");
		return false;
	}
	$offsetfile = str_replace('[key]', $key, TASKFILEOFFSET);
	if(!file_exists($offsetfile)) touch($offsetfile);
	$task = '';
	($fo = @fopen($offsetfile, 'r+')) || ($fo = @fopen($offsetfile, 'w'));
	flock($fo, LOCK_EX);
	fseek($fo, 0);
	$offset = fgets($fo);
	$offset = (int)$offset;
	if(!$fp = fopen($file, 'r')) {
		flock($fo, LOCK_UN);
		fclose($fo);
		self::akunlink($file);
		self::akunlink($offsetfile);
		self::akunlink("$cc_pid_path/$key/$pid");
		return '';
	}
	fseek($fp, $offset);
	$i = 0;
	$tasks = array();
	while(!feof($fp)) {
		$task = fgets($fp);
		$offset += strlen($task);
		$task = substr($task, 0, -1);
		if($task != '') {
			$i ++;
			$tasks[] = $task;
			if($i >= $num) break;
		}
	}
	fclose($fp);
	if(empty($test)) {
		rewind($fo);
		fwrite($fo, $offset);
		flock($fo, LOCK_UN);
	}
	fclose($fo);
	if(empty($tasks)) {
		@self::akunlink($file);
		@self::akunlink($offsetfile);
		self::akunlink("$cc_pid_path/$key/$pid");
		return false;
	} else {
		if(!empty($pid)) self::ak_touch("$cc_pid_path/$key/$pid");
		foreach($tasks as $k => $v) {
			$v = str_replace('#\n#', "\n", $v);
			if(substr($v, 0, 2) == 'a:') $v = unserialize($v);
			$tasks[$k] = $v;
		}
		if(!isset($onereturn)) {
			return $tasks;
		} else {
			return current($tasks);
		}
	}
}




}

?>