<?php
function smarty_block_nocache($_arr, $_content) {
		return $_content;	
}
?>