$(function(){
	$('#pass').validate({
		   highlight:function(element,errorClass){
		   $(element).css('border','1px solid red');   
		   $(element).parent().find('span').html(' ').removeClass('succ'); 
		   },
		   unhighlight:function(element,errorClass){
		   $(element).css('border','1px solid #ccc');
		   $(element).parent().find('span').html(' ').addClass('succ');  
		   },
		   rules:{
			   	username:{
					required:true
				},
				password:{
					required:true,
					minlength:5
				},
				notpassword:{
					required:true,
					equalTo:"#pass1"
				}
			},
		 messages:{
			 	username:{
					required:'请填写用户名!'
				},
				password:{
					required:'请填写密码!',
					minlength:jQuery.format('密码不能小于{0}位')
				},
				notpassword:{
					required:'重复密码不能为空!',
					equalTo:'两次密码输入不一致!' 
				}
			}
		});	
});