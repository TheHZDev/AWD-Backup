$(function(){
	$('#addlink').validate({
		   highlight:function(element,errorClass){
		   $(element).css('border','1px solid red');   
		   $(element).parent().find('span').html(' ').removeClass('succ'); 
		   },
		   unhighlight:function(element,errorClass){
		   $(element).css('border','1px solid #ccc');
		   $(element).parent().find('span').html(' ').addClass('succ');  
		   },
		   rules:{
			   linkname:{
					required:true
				},
				linkurl:{
					required:true
				}
			},
		 messages:{
			 linkname:{
					required:'请填写链接名称!'
				},
				linkurl:{
					required:'请填写URL!'
				}
			}
		});	
});

//选择全部
function CheckAll(form) {
	  for (var i = 0 ;i<form.elements.length; i++) {
	   var e = form.elements[i] ;  
	   if (e.name!='chkall') {   
	    e.checked = form.chkall.checked; 
	   }
	  }
} 