$(function(){
	//编缉器配置xheditor
	$('#content').xheditor({
		upImgUrl:"?a=call&m=xhUp&type=xh",
		upImgExt:"jpg,jpeg,gif,png",
		html5Upload:false,
		tools:'Cut,Copy,Paste,Pastetext,|,Blocktag,Fontface,FontSize,Bold,Italic,Underline,Strikethrough,FontColor,BackColor,SelectAll,Removeformat,|,Align,List,Outdent,Indent,|,Link,Unlink,Anchor,Img,Hr,Emot,Table,|,Source,Preview,Fullscreen,Print,About'	
	});	
	$('#add').validate({
		   highlight:function(element,errorClass){
		   $(element).css('border','1px solid red');   
		   $(element).parent().find('span').html(' ').removeClass('succ'); 
		   },
		   unhighlight:function(element,errorClass){
		   $(element).css('border','1px solid #ccc');
		   $(element).parent().find('span').html(' ').addClass('succ');  
		   },
		   rules:{
			   dan_name:{
					required:true
				},
				filename:{
					required:true,
					html:true
				},
				title:{
					required:true
				}
			},
		 messages:{
			 dan_name:{
					required:'请填写单页名称!'
				},
				filename:{
					required:'请填写文件名!'
				},
				title:{
					required:'请填写单页标题!'
				}
			}
		});	
});
$.validator.addMethod('html',function(value,element){
	var tel=/html/;
	return this.optional(element) || (tel.test(value));
},'文件名填写错误!');
//弹窗居中
function centerWindow(url, name, width, height) {
	var left = (screen.width - width) / 2;
	var top = (screen.height - height) / 2 - 50;
	window.open(url, name, 'width='+width+',height='+height+',top='+top+',left='+left);
}
//选择全部
function CheckAll(form) {
	  
	  for (var i = 0 ;i<form.elements.length; i++) {
	   var e = form.elements[i] ;  
	   if (e.name!='chkall') {
	   
	    e.checked = form.chkall.checked; 
	   }
	  }
	  
	 } 