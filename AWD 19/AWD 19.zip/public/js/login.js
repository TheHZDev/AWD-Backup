function checklogin() {
	var fm = document.login;
	if (fm.username.value == '') {
		layer.msg('请填写用户名!',{
			skin:'msg-class',
			time:1500,
			shade: 0.3,//遮罩层透明度
			icon:2,//1-6
			area: ['50px'],	
			offset: ['75px'],
		});
		fm.username.focus();
		return false;
	}
	if (fm.password.value == '') {
		layer.msg('请填写密码!',{
			skin:'msg-class',
			time:1500,
			shade: 0.3,//遮罩层透明度
			icon:2,//1-6
			area: ['50px'],	
			offset: ['75px']
		});
		fm.password.focus();
		return false;
	}
	if (fm.code.value == '') {
		layer.msg('请填写验证码!',{
			skin:'msg-class',
			time:1500,
			shade: 0.3,//遮罩层透明度
			icon:2,//1-6
			area: ['50px'],	
			offset: ['75px']
		});
		fm.code.focus();
		return false;
	}
	if (fm.ajaxlogin.value != '') {
		layer.msg('用户名或密码错误!',{
			skin:'msg-class',
			time:1500,
			shade: 0.3,//遮罩层透明度
			icon:2,//1-6
			area: ['50px'],	
			offset: ['75px']
		});
		fm.password.focus();
		return false;
	}
	if (fm.ajaxcode.value != '') {
		layer.msg('验证码不正确!',{
			skin:'msg-class',
			time:1500,
			shade: 0.3,//遮罩层透明度
			icon:2,//1-6
			area: ['50px'],	
			offset: ['75px']
		});
		fm.code.focus();
		return false;
	}
	
	layer.msg('登录成功!',{
		skin:'msg-class',
		time:3000,
		shade: 0.3,//遮罩层透明度
		icon:1,//1-6
		area: ['50px'],	
		offset: ['75px']
	});
	return true;
	
}
function checkLogin(){
    var user = document.getElementById("user");
    var pass = document.getElementById("pass");
    var ajaxlogin = document.getElementById("ajaxlogin");
    var ajax = new AjaxObj();
    ajax.swRequest({
        method:"POST",
        sync:false,
        url:'?a=login&m=ajaxLogin',
        data:"user="+user.value+"&pass="+pass.value,
        success: function(msg) {
            if(msg==1){
                ajaxlogin.value = 'true';
            } else {
				ajaxlogin.value = '';
			}
        },
        failure: function(a) {
            alert(a);
        },
        soap:this
    });
}


function checkCode(){
    var code = document.getElementById("code");
    var ajaxcode = document.getElementById("ajaxcode");
    var ajax = new AjaxObj();
    ajax.swRequest({
        method:"POST",
        sync:false,
        url:'?a=login&m=ajaxCode',
        data:"code="+code.value,
        success: function(msg) {
            if(msg==1){
                ajaxcode.value = 'true';//不相等  
            } else {
				ajaxcode.value = '';//相等
			}
        },
        failure: function(a) {
            alert(a);
        },
        soap:this
    });
}