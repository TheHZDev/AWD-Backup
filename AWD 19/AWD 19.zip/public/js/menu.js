$(function(){
	$('#menu em').toggle(function(){
		$(".nav").show()}, 
	    function(){
	        $(".nav").hide()
	});
});