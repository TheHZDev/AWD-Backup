$(function(){
	$('#sys').validate({
		   highlight:function(element,errorClass){
		   $(element).css('border','1px solid red');   
		   $(element).parent().find('span').html(' ').removeClass('succ'); 
		   },
		   unhighlight:function(element,errorClass){
		   $(element).css('border','1px solid #ccc');
		   $(element).parent().find('span').html(' ').addClass('succ');  
		   },
		   rules:{
			   	title:{
					required:true
				},
				url:{
					required:true
				},
				thumb:{
					required:true
				},
				keywords:{
					required:true
				},
				description:{
					required:true
				},
				footer:{
					required:true
				},
				page_size:{
					required:true
				},
				page_size_index:{
					required:true
				}
				
			},
		 messages:{
			 	title:{
					required:'请填写网站标题!'
				},
				url:{
					required:'请填写域名!'
				},
				thumb:{
					required:'请上传LOGO!'
				},
				keywords:{
					required:'请填写网站关键词!'
				},
				description:{
					required:'请填写描述!'
				},
				footer:{
					required:'请填写底部信息!'
				},
				page_size:{
					required:'后台分页条数不能为空!'
				},
				page_size_index:{
					required:'前台分页条数不能为空!'
				}
			}
		});	
});
//弹窗居中
function centerWindow(url, name, width, height) {
	var left = (screen.width - width) / 2;
	var top = (screen.height - height) / 2 - 50;
	window.open(url, name, 'width='+width+',height='+height+',top='+top+',left='+left);
}