<?php
//分类实体类
class NavModel extends Model{
	private $id;
	private $nav_name;
	private $nav_ename;
	private $title;
	private $keyword;
	private $info;
	private $sort;
	//拦截器(__set)
	public function __set($_key, $_value) {
		$this->$_key = tool::setFormString($_value);
	}
	
	//拦截器(__get)
	public function __get($_key){
		return $this->$_key;
	}
	
	//添加分类
	public function add_nav(){
		$_sql="INSERT INTO
						my_nav(
								nav_name,
								nav_ename,
								title,
								keyword,
								info,
								sort,
								time	
								)
						VALUES(
							    '$this->nav_name',
							    '$this->nav_ename',
							    '$this->title',
							    '$this->keyword',
								'$this->info',
								".parent::nextId('my_nav').",
								NOW()
								)";
		return parent::add($_sql);
	}
	//修改分类
	public function update_nav(){
		$_sql="UPDATE
					my_nav
				SET
					nav_name='$this->nav_name',
					nav_ename='$this->nav_ename',
					title='$this->title',
					keyword='$this->keyword',
					info='$this->info'
				WHERE
					id='$this->id'
				LIMIT 1";
		return parent::update($_sql);
	}	
	//删除分类
	public function delete_nav(){
		$_sql="DELETE
					FROM
						my_nav
					WHERE
						id='$this->id'";
		return parent::delete($_sql);
	}
	//查询所有分类
	public function getAllNav(){
		$_sql="SELECT *
				 	FROM 
						my_nav
					ORDER BY
						sort ASC";
		return parent::select($_sql);
	}
	//查询一个分类
	public function findOne(){
		$_sql="SELECT *
					FROM 
						my_nav
					WHERE
						id='$this->id'
					LIMIT 
						1";
		return parent::select($_sql);
	}
	//查询单个导航(前台用)
	public function getOneNav() {
		$_sql = "SELECT 
						n1.title,
						n1.keyword,
						n1.info,
						n1.id,
						n1.nav_ename,
						n1.nav_name,
						n2.nav_ename ename,
						n2.id iid,
						n2.nav_name nnav_name
					FROM
						my_nav n1
				LEFT JOIN
						my_nav n2
					ON
						n1.nid=n2.id
					WHERE
						n1.id='$this->id'
					LIMIT 1";
		return parent::select($_sql);
	}
	//查询所属分类
	public function findParent(){
		$_sql="SELECT *
					FROM
						my_nav
					WHERE
						id='$this->nid'
					LIMIT
						1";
		return parent::select($_sql);
	}
	//排序
	public function setNavSort(){
		foreach ($this->sort as $_key=>$_value){
			$_sql.="UPDATE my_nav SET sort='$_value' WHERE id='$_key';";
		}
		return parent::update($_sql);
	}	
}


?>