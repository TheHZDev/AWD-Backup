<?php
//Model基类
class Model {
	protected $_db=null;
	public function __construct(){
		$this->_db=DB::getInstance()->_pdo;
	}
	//验证一条数据模型
	protected function one($_sql){
		return $this->execute($_sql);
	}
	//修改数据模型
	protected function update($_sql){
		return $this->execute($_sql)->rowCount();
	}
	//增加数据模型
	protected function add($_sql){
		return $this->execute($_sql)->rowCount();
	}
	//删除数据模型
	protected function delete($_sql){
		return $this->execute($_sql)->rowCount();
	}
	//查询所有
	protected function select($_sql){
		$_stmt = $this->execute($_sql);
		while (!!$_objs = $_stmt->fetchObject()) {
			$_result[] = $_objs;
		}
		return $_result;
	}
	//总记录
	protected function total($_sql){
		$_stmt=$this->execute($_sql);
		return $_stmt->fetchObject()->count;
	}
	//得到下一个ID
	protected function nextId($_table) {
		$_sql = "SHOW TABLE STATUS LIKE '$_table'";
		$_stmt = $this->execute($_sql);
		return $_stmt->fetchObject()->Auto_increment;
	}
	//执行SQL
	protected function execute($_sql){
		try{
			$_stmt=$this->_db->prepare($_sql);
			$_stmt->execute();
		}catch (PDOException $e){
			exit('SQL语句:'.$_sql.'<br />错误信息:'.$e->getMessage());
		}
		return $_stmt;
	}
}
 

?>