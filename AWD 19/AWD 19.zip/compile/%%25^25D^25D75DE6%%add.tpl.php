<?php /* Smarty version 2.6.26, created on 2018-08-29 21:49:57
         compiled from admin/link/add.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>添加链接</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/link.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/link.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 添加链接</div>
<div id="link">
<form name="add" method="post" id="addlink" action="?a=link&m=add">
<dl>
	<dd><strong>链接名称 :</strong>　<input type="text" name="linkname" class="text"/>&nbsp;<span class="red">*</span></dd>
	<dd><strong>链接URL:</strong>　<input type="text" name="linkurl" class="text"/>&nbsp;<span class="red">*</span></dd>
	<dd class="noline"><input type="submit" name="send" value="添加链接" class="submit"/></dd>
</dl>
</form>
</div>
</body>
</html>