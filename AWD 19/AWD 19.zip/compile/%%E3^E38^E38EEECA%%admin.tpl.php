<?php /* Smarty version 2.6.26, created on 2018-08-29 21:39:42
         compiled from admin/public/admin.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>后台管理首页</title>
<link rel="icon" href="../view/index/images/favicon.ico" type="image/icon" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/admin.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/iframe.js"></script>
<script type="text/javascript" src="../public/js/channel.js"></script>
</head>
<body>
<div id="header">
<img src="../view/admin/images/yccms.png"/>
<p>您好，<span style="color:red;"><?php echo $this->_tpl_vars['admin']['username']; ?>
</span> | <a href="../index.html" target="_black">网站首页</a> | <a href="?a=admin&m=logout">退出</a></p>
	<ul>
		<li><a href="javascript:channel(0)" id="nav1" onclick="admin_top_nav(1)" class="selected">系统设置</a></li>
		<li><a href="javascript:channel(1)" id="nav2" onclick="admin_top_nav(2)">内容管理</a></li>
		<li><a href="javascript:channel(2)" id="nav3" onclick="admin_top_nav(3)">静态生成</a></li>
		<li><a href="javascript:channel(3)" id="nav4" onclick="admin_top_nav(4)">其它功能</a></li>
	</ul>
</div>
<div id="sidebar">
	<dl style="display:block">
		<dt class="set">系统设置</dt>
		<dd><a href="?a=admin&m=main" class="menu_a on" target="in">系统信息</a></dd>
		<dd><a href="?a=system&m=main" class="menu_a" target="in">首页内容</a></dd>
		<dd><a href="?a=system" class="menu_a" target="in">系统设置</a></dd>
		<dd></dd>
	</dl>
	<dl style="display:none">
		<dt class="con">内容管理</dt>
		<dd><a href="?a=nav" class="menu_a" target="in">分类管理</a></dd>
		<dd><a href="?a=nav&m=add" class="menu_a" target="in">添加分类</a></dd>
		<dd><a href="?a=article" class="menu_a" target="in">文章列表</a></dd>
		<dd><a href="?a=article&m=add" class="menu_a" target="in">添加文章</a></dd>
		<dd></dd>
	</dl>
	<dl style="display:none">
		<dt class="static">静态生成</dt>
		<dd><a href="?a=html" class="menu_a" target="in">生成首页</a></dd>
		<dd><a href="?a=html&m=lists" class="menu_a" target="in">生成列表</a></dd>
		<dd><a href="?a=html&m=arts" class="menu_a" target="in">生成内容</a></dd>
		<dd></dd>
	</dl>
	<dl style="display:none">
		<dt class="other">其它功能</dt>
		<dd><a href="?a=admin&m=update" class="menu_a" target="in">修改密码</a></dd>
		<dd><a href="?a=pic" class="menu_a" target="in">图片管理</a></dd>
		<dd><a href="?a=link" class="menu_a" target="in">友情链接</a></dd>
		<dd><a href="?a=admin&m=cleancache" class="menu_a" target="in">清理编译缓存</a></dd>
		<dd></dd>
	</dl>
</div>
<div id="main">
	<iframe src="?a=admin&m=main" frameborder="0" name="in"></iframe>
</div>
</body>
</html>