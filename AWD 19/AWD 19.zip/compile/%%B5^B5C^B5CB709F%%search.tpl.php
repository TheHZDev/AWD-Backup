<?php /* Smarty version 2.6.26, created on 2018-08-29 13:42:53
         compiled from index/public/search.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="applicable-device" content="pc,mobile"/>
<meta name="MobileOptimized" content="width"/>
<meta name="HandheldFriendly" content="true"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title><?php echo $this->_tpl_vars['keyword']; ?>
_搜索<?php echo $this->_tpl_vars['t_fix']; ?>
</title>
<meta name="keywords" content="<?php echo $this->_tpl_vars['keyword']; ?>
" />
<meta name="description" content="<?php echo $this->_tpl_vars['keyword']; ?>
" />
<link rel="icon" href="../view/index/images/favicon.ico" type="image/icon" />
<link rel="stylesheet" type="text/css" href="../view/index/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/index/style/so.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/menu.js"></script>
<script type="text/javascript" src="../public/js/search.js"></script>
<script type="text/javascript">
document.write('<script type="text/javascript" src="../config/count.php?a=online&m=w&lailuUrl='+document.referrer+'"><\/script>');
</script>
</head>
<body>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "index/public/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?> 
<div id="content">
<div id="menu">
<em></em><h1><?php echo $this->_tpl_vars['webname']; ?>
</h1>
</div>
<div id="so">
<p class="location">当前位置 : <a href="../">首页</a> &gt; 搜索 (共找到 " <span class="red"><?php echo $this->_tpl_vars['keyword']; ?>
</span> "相关内容 <span class="red"><?php echo $this->_tpl_vars['sum']; ?>
</span> 条)</p>
<?php $_from = $this->_tpl_vars['search']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['value']):
?>
<dl>
<dt><a href="../<?php echo $this->_tpl_vars['value']->html; ?>
" target="_blank"><?php echo $this->_tpl_vars['value']->title; ?>
</a></dt>
<dd><em><?php echo $this->_tpl_vars['value']->time; ?>
</em>&nbsp;<?php echo $this->_tpl_vars['value']->info; ?>
</dd>
</dl>
<?php endforeach; else: ?>
<p class="error">抱歉!未找到任何内容。</p>
<?php endif; unset($_from); ?>
<div id="page"><?php echo $this->_tpl_vars['page']; ?>
</div>
</div><!--so结束--> 
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "index/public/sidebar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?> 
</div><!--content结束--> 
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "index/public/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?> 
</body>
</html>