<?php /* Smarty version 2.6.26, created on 2018-08-29 21:24:37
         compiled from admin/link/update.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>修改链接</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/link.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/link.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 修改链接</div>
<div id="link">
<form name="add" method="post" id="addlink" action="?a=link&m=update">
<input type="hidden" name="id" value="<?php echo $this->_tpl_vars['id']; ?>
" />
<input type="hidden" name="prev_url" value="<?php echo $this->_tpl_vars['prev_url']; ?>
" />
<dl>
	<dd><strong>链接名称 :</strong>　<input type="text" name="linkname" value="<?php echo $this->_tpl_vars['linkname']; ?>
" class="text"/>&nbsp;<span class="red">*</span></dd>
	<dd><strong>链接URL:</strong>　<input type="text" name="linkurl" value="<?php echo $this->_tpl_vars['linkurl']; ?>
" class="text"/>&nbsp;<span class="red">*</span></dd>
	<dd class="noline"><input type="submit" name="send" value="修改链接" class="submit"/></dd>
</dl>
</form>
</div>
</body>
</html>