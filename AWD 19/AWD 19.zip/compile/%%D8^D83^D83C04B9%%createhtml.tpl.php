<?php /* Smarty version 2.6.26, created on 2018-08-15 21:45:38
         compiled from admin/public/createhtml.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>生成HTML</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/html.css" />
<script type="text/javascript" src="../public/js/search.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 生成内容页静态</div>
<div id="createhtml">
<form method="GET" action="?">
<input type="hidden" name="a" value='html' />
<input type="hidden" name="m" value='arts' />
<dl>
<dt>提示:</dt>
<dd>生成过程中请不要刷新页面。</dd>
<?php if ($_GET['art']): ?>
<dd><span class="state">内容生成完毕 !共 <?php echo $_GET['art']; ?>
 条。</span></dd>
<?php endif; ?>
<dd class="no">更新所有文章&nbsp;<input type="submit" name="send" value="开始生成" class="submit"/></dd>
</dl>
</form>
</div>
</body>
</html>