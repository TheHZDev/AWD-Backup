<?php /* Smarty version 2.6.26, created on 2018-08-13 00:05:21
         compiled from admin/public/system.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>系统设置</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/system.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/sys.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 系统设置</div>
<div id="system">
<form name="add" id="sys" method="post" action="?a=system">
<dl>
<dd><strong>网站标题 :</strong>　<input type="text" name="title" value="<?php echo $this->_tpl_vars['title']; ?>
" class="text"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>网站名称 :</strong>　<input type="text" name="webname" value="<?php echo $this->_tpl_vars['webname']; ?>
" class="text"/>&nbsp;<em class="gray">文章标题后缀，不需要可以留空。</em></dd>
<dd><strong>网站LOGO:</strong>　<input type="text" name="thumb" value="<?php echo $this->_tpl_vars['thumb']; ?>
" class="text" readonly="readonly"/>&nbsp; 
	<input type="button" value="上传LOGO"  class="button" onclick="centerWindow('?a=call&m=upfile&type=content','upfile','400','150')" />&nbsp;<span class="red">*</span>&nbsp;<em class="gray">宽度为960像素，必须是PNG格式，大小不超过2M</em>
	<img name="pic" style="display:none;" class="pic" />
	</dd>
<dd><strong>网站域名 :</strong>　<input type="text" name="url" value="<?php echo $this->_tpl_vars['url']; ?>
" class="text"/>&nbsp;<span class="red">*</span>&nbsp;<em class="gray">后面不带斜线，如：http://www.abc.com</em></dd>
<dd><strong>关键词 :</strong>　<input type="text" name="keywords" value="<?php echo $this->_tpl_vars['keywords']; ?>
" class="text"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>网站描述 :</strong>　<textarea name="description"><?php echo $this->_tpl_vars['description']; ?>
</textarea>&nbsp;<span class="red">*</span></dd>
<dd><strong>前台分页 :</strong>　<input type="text" name="page_size_index" value="<?php echo $this->_tpl_vars['page_size_index']; ?>
" class="text small"/>&nbsp;<span class="red">*</span>&nbsp;<em class="gray">前台文章列表每页显示条数</em></dd>
<dd><strong>后台分页 :</strong>　<input type="text" name="page_size" value="<?php echo $this->_tpl_vars['page_size']; ?>
" class="text small"/>&nbsp;<span class="red">*</span>&nbsp;<em class="gray">后台文章列表每页显示条数</em></dd>
<dd><strong>底部信息 :</strong>　<textarea name="footer"><?php echo $this->_tpl_vars['footer']; ?>
</textarea>&nbsp;<span class="red">*</span></dd>
<dd class="noline"><input type="submit" name="send" value="保存配置" class="submit"/></dd>
</dl>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>1、除“网站名称”外，其它为必填项。</li>
<li>2、更改保存配置后须进入“静态生成”-“生成首页”使更改生效。</li>
<li>3、网站标题：即网站首页的标题title(不超过30个字符)。</li>
<li>4、网站名称：会显示在文章标题后面，不需要可以留空。例：怎样写原创文章_YCCMS。后面的YCCMS即是网站名称。</li>
<li>5、网站LOGO：网站最上面的图片，宽度为960像素，必须是PNG格式，大小不超过2M。</li>
<li>6、网站域名：填写网站域名，后面不带"/",例：http://www.baidu.com。</li>
<li>7、关  键  词：以逗号","分开。</li>
<li>8、网站描述：网站描述(不超过77个字符)。</li>
<li>9、前台分页：网站前台分类列表每页显示文章条数。</li>
<li>10、后台分页：网站后台文章列表每页显示文章条数。</li>
<li>11、底部信息：会显示在网站最底部。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>