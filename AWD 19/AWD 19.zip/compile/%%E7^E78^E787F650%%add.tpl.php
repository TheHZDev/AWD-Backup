<?php /* Smarty version 2.6.26, created on 2018-08-19 14:23:01
         compiled from admin/nav/add.tpl */ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>添加分类</title>
<link rel="stylesheet" type="text/css" href="../view/admin/style/basic.css" />
<link rel="stylesheet" type="text/css" href="../view/admin/style/nav.css" />
<script type="text/javascript" src="../public/js/jquery-1.8.1.min.js"></script>
<script type="text/javascript" src="../public/js/jquery.validate.js"></script>
<script type="text/javascript" src="../public/js/nav.js"></script>
</head>
<body style="background:#EBF1F3;">
<div id="current">当前位置 &gt; <a href="?" target="_parent">后台首页</a>&gt; 添加分类</div>
<div id="nav">
<form name="add" id="add" method="post" action="?a=nav&m=add">
<dl>
<dd><strong>分类名称 :</strong>　<input type="text" name="nav_name" class="text"/>&nbsp;<span class="red">*</span>&nbsp;<em class="gray">分类名称(必填)</em></dd>
<dd><strong>英文别名 :</strong>　<input type="text" name="nav_ename" class="text"/>&nbsp;<span class="red">*</span>&nbsp;<em class="gray">英文名称(必填)</em></dd>
<dd><strong>分类标题 :</strong>　<input type="text" name="title" class="text"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>关 键 词 :</strong>　<input type="text" name="keyword" class="text"/>&nbsp;<span class="red">*</span></dd>
<dd><strong>描 述 :</strong>　<textarea name="info"></textarea>&nbsp;<span class="red">*</span></dd>
<dd><input type="submit" name="send" value="添加分类" class="submit"/></dd>
</dl>
</form>
<table class="sm">
<tr><th>设置帮助</th></tr>
<tr><td>
<ul>
<li>1、分类名称：可以是中文、英文或数字。</li>
<li>2、英文别名：生成的目录名称（可以是英文或数字）。</li>
</ul>
</td></tr>
</table>
</div>
</body>
</html>