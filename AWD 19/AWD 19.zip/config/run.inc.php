<?php
//开启session
session_start();
//超时时间
@set_time_limit(0);
//设置编码
header('Content-Type:text/html;charset=utf-8');
//错误级别,报告警告之外的所有错误
error_reporting(E_ALL ^ E_NOTICE);
//设置时区
date_default_timezone_set('PRC'); 
//网站绝对根路径
define('ROOT_PATH',str_replace('\\','/',substr(dirname(__FILE__),0,-7))); 
//引入配置文件
require ROOT_PATH.'/config/config.inc.php';
//引入Smarty
require ROOT_PATH.'/public/smarty/Smarty.class.php';
//自动加载类
function __autoload($_className){
	if(substr($_className,-6)=='Action'){
		require ROOT_PATH.'/controller/'.ucfirst($_className).'.class.php';	
	}elseif(substr($_className, -5) == 'Model'){
		require ROOT_PATH.'/model/'.ucfirst($_className).'.class.php';
	}else{
		require ROOT_PATH.'/public/class/'.ucfirst($_className).'.class.php';
	}
}
//单入口
Factory::setAction()->run();
?>