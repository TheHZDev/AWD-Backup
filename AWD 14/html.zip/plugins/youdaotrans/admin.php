<?php
/**
 * 有道翻译<后台应用>
 * @package phpok\plugins
 * @作者 phpok.com
 * @版本 5.0.000
 * @授权 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年01月17日 09时55分
**/
class admin_youdaotrans extends phpok_plugin
{
	public $me;
	private $app_key = '';
	private $app_secret = '';
	private $btns = '';
	private $html_id = '';
	private $input_ids = '#identifier';
	private $is_https = 0;
	public function __construct()
	{
		parent::plugin();
		$this->me = $this->_info();
		if($this->me && $this->me['param']){
			if($this->me['param']['app_key']){
				$this->app_key = $this->me['param']['app_key'];
			}
			if($this->me['param']['app_secret']){
				$this->app_secret = $this->me['param']['app_secret'];
			}
			if($this->me['param']['btns']){
				$this->btns = $this->me['param']['btns'];
			}
			if($this->me['param']['html_elements']){
				$this->html_id = $this->me['param']['html_elements'];
			}
			if($this->me['param']['input_ids']){
				$this->input_ids = $this->me['param']['input_ids'];
			}
			if($this->me['param']['is_https']){
				$this->is_https = $this->me['param']['is_https'];
			}
		}
	}
	
	
	
	/**
	 * 系统内置在</body>节点前输出HTML内容，如果不使用，请删除这个方法
	**/
	public function html_phpokbody()
	{
		if(!$this->app_key || !$this->app_secret || !$this->btns || !$this->html_id || !$this->input_ids){
			return true;
		}
		$this->assign('youdao_btn_ids',$this->btns);
		$this->assign('youdao_html_ids',$this->html_id);
		$this->assign('youdao_input_ids',$this->input_ids);
		$this->_show("admin_phpokbody.html");
	}

	private function err_code($id=0)
	{
		if(!$id){
			return false;
		}
		$data = $this->lib('xml')->read($this->me['path'].'err.xml');
		if($data['info'.$id]){
			return $data['info'.$id];
		}
		return false;
	}
	
	public function trans()
	{
		$this->config('is_ajax',true);
		if(!$this->app_key || !$this->app_secret || !$this->btns || !$this->html_id || !$this->input_ids){
			$this->error('未指定要翻译的文本');
		}
		$keywords = $this->get('keywords');
		if(!$keywords){
			$this->error('参数未配置完整');
		}
		$url = 'http://openapi.youdao.com/api';
		if($this->is_https){
			$url = 'https://openapi.youdao.com/api';
		}
		$post = array('q'=>$keywords,'from'=>'auto','to'=>'EN','appKey'=>$this->app_key);
		$post['salt'] = $this->lib('common')->str_rand(3,'number');
		$post['sign'] = strtoupper(md5($this->app_key.$keywords.$post['salt'].$this->app_secret));
		$this->lib('curl')->is_post(true);
		foreach($post as $key=>$value){
			$this->lib('curl')->post_data($key,$value);
		}
		$data = $this->lib('curl')->get_json($url);
		if(!$data['status']){
			$this->error($data['info']);
		}
		if($data['errorCode']){
			$tip = $this->err_code($data['errorCode']);
			if(!$tip){
				$tip = '异常错误，请检查';
			}
			$this->error($tip);
		}
		$info = current($data['translation']);
		$info = str_replace(array(' ',"'",'"'),'-',$info);
		$info = str_replace('.','',$info);
		$this->success($info);
	}
}