<?php
/**
 * 有道翻译<插件安装>
 * @package phpok\plugins
 * @作者 phpok.com
 * @版本 5.0.000
 * @授权 http://www.phpok.com/lgpl.html PHPOK开源授权协议：GNU Lesser General Public License
 * @时间 2018年01月17日 09时55分
**/
class install_youdaotrans extends phpok_plugin
{
	public $me;
	public function __construct()
	{
		parent::plugin();
		$this->me = $this->_info();
	}
	
	/**
	 * 插件安装时，增加的扩展表单输出项，如果不使用，请删除这个方法
	**/
	public function index()
	{
		return $this->_tpl('setting.html');
	}
	
	/**
	 * 插件安装时，保存扩展参数，如果不使用，请删除这个方法
	**/
	public function save()
	{
		$id = $this->_id();
		$ext = array();
		$ext['app_key'] = $this->get('app_key');
		$ext['app_secret'] = $this->get('app_secret');
		$ext['btns'] = $this->get('btns');
		$ext['html_elements'] = $this->get('html_elements');
		$ext['input_ids'] = $this->get('input_ids');
		$ext['is_https'] = $this->get('is_https','int');
		$this->_save($ext,$id);
	}
	
	
}