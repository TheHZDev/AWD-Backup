<?php
$mc_pages=array (
  'team' => 
  array (
    'file' => 'kdl0u0',
    'path' => 'team',
    'state' => 'publish',
    'title' => 'Bugku团队招人!',
    'date' => '2022-01-01',
    'time' => '00:00:00',
    'can_comment' => '1',
  ),
)
?>