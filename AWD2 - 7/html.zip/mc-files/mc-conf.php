<?php
$mc_config = array (
  'version' => '/*MINICMS_VERSION*/',
  'site_link' => '',
  'site_name' => '熊大的日志',
  'site_desc' => '又一个awd靶场',
  'user_name' => 'admin',
  'user_pass' => '123456',
  'user_nick' => '神秘人',
  'comment_code' => '',
)
?>