<?php
$post_title = 'bugku images';
$post_category = '';
$post_content = '<p>111111</p>';
$post_time = '1637394026';
?>