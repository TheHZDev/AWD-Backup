<?php
$title = 'ctf';
$content = '<p>11111</p>';
$hidden = 'no';
?>