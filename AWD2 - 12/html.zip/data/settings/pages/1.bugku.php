<?php
$title = 'bugku';
$content = '<div><span>S2赛季开启！官方消息推送群：641952034</span></div>
<div> </div>
<div><span style="color: #5fb878;">Bu</span>gku AWD S2赛季排位赛玩法规则：</div>
<div> </div>
<div>时间：每周四报名，每周六晚上19:00开赛</div>
<div> </div>
<div>人数：50支战队，每个战队3人参加</div>
<div> </div>
<div>提前2天开启报名由队长报名，报名需填写队员真实IP开赛前10分钟可免费修改，开启后金币修改</div>
<div> </div>
<div> </div>
<div> </div>
<div><span>积分规则：</span></div>
<div> </div>
<div>每场比赛基础分2000分赛后根据所剩积分除以100，例：A战队打完比赛后积分为3500分那么赛后所积段位分为35分</div>
<div> </div>
<div>倔强青铜 0-100分</div>
<div> </div>
<div>不屈白银 100-250分</div>
<div> </div>
<div>荣耀黄金 250-450分</div>
<div> </div>
<div>华贵铂金 450-700分</div>
<div> </div>
<div>璀璨钻石 700-1000分</div>
<div> </div>
<div>攻防大师 1000分以上（攻防大师段位第一名为最强王者）</div>
<div> </div>
<div> </div>
<div> </div>
<div><span>奖励：</span></div>
<div> </div>
<div>每周的前三名战队有头像框、金币奖励</div>
<div> </div>
<div>赛季末前三有实体奖杯、金币、头像框等奖励</div>';
$hidden = 'no';
?>