<?php
$title = 'awd';
$content = '<p>111111</p>';
$hidden = 'no';
?>