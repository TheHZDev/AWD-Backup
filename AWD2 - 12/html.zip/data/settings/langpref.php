<?php
$langpref = 'zh-cn.php';
?>