<?php
$sitetitle = 'bugku awd';
$email = 'admin@bugku.com';
?>