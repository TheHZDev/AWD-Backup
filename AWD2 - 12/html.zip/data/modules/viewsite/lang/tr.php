<?php
$lang['viewsite']['module_name'] = 'site linkine bak';
$lang['viewsite']['module_intro'] = 'Modül geliştiricilerine yardım etmek için geliştirildi. Yönetim menüsünden siteye bir link eklemek için kullanılır.';
$lang['viewsite']['message'] = 'siteye bak';
?>