<?php
$lang['viewsite']['module_name'] = 'ver enlace del sitio';
$lang['viewsite']['module_intro'] = 'Creado para mostrar los enlaces de los diseñadores del módulo. Añade un enlace al sitio en el menú de administración.';
$lang['viewsite']['message'] = 'ver el sitio';
?>