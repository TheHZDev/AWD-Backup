<?php
$lang['contactform']['module_name'] = 'kontakto forma';
$lang['contactform']['module_intro'] = 'kontakto forma, leidžia jūsų lankytojams atsiųsti jums zinute';
$lang['contactform']['fields'] = 'Jus neužpildėte visų laukelių teisingai.';
$lang['contactform']['email_title'] = 'Pranešimas iš jūsų svetainės, nuo';
$lang['contactform']['been_send'] = 'Jūsų žinutė sekmingai išsiusta.';
$lang['contactform']['not_send'] = 'Jūsų žinutė nebuvo išsiusta. Klaida.';
?>