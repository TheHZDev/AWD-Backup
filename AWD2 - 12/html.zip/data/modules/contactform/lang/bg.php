<?php
$lang['contactform']['module_name'] = 'форма за контакт';
$lang['contactform']['module_intro'] = 'с формата за контакт, позволявате на вашите посетители да Ви пратят съобщение';
$lang['contactform']['fields'] = 'Не сте попълнили полетата правилно';
$lang['contactform']['email_title'] = 'Съобщение от вашия сайт';
$lang['contactform']['been_send'] = 'Вашето съобщение е изпратено успешно.';
$lang['contactform']['not_send'] = 'Вашето съобщение не е изпратено, установена е грешка.';
?>