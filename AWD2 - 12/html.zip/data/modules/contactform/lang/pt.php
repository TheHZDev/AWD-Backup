<?php
$lang['contactform']['module_name'] = 'formulário de contactos';
$lang['contactform']['module_intro'] = 'com um formulário de contactos, pode permitir que os seus visitantes lhe enviem uma mensagem';
$lang['contactform']['fields'] = 'Não preencheu todos os campos correctamente.';
$lang['contactform']['email_title'] = 'Mensagem do seu website de';
$lang['contactform']['been_send'] = 'A sua mensagem foi enviada com sucesso.';
$lang['contactform']['not_send'] = 'A sua mensagem não pôde ser enviada, um erro ocorreu.';
?>