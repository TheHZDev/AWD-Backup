<?php
$lang['contactform']['module_name'] = 'iletişim formu';
$lang['contactform']['module_intro'] = 'iletişim formu ile ziyaretçilerinizin size mesaj göndermesini sağlayabilirsiniz';
$lang['contactform']['fields'] = 'Bütün alanları doğru şekilde doldurmadınız.';
$lang['contactform']['email_title'] = 'Sitenizdeki formdan mesaj';
$lang['contactform']['been_send'] = 'Mesajınız gönderildi.';
$lang['contactform']['not_send'] = 'Mesajınız gönderilemiyor, bir hata oluştu.';
?>