<?php
$lang['contactform']['module_name'] = 'ฟอร์มการติดต่อ';
$lang['contactform']['module_intro'] = 'ด้วยฟอร์มการติดต่อ คุณสามารถอนุญาติให้ผู้เยี่ยมชมเว็บไซต์ส่งข้อความถึงคุณได้';
$lang['contactform']['fields'] = 'คุณไม่ได้กรอกข้อมูลในทุกส่วนให้ถูกต้อง';
$lang['contactform']['email_title'] = 'ข้อความจากเว็บไซต์ของคุณจาก';
$lang['contactform']['been_send'] = 'ข้อความของคุณถูกส่งไปเรียบร้อยแล้ว';
$lang['contactform']['not_send'] = 'ข้อความของคุณไม่สามารถส่งได้ เพราะมีข้อผิดพลาดบางประการ';
?>