<?php
$lang['tinymce']['module_name'] = 'TinyMCE';
$lang['tinymce']['module_intro'] = 'Pluck\'a TinyMCE düzenleyicisini ekler. TinyMCE <a href="http://tinymce.moxiecode.com/" target="_blank">Moxiecode</a> tarafından geliştirilmektedir.';
?>