<?php
$lang['tinymce']['module_name']	= 'tinymce';
$lang['tinymce']['module_intro']	= 'Dodaj edytor TinyMCE do plucka. TinyMCE jest rozwijany przez <a href="http://tinymce.moxiecode.com/" target="_blank">Moxiecode</a>.';
?>