<?php
$title = '我留了一个后门';
$content = '<p>自己找找吧 我在data目录下的子目录留了一个后门</p>';
$hidden = 'no';
?>