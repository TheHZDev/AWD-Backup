<?php


//Make sure the file isn't accessed directly.
defined('IN_PLUCK') or exit('Access denied!');
?>
<div id="copyright"><a href="https://ctf.bugku.com" target="_blank">Bugku </a> © 2012-2021. <?php echo $lang['general']['copyright']; ?></div>
</div>
</body>
</html>