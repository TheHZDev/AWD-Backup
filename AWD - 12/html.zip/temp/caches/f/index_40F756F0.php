<?php exit;?>a:3:{s:8:"template";a:23:{i:0;s:38:"/var/www/html/themes/default/index.dwt";i:1;s:52:"/var/www/html/themes/default/library/page_header.lbi";i:2;s:45:"/var/www/html/themes/default/library/cart.lbi";i:3;s:54:"/var/www/html/themes/default/library/category_tree.lbi";i:4;s:46:"/var/www/html/themes/default/library/top10.lbi";i:5;s:55:"/var/www/html/themes/default/library/promotion_info.lbi";i:6;s:52:"/var/www/html/themes/default/library/order_query.lbi";i:7;s:54:"/var/www/html/themes/default/library/invoice_query.lbi";i:8;s:50:"/var/www/html/themes/default/library/vote_list.lbi";i:9;s:51:"/var/www/html/themes/default/library/email_list.lbi";i:10;s:53:"/var/www/html/themes/default/library/cat_articles.lbi";i:11;s:52:"/var/www/html/themes/default/library/brand_goods.lbi";i:12;s:49:"/var/www/html/themes/default/library/index_ad.lbi";i:13;s:53:"/var/www/html/themes/default/library/new_articles.lbi";i:14;s:60:"/var/www/html/themes/default/library/recommend_promotion.lbi";i:15;s:47:"/var/www/html/themes/default/library/brands.lbi";i:16;s:55:"/var/www/html/themes/default/library/recommend_best.lbi";i:17;s:54:"/var/www/html/themes/default/library/recommend_new.lbi";i:18;s:54:"/var/www/html/themes/default/library/recommend_hot.lbi";i:19;s:48:"/var/www/html/themes/default/library/auction.lbi";i:20;s:50:"/var/www/html/themes/default/library/group_buy.lbi";i:21;s:45:"/var/www/html/themes/default/library/help.lbi";i:22;s:52:"/var/www/html/themes/default/library/page_footer.lbi";}s:7:"expires";i:1536136679;s:8:"maketime";i:1536133079;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Generator" content="ECSHOP v2.7.3" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="ECSHOP演示站,ecshop,ecshop下载，ecshop模板" />
<meta name="Description" content="ECSHOP购物商城演示站：ECSHOP模板屋www.ecshop119.com" />
<title>ECSHOP模板屋www.ecshop119.com-购物商城演示站 - ECShop119</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/default/style.css" rel="stylesheet" type="text/css" />
<link rel="alternate" type="application/rss+xml" title="RSS|ECSHOP模板屋www.ecshop119.com-购物商城演示站 - ECShop119" href="feed.php" />
<script type="text/javascript" src="js/common.js"></script><script type="text/javascript" src="js/index.js"></script></head>
<body>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<div class="block clearfix">
 <div class="f_l"><a href="index.php" name="top"><img src="themes/default/images/logo.gif" /></a></div>
 <div class="f_r log">
   <ul>
   <li class="userInfo">
   <script type="text/javascript" src="js/transport.js"></script><script type="text/javascript" src="js/utils.js"></script>   <font id="ECS_MEMBERZONE">554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca </font>
   </li>
      </ul>
 </div>
</div>
<div  class="blank"></div>
<div id="mainNav" class="clearfix">
  <a href="index.php" class="cur">首页<span></span></a>
  </div>
<div id="search"  class="clearfix">
  <div class="keys f_l">
   <script type="text/javascript">
    
    <!--
    function checkSearchForm()
    {
        if(document.getElementById('keyword').value)
        {
            return true;
        }
        else
        {
            alert("请输入搜索关键词！");
            return false;
        }
    }
    -->
    
    </script>
      </div>
  <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()" class="f_r"  style="_position:relative; top:5px;">
   <select name="category" id="category" class="B_input">
      <option value="0">所有分类</option>
          </select>
   <input name="keywords" type="text" id="keyword" value="" class="B_input" style="width:110px;"/>
   <input name="imageField" type="submit" value="" class="go" style="cursor:pointer;" />
   <a href="search.php?act=advanced_search">高级搜索</a>
   </form>
</div><div class="blank"></div>
<div class="block clearfix">
  
  <div class="AreaL">
    
    <div class="box">
     <div class="box_1">
      <h3><span>商店公告</span></h3>
      <div class="boxCenterList RelaArticle">
        欢迎光临手机网,我们的宗旨：诚信经营、服务客户！
<MARQUEE onmouseover=this.stop() onmouseout=this.start() 
scrollAmount=3><U><FONT color=red>
<P>咨询电话010-10124444  010-21252454 8465544</P></FONT></U></MARQUEE>      </div>
     </div>
    </div>
    <div class="blank5"></div>
    
  
<div class="cart" id="ECS_CARTINFO">
 554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca</div>
<div class="blank5"></div><div class="box">
 <div class="box_1">
  <div id="category_tree">
     
  </div>
 </div>
</div>
<div class="blank5"></div><div class="box">
 <div class="box_2">
  <div class="top10Tit"></div>
  <div class="top10List clearfix">
    </div>
 </div>
</div>
<div class="blank5"></div><script>var invalid_order_sn = "无效订单号"</script>
<div class="box">
 <div class="box_1">
  <h3><span>订单查询</span></h3>
  <div class="boxCenterList">
    <form name="ecsOrderQuery">
    <input type="text" name="order_sn" class="inputBg" /><br />
    <div class="blank5"></div>
    <input type="button" value="查询该订单号" class="bnt_blue_2" onclick="orderQuery()" />
    </form>
    <div id="ECS_ORDER_QUERY" style="margin-top:8px;">
          </div>
  </div>
 </div>
</div>
<div class="blank5"></div>554fcae493e564ee0dc75bdf2ebf94cavote|a:1:{s:4:"name";s:4:"vote";}554fcae493e564ee0dc75bdf2ebf94ca<div class="box">
 <div class="box_1">
  <h3><span>邮件订阅</span></h3>
  <div class="boxCenterList RelaArticle">
    <input type="text" id="user_email" class="inputBg" /><br />
    <div class="blank5"></div>
    <input type="button" class="bnt_blue" value="订阅" onclick="add_email_list();" />
    <input type="button" class="bnt_bonus"  value="退订" onclick="cancel_email_list();" />
  </div>
 </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
var email = document.getElementById('user_email');
function add_email_list()
{
  if (check_email())
  {
    Ajax.call('user.php?act=email_list&job=add&email=' + email.value, '', rep_add_email_list, 'GET', 'TEXT');
  }
}
function rep_add_email_list(text)
{
  alert(text);
}
function cancel_email_list()
{
  if (check_email())
  {
    Ajax.call('user.php?act=email_list&job=del&email=' + email.value, '', rep_cancel_email_list, 'GET', 'TEXT');
  }
}
function rep_cancel_email_list(text)
{
  alert(text);
}
function check_email()
{
  if (Utils.isEmail(email.value))
  {
    return true;
  }
  else
  {
    alert('邮件地址非法！');
    return false;
  }
}
</script><div class="box">
 <div class="box_1">
  <h3>
  <span><a href=""></a></span>
  <a href=""><img src="themes/default/images/more.gif" alt="more" /></a>
  </h3>
  <div class="boxCenterList RelaArticle">
    </div>
 </div>
</div>
<div class="blank5"></div><div class="box">
 <div class="box_1">
  <h3><span><a href="" class="f6"></a></span></h3>
    <div class="centerPadd">
    <div class="clearfix goodsBox" style="border:none;">
            <div class="more"><a href=""><img src="themes/default/images/more.gif" /></a></div>
    </div>
    </div>
 </div>
</div>
<div class="blank5"></div>
  </div>
  
  
  <div class="AreaR">
   
    <div class="box clearfix">
     <div class="box_1 clearfix">
       <div class="f_l" id="focus">
         <script type="text/javascript">
  var swf_width=484;
  var swf_height=200;
  </script>
  <script type="text/javascript" src="data/flashdata/pinkfocus/cycle_image.js"></script>
       </div>
       
       <div id="mallNews" class="f_r">
        <div class="NewsTit"></div>
        <div class="NewsList tc">
         
        <ul>
</ul>        </div>
       </div>
       
     </div>
    </div>
    <div class="blank5"></div>
   
   
    <div class="clearfix">
      
            
      <div class="box f_r brandsIe6">
       <div class="box_1 clearfix" id="brands">
               </div>
      </div>
    </div>
    <div class="blank5"></div>
   
  </div>
  
</div>
<div class="blank5"></div>
<div class="block">
  <div class="box">
   <div class="helpTitBg clearfix">
       </div>
  </div>
</div>
<div class="blank"></div>
<div id="bottomNav" class="box">
 <div class="box_1">
  <div class="links clearfix">
        <a href="http://www.ecshop.com/" target="_blank" title="ECSHOP 网上商店管理系统"><img src="http://www.ecshop.com/images/logo/ecshop_logo.gif" alt="ECSHOP 网上商店管理系统" border="0" /></a>
                [<a href="http://www.maifou.net/" target="_blank" title="买否网">买否网</a>]
        [<a href="http://www.wdwd.com/" target="_blank" title="免费开独立网店">免费开独立网店</a>]
          </div>
 </div>
</div>
<div class="blank"></div>
<div id="bottomNav" class="box">
 <div class="box_1">
  <div class="bNavList clearfix">
   <div class="f_l">
      </div>
   <div class="f_r">
   <a href="#top"><img src="themes/default/images/bnt_top.gif" /></a> <a href="index.php"><img src="themes/default/images/bnt_home.gif" /></a>
   </div>
  </div>
 </div>
</div>
<div class="blank"></div>
<div id="footer">
 <div class="text">
 &copy; 2005-2018 ECSHOP模板屋www.ecshop119.com-购物商城演示站 版权所有，并保留所有权利。<br />
         Tel: 15105955077               <a href="http://wpa.qq.com/msgrd?V=1&amp;Uin=2479454955&amp;Site=ECSHOP模板屋www.ecshop119.com-购物商城演示站&amp;Menu=yes" target="_blank"><img src="http://wpa.qq.com/pa?p=1:2479454955:4" height="16" border="0" alt="QQ" /> 2479454955</a>
                              <a href="http://amos1.taobao.com/msg.ww?v=2&uid=ecshop119&s=2" target="_blank"><img src="http://amos1.taobao.com/online.ww?v=2&uid=ecshop119&s=2" width="16" height="16" border="0" alt="淘宝旺旺" />ecshop119</a>
                                                              <br />
    554fcae493e564ee0dc75bdf2ebf94caquery_info|a:1:{s:4:"name";s:10:"query_info";}554fcae493e564ee0dc75bdf2ebf94ca<br />
        <div align="left"  id="rss"><a href="feed.php"><img src="themes/default/images/xml_rss2.gif" alt="rss" /></a></div>
 </div>
</div></body>
</html>