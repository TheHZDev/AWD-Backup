<?php

/**
 * ECSHOP 程序说明
 * ===========================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ==========================================================
 * $Author: liubo $
 * $Id: auto_manage.php 17217 2011-01-19 06:29:08Z liubo $
 */

global $_LANG;

$_LANG['auto_manage']            = '自动处理';
$_LANG['auto_manage_desc']       = '自动处理商品的上架下架,和文章的发布取消';
$_LANG['auto_manage_count']   = '每次处理记录个数';
$_LANG['auto_manage_count_range']['5'] = '5';
$_LANG['auto_manage_count_range']['10'] = '10';
$_LANG['auto_manage_count_range']['20'] = '20';
$_LANG['auto_manage_count_range']['50'] = '50';

?>