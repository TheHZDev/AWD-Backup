<?php

/**
 * ECSHOP 支付宝语言文件
 * ============================================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * $Author: liubo $
 * $Id: alipay.php 17217 2011-01-19 06:29:08Z liubo $
 */

global $_LANG;

$_LANG['alipay'] = '支付宝';
$_LANG['alipay_desc'] = '国内先进的网上支付平台。三种支付接口：担保交易，即时到账，双接口。在线即可开通，零预付，免年费，单笔阶梯费率，无流量限制。<br/><a href="http://cloud.ecshop.com/payment_apply.php?mod=alipay" target="_blank"><font color="red">立即在线申请</font></a>';
$_LANG['alipay_account'] = '支付宝帐户';
$_LANG['alipay_pay_method'] = '选择接口类型';
$_LANG['alipay_partner'] = '合作者身份(Pid)';
$_LANG['alipay_key'] = '安全校验码(Key)';
$_LANG['pay_button'] = '立即使用支付宝支付';
$_LANG['alipay_pay_method_desc'] = '请选择您最后一次跟支付宝签订的协议里面说明的接口类型';
$_LANG['alipay_pay_method_range'][0] = '使用标准双接口';
$_LANG['alipay_pay_method_range'][1] = '使用担保交易接口';
$_LANG['alipay_pay_method_range'][2] = '使用即时到帐交易接口';
?>