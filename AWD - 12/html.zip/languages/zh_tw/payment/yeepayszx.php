<?php

/**
 * ECSHOP YeePay易寶語言文件
 * ============================================================================
 * 版權所有 2005-2011 上海商派網絡科技有限公司，並保留所有權利。
 * 網站地址: http://www.ecshop.com；
 * ----------------------------------------------------------------------------
 * 這不是一個自由軟件！您只能在不用於商業目的的前提下對程序代碼進行修改和
 * 使用；不允許對程序代碼以任何形式任何目的的再發佈。
 * ============================================================================
 * $Author: testyang $
 * $Id: yeepay.php 14227 2008-03-10 06:37:24Z testyang $
 */

global $_LANG;

$_LANG['yeepayszx']     = 'YeePay易寶神州行支付';
$_LANG['ypszx_desc']    = 'YeePay易寶神州行支付是只要是中國移動發行的能用於給神州行手機充值的卡（請注意：該卡的序列號為17位，密碼為18位），就可以用於網上支付，因為每次支付的額度和神州行卡相等，建議點卡銷售等使用，單次支付金額不能超過神州行卡的最大面值300元。' .
        '<input type="button" name="Submit" value="立即註冊" onclick="window.open(\'https://www.yeepay.com/selfservice/AgentService.action?p0_Cmd=AgentRegister&p1_MerId=10000383855&hmac=bd9e7b0f85bddedb105eebb136632772\')" />';
$_LANG['yp_account'] = '商戶編號';
$_LANG['yp_key']     = '商戶密鑰';
$_LANG['pay_button'] = '立即使用YeePay易寶支付';
?>