<?php

/**
 * ECSHOP paypal快速结帐语言文件
 * ============================================================================
 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * $Author: liuhui $
 * $Id: paypal_ec.php 16488 2009-08-02 10:12:56Z liuhui $
 */

global $_LANG;

$_LANG['paypal_ec']                       = 'paypal EC';
$_LANG['paypal_ec_desc']                  = 'PayPal(www.paypal.com) is a leading e-payment service provider in the world, its accounts has more than 71600 thousands.Udpay can be used in 56 markets by 7 types currency (Canadian dollar,EURO,Pound,U.S. dollar,Japanese yen,Austalian dollar, HongKong dollar).<br/><a href="http://cloud.ecshop.com/payment_apply.php?mod=paypal" target="_blank">Immediately online application</a>';
$_LANG['paypal_ec_username']               = 'username:';
$_LANG['paypal_ec_password']               = 'paaaword:';
$_LANG['paypal_ec_signature']               = 'signature:';
$_LANG['paypal_currency']              = 'Currency payment';
$_LANG['paypal_currency_range']['AUD'] = 'Austalian dollar';
$_LANG['paypal_currency_range']['CAD'] = 'Canadian dollar';
$_LANG['paypal_currency_range']['EUR'] = 'Euro';
$_LANG['paypal_currency_range']['GBP'] = 'Pound';
$_LANG['paypal_currency_range']['JPY'] = 'Japanese yen';
$_LANG['paypal_currency_range']['USD'] = 'U.S. dollar';
$_LANG['paypal_currency_range']['HKD'] = 'Hong Kong dollar';
$_LANG['paypal_button']                = 'Pay in Paypal EC immediately.';
?>