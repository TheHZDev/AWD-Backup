<?php

/**
 * ECSHOP Control panel administrator operate content language file
 * ============================================================================
 * All right reserved (C) 2005-2011 Beijing Yi Shang Interactive Technology
 * Development Ltd.
 * Web site: http://www.ecshop.com
 * ----------------------------------------------------------------------------
 * This is a free/open source software；it mean that you can modify, use and
 * republish the program code, on the premise of that your behavior is not for
 * commercial purposes.
 * ============================================================================
 * $Author: liubo $
 * $Id: magazine_list.php 17217 2011-01-19 06:29:08Z liubo $
*/

$_LANG['add_new'] = 'Add a new magazine';
$_LANG['magazine_name'] = 'Magazine name';
$_LANG['magazine_edit'] = 'edit';
$_LANG['magazine_del'] = 'delete';
$_LANG['ck_del'] = 'Determine the delete?';
$_LANG['finish_list'] = 'already inserted %s records, please wait for a moment';
$_LANG['finishing'] = 'Are generated later';
$_LANG['magazine_addtolist'] = 'Insert Send Queue';
$_LANG['magazine_ckaddtolist'] = 'Insert magazine confirmed this mass-mailing list? This action will give the existing mailing list to send this E-zine';
$_LANG['pri'][0] = 'Ordinary';
$_LANG['pri'][1] = 'High';
$_LANG['magazine_last_update'] = 'Last edited magazine';
$_LANG['magazine_last_send'] = 'Magazine of the last send time';
$_LANG['magazine_content'] = 'Magazine content (support for html)';
$_LANG['go_list'] = 'Return list';
$_LANG['edit_ok'] = 'Operation successful!';
$_LANG['email_user'] = 'E-mail subscribers';
$_LANG['user_list'] = 'All Member';

?>