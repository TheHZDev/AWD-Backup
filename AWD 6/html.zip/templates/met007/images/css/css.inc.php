<?php
//首页样式定义
$indexpage[0]=array('首页一','index','最新版本','view.jpg');//array('风格名称,'调用首页文件名','首页简介','预览图片名称')
$indexpage[1]=array('首页二','index1','根据客户使用情况进行过调整','view.jpg');
$indexpage[2]=array('首页三','index2','原始版本的首页','view.jpg');

//模板风格定义
$cssnum[0]=array('蓝色','metinfo.css');//array('风格名称,'调用css名称')
$cssnum[1]=array('红色','red.css');//array('风格名称,'调用css名称')
$cssnum[2]=array('绿色','green.css');//array('风格名称,'调用css名称')
$cssnum[3]=array('青色','cyan-blue.css');//array('风格名称,'调用css名称')
$cssnum[4]=array('黑色','black.css');//array('风格名称,'调用css名称')
$cssnum[5]=array('紫色','purple.css');//array('风格名称,'调用css名称')
?>