<?php
//模板风格定义
$cssnum[0]=array('蓝色','metinfo.css');//array('风格名称,'调用css名称')
$cssnum[1]=array('红色','metinfo_red.css');//array('风格名称,'调用css名称')
$cssnum[2]=array('绿色','metinfo_green.css');//array('风格名称,'调用css名称')
?>