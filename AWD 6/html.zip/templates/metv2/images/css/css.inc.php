<?php
$cssnum[0]=array('蓝色','metinfo.css');//array('风格名称,'调用css名称')
$cssnum[1]=array('红色','redmetinfo.css');//array('风格名称,'调用css名称')
$cssnum[2]=array('绿色','greenmetinfo.css');////array('风格名称,'调用css名称')
?>