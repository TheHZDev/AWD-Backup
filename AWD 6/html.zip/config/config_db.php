<?php
                   /*
                   con_db_host = "localhost"
                   con_db_id   = "cms"
                   con_db_pass	= "0fe1d95a9a7b66e3"
                   con_db_name = "cms"
                   tablepre    =  "met_"
                   db_charset  =  "utf8";
                  */
                  ?>