<?php
 return array (
  0 => 
  array (
    'id' => '1',
    'name' => '咨询销售',
    'no_order' => '1',
    'qq' => '348468810',
    'msn' => '',
    'taobao' => 'metinfo',
    'alibaba' => '',
    'skype' => '',
    'lang' => 'cn',
  ),
  1 => 
  array (
    'id' => '2',
    'name' => '咨询销售',
    'no_order' => '2',
    'qq' => '1498488199',
    'msn' => 'metinfo@metinfo.cn',
    'taobao' => '',
    'alibaba' => '',
    'skype' => '',
    'lang' => 'cn',
  ),
  2 => 
  array (
    'id' => '3',
    'name' => '空间域名',
    'no_order' => '3',
    'qq' => '2545740365',
    'msn' => '',
    'taobao' => 'metinfo',
    'alibaba' => '',
    'skype' => '',
    'lang' => 'cn',
  ),
  3 => 
  array (
    'id' => '4',
    'name' => '合作加盟',
    'no_order' => '4',
    'qq' => '909059761',
    'msn' => 'metinfo@metinfo.cn',
    'taobao' => '',
    'alibaba' => '',
    'skype' => '',
    'lang' => 'cn',
  ),
); ?>