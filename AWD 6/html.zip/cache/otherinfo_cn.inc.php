<?php
 return array (
  'id' => '3',
  'info1' => '',
  'info2' => '',
  'info3' => '',
  'info4' => '',
  'info5' => '',
  'info6' => '',
  'info7' => '',
  'info8' => '',
  'info9' => '',
  'info10' => '<div>
	请在<strong>后台-内容管理-其他内容</strong>中修改此段文字</div>
<div>
	某某有限公司</div>
<div>
	电 &nbsp;话：0000-888888</div>
<div>
	邮 &nbsp;编：000000</div>
<div>
	Email：admin@admin.cn</div>
<div>
	网 &nbsp;址：www.xxxxx.cn</div>
',
  'imgurl1' => '',
  'imgurl2' => '',
  'rightmd5' => '',
  'righttext' => '',
  'authcode' => '',
  'authpass' => '',
  'authtext' => '',
  'data' => '',
  'lang' => 'cn',
); ?>