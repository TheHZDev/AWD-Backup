<?php

define('_VERSION','5_5_0_20130605_UTF8');
define('_VERNUM','5.5.0.20130605');