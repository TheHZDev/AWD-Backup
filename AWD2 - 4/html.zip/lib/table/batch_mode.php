<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class batch_mode {
}