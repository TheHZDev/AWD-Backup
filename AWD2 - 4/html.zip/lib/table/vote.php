<?php

class vote {
    function url($id) {
        return ballot::url($id);
    }
}