<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class table_ologin  extends table_mode {

}