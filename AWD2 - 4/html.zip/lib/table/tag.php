<?php

class tag extends table {
    public  $name='b_tag';
    
    function getcols($act) {
    	switch ($act) {
    		case 'list':
    			return 'tagid,tagname';
    		case 'modify':
    			return 'tagid,tagname';
    		case 'manage':
    			return 'tagid,tagname';
    		default: return '1';
    	}
    }
    
    function url($tag,$page=1) {
    	if(front::$get['t'] == 'wap'){
    		if(config::get('tag_html')){
    			$otag = new tag();
    			$row = $otag->getrow("tagname='$tag'");
    			$tagid= $row['tagid'];
    			$pinyin = pinyin::get($tag);
    			return config::get('base_url').'/tags_wap/'.$pinyin.'_'.$tagid.'_'.$page.'.html';
    		}else{
    			return url::create('tag/show/t/wap/tag/'.urlencode($tag).($page>1?'/page/'.$page:''),false);
    		}
    	}
    	if(config::get('tag_html')){
    		$otag = new tag();
    		$row = $otag->getrow("tagname='$tag'");
    		$tagid= $row['tagid'];
    		$pinyin = pinyin::get($tag);
    		return config::get('base_url').'/tags/'.$pinyin.'_'.$tagid.'_'.$page.'.html';
    	}
    	return url::create('tag/show/tag/'.urlencode($tag).($page>1?'/page/'.$page:''),false);
    }
    
    static function getTags() {
    	$sets=settings::getInstance()->getrow(array('tag'=>'table-hottag'));
    	if (!is_array($sets)) return;
    	$data=unserialize($sets['value']);
    	preg_match_all('%\(([\d\w\/\.-]+)\)(\S+)%m',$data['hottag'],$result,PREG_SET_ORDER);
    	$data=array();
    	$data[0] = '请选择';
    	foreach ($result as $res)
    		$data[$res[1]]=$res[2];
    	//var_dump($data);
    	return $data;
    }
    
    function urls($tagstring) {
        $tags=explode(',',$tagstring);
        $urls=array();
        foreach($tags as $tag) {
            if($tag)
                $urls[$tag]=$this->url($tag);
        }
        return $urls;
    }
    function pagination() {
        return template('system/tag_pagination.html');
    }
}