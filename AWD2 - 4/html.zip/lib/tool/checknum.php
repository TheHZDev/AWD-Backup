<?php

$n = rand();
echo $n;