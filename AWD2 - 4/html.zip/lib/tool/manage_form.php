<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class manage_form {
    static function table(table_admin $act) {
    }
    static function manage(manage_act $act) {
    }
}