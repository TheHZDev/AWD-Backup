<?php return array (
  0 => 
  array (
    'hrname' => '分类短URL:{$caturl}_{$page}.html',
    'htmlrule' => '{$caturl}_{$page}.html',
    'cate' => 'type',
  ),
  1 => 
  array (
    'hrname' => '所有分类目录_分页:{$caturl}/{$page}.html',
    'htmlrule' => '{$caturl}/{$page}.html',
    'cate' => 'type',
  ),
  2 => 
  array (
    'hrname' => '分类目录_分页:{$dir}/{$page}.html',
    'htmlrule' => '{$dir}/{$page}.html',
    'cate' => 'type',
  ),
  3 => 
  array (
    'hrname' => '分类ID_分页:{$catid}_{$page}.html',
    'htmlrule' => '{$catid}_{$page}.html',
    'cate' => 'type',
  ),
);