<?php if (!defined('ROOT')) exit('Can\'t Access !');


 return array (

'enabled'=>'1',

'keeptime'=>'86400',

'profitmargin'=>'2',

'forward'=>'',

'rewardnumber'=>'1',

'rewardtype'=>'point', 

'regrewardnumber'=>'5',

'regrewardtype'=>'point', 

);

?>

