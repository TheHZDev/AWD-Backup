<?php  return array (
  0 => 
  array (
    'aid' => '9',
    'catid' => '2',
    'typeid' => '0',
    'title' => '<font style="color:;">优秀网站的五大要素</font>',
    'tag' => '',
    'username' => 'cmseasy',
    'userid' => '127',
    'view' => '0',
    'color' => '',
    'strong' => '0',
    'toppost' => '0',
    'font' => '',
    'spid' => '0',
    'ip' => '',
    'mtitle' => '',
    'keyword' => '',
    'description' => '',
    'listorder' => '0',
    'adddate' => '2011-11-27',
    'author' => 'cmseasy',
    'image' => '/',
    'thumb' => '/upload/images/201111/13223335247372.jpg',
    'state' => '1',
    'checked' => '1',
    'introduce' => '  1、网站内容非富           网站作为一种媒体，提供给用户的最主要还是网站的内容，没有人会在一个没内容的网站上留连往返，就象没人会两次看同一份毫无新意的报纸一样！ 2、页面下载速度快 　　 据研究发现，页面下载速度是网站留住访问者的关键因素，如果20—30秒还不能打开一个网页，一般人就会没有耐心。如果不能让每个页面都保持较快的下载速度，至少应该确保主页速度尽可能快。 　　 在目前的情况下，保持页面下载速度的主要方法是让网页简单，仅将最重要的信息安排在首页，尽量避免使用大量的图片。 　　 虽然大量使用文字降低了网页的视觉效果，显得有些呆板，不过根据加拿大最近一项“网民网上看什么”的调查显示，互联网用户92%的上网时间用来看文字资讯。 3、功能多样',
    'introduce_len' => '200',
    'content' => '<p>&nbsp;</p>
<p>1、网站内容非富</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 网站作为一种媒体，提供给用户的最主要还是网站的内容，没有人会在一个没内容的网站上留连往返，就象没人会两次看同一份毫无新意的报纸一样！</p>
<p>2、页面下载速度快</p>
<p>　　 据研究发现，页面下载速度是网站留住访问者的关键因素，如果20&mdash;30秒还不能打开一个网页，一般人就会没有耐心。如果不能让每个页面都保持较快的下载速度，至少应该确保主页速度尽可能快。</p>
<p>　　 在目前的情况下，保持页面下载速度的主要方法是让网页简单，仅将最重要的信息安排在首页，尽量避免使用大量的图片。</p>
<p>　　 虽然大量使用文字降低了网页的视觉效果，显得有些呆板，不过根据加拿大最近一项&ldquo;网民网上看什么&rdquo;的调查显示，互联网用户92%的上网时间用来看文字资讯。</p>
<p>3、功能多样、使用方便</p>
<p>　　 网站吸引用户访问的基本目的无非是出于几个方面：扩大网站知名度和吸引力；将潜在顾客转化为实际顾客；将现有顾客发展为忠诚顾客等。为用户提供一个多功能的人性化界面，并保持这种功能的使用方便，就显得十分重要，说到底用户使用一种服务----不管在网上网下------最主要的是方便。包括方便的导航系统、必要的帮助信息、常见问题解答、尽量简单的用户注册程序等等。</p>
<p>4、网站品质优秀</p>
<p>　　 网页上的错误链接常常是人们对网站抱怨的主要因素之一。我们时常可以看到&ldquo;该网页已被删除或不能显示&rdquo;、&ldquo;Filenotfound&rdquo;等由于无效链接而产生的反馈信息，这种情况往往让人觉得难以忍受，同时也严重影响了用户对网站的信心。如果网站同时可以提供800免费服务电话和callcenter等联系方式，相信不仅可以体现公司的实力，而且更能充分体现出良好的顾客服务。</p>
<p>5、保护个人信息</p>
<p>　　 在个性化服务十分普及的今天，许多网站要求用户首先注册为会员，网站收集用户资料有何目的？如何利用用户的个人信息？是否将用户资料出售给其它机构？是否会利用个人信息向用户发送大量的广告邮件？用户是否对此拥有选择的权利？填写的个人信息是否安全？是否能获得必要的回报？这些都是用户十分关心的问题，如果网站对此没有明确的说明和承诺，这样的网站显然缺乏必要的商业道德，或者至少可以被认为对用户不够尊重。<br />
&nbsp;</p>',
    'template' => '0',
    'showform' => '0',
    'htmlrule' => '',
    'ishtml' => '0',
    'iswaphtml' => '0',
    'linkto' => '',
    'attr1' => '',
    'attr2' => '',
    'attr3' => '',
    'comment_num' => '0',
    'attachment_id' => '',
    'attachment_path' => '',
    'grade' => '0',
    'pics' => 'a:1:{i:0;s:0:"";}',
    'type' => '',
    'province_id' => '0',
    'city_id' => '0',
    'section_id' => '0',
    'outtime' => '0000-00-00',
    'my_size' => '',
    'my_zhaopinbumen' => '',
    'my_jobtype' => '',
    'my_jobtitle' => '',
    'my_jobnumber' => '',
    'my_jobgender' => '',
    'my_jobwork' => '',
    'my_jobacademic' => '',
    'my_jobage' => '',
    'my_jobworkareas' => '',
    'my_jobrequirements' => '',
    'my_contactname' => '',
    'url' => '/index.php?case=archive&act=show&aid=9',
    'catname' => '企业新闻',
    'caturl' => '/index.php?case=archive&act=list&catid=2',
    'stitle' => '优秀网站的五大要素',
    'strgrade' => '<img src="/images/star2.gif" border="0" /><img src="/images/star2.gif" border="0" /><img src="/images/star2.gif" border="0" /><img src="/images/star2.gif" border="0" /><img src="/images/star2.gif" border="0" />',
    'buyurl' => '/index.php?case=archive&act=orders&aid=9',
    'oldprice' => '',
    'intro' => '  1、网站内容非富           网站作为一种媒体，提供给用户的最主要还是网站的内容，没有人会在一个没内容的网站上留连往返，就象没人会两次看同一份毫无新意的报纸一样！ 2、页面下载速度快 　　',
    'sthumb' => '//upload/images/201111/13223335247372.jpg',
  ),
);