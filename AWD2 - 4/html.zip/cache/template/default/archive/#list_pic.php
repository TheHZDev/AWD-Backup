<?php defined('ROOT') or exit('Can\'t Access !'); ?>
<?php echo template('header.html'); ?>
<!-- 面包屑导航开始 -->
<div class="clear box">
<?php echo template('position.html'); ?>
</div><div class="blank5"></div>
<!-- 面包屑导航结束 -->

<!-- 中部开始 -->
<div class="clear box c_bg">
<div class="c_top"></div>

<!-- 左侧开始 -->
<div class="w_250">

<?php echo template('left.html'); ?>

<!-- 订单查询 -->
<div class="title mt20 mb20">
<h3><a><?php echo lang(vieworders);?></a>/<span>Order</span></h3>
</div>


<div class="l_box_top"></div>
<div class="l_box">
<div class="order">
<input size="20" id="oid" class="o_text" name="oid" type="text" align="absmiple"value=" <?php echo lang(orderid);?>… " onfocus="if(this.value==' <?php echo lang(orderid);?>… ') {this.value=''}" onblur="if(this.value=='') this.value=' <?php echo lang(orderid);?>… '" /> 
<input type="submit" id="search_btn" align="absmiple" name='submit' value=" <?php echo lang(look);?> " onclick="javascript:window.location.href='<?php echo url('archive/orders');?>&oid='+document.getElementById('oid').value;" class="o_btn" />
</div>
</div>
<div class="l_box_bottom"></div>

<div class="clear"></div>
</div>
<!-- 左侧结束 -->


<!-- 右侧开始 -->
<div class="w_700">

<div id="content" class="clear" style="width:650px;overflow:hidden;">

<!-- 栏目标题开始 -->
<div class="title mt20 mb20">
<h3><a><?php echo $category[$catid]['catname'];?></a>/<span><?php echo $category[$catid]['htmldir'];?></span></h3>
</div>
<div class="line_2"></div><div class="blank20"></div>
<!-- 栏目标题结束 -->

<!-- 内容缩略图列表 -->
<ul id="list-view">
<li>
<?php foreach($archives as $i => $archive) { ?>

<?php if($i%4==0  &&   $i> 1) { ?>
<div class="blank10 clear"></div>
</li>
<li>
<?php } else { ?><?php } ?>

<div class="list-view">
<div class="img-wrap"><a title="<?php echo $archive['stitle'];?>" target="_blank" href="<?php echo $archive['url'];?>"><img alt="<?php echo $archive['stitle'];?>" src="<?php echo $archive['thumb'];?>" onerror='this.src="<?php echo config::get('onerror_pic');?>"' /></a></div>
<h5><a title="<?php echo $archive['stitle'];?>" target="_blank" href="<?php echo $archive['url'];?>"><?php echo $archive['title'];?></a></h5><?php if($archive['attr2']) { ?><?php if($archive['attr2']==$archive['oldprice']) { ?><?php echo lang(price);?>：<span><?php echo $archive['attr2'];?></span><?php echo lang(unit);?><?php } else { ?><?php echo lang(list_price);?>：<span><?php echo $archive['oldprice'];?></span><?php echo lang(unit);?> <?php echo lang(discount);?>：<span><?php echo $archive['attr2'];?></span><?php echo lang(unit);?><?php } ?><?php } ?>
</div>

<?php } ?>
<div class="clear"></div>
</li>
</ul>
<!-- 内容缩略图列表结束 -->

<div class="clear"></div>
<div class="blank30"></div>

<!-- 内容列表分页开始 -->
<?php if(isset($pages)) { ?>
<?php echo category_pagination($catid);?>
<?php } ?>
<!-- 内容列表分页结束 -->

<div class="blank30"></div>
<a title="<?php echo lang(gotop);?>" href="#" class="clear floatright"><img alt="<?php echo lang(gotop);?>" src="<?php echo $skin_url;?>/images/gotop.gif"></a>
<div class="blank30"></div>
<div class="clear"></div>
</div>
</div>
<!-- 右侧结束 -->

<div class="c_bottom"></div>
<div class="clear"></div>
</div>
<!-- 中部结束 -->
<?php echo template('footer.html'); ?>