</div>
<div class="blank30"></div>
<center>Copyright &copy; 2011<a title="<?php echo $GLOBALS['config']['sitename']?>" href="{$base_url}/"><?php echo $GLOBALS['config']['sitename']?></a><div class="copy"><a href="http://www.cmseasy.cn" title="Powered by CmsEasy" target="_blank">Powered by CmsEasy</a></div></center>
<div class="blank30"></div>

<script type="text/javascript" src="../js/common.js"></script>
</body>
</html>