<?php
class action_stdClass{

}