<?php


return array(
'vote'=>'投票',
);