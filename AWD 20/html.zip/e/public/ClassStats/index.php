<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>EmpireCMS</title>
</head>
<body>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><font size="4">此项功能免费版没有开放，需要购买<strong>商业授权版</strong>可联系<a href="http://www.phome.net" target="_blank"><strong>帝国CMS官方</strong></a>。谢谢支持！</font></p>
</div>
</body>
</html>
