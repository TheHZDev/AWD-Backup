<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?>

                 </td>
              </tr>
            </table> </td>
    </tr>
   </table></td>
 </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><hr></td>
  </tr>
</table>
<table width="778" border="0" align="center" cellpadding="0" cellspacing="2">
  <tr> 
    <td height="21"><div align="center"><a href="#">关于我们</a> | <a href="#">服务条款</a> 
        | <a href="#">广告服务</a> | <a href="#">联系我们</a> | <a href="#">网站地图</a> | 
        <a href="#">免责声明</a></div></td>
  </tr>
  <tr> 
    <td height="21"><div align="center">Powered by <a href="http://www.phome.net" target="_blank"><strong>EmpireCMS</strong></a> 
        <font color="#FF9900"><strong>7.5</strong></font> &copy; 2002-2018 EmpireSoft 
        Inc.</div></td>
  </tr>
  <tr> 
    <td>
<div align="center"></div></td>
  </tr>
</table>
</body>
</html>