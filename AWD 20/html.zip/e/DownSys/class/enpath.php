<?php
//##############防盗链插件
//给下载地址加密
function DoEnDownpath($url)
{
	return $url;
}

//给在线观看地址加密
function DoEnOnlinepath($url)
{
	return $url;
}
?>