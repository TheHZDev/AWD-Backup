<?php
Header("Location:../");
?>