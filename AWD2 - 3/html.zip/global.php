<?php
include './config.php';
include './function.php';
include './waf.php';
session_start();
?>