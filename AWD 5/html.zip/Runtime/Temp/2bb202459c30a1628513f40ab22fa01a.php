<?php
//000000000000a:1:{s:2:"u1";s:13:"Administrator";}
?>