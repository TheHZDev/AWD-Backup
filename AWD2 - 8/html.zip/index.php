<?php
session_start();
set_time_limit(0);

define('IN_DSW', true);
defined('ROOT_PATH') or define('ROOT_PATH', str_replace('\\', '/', dirname(__FILE__)).'/');
define('DATA_PATH', ROOT_PATH.'data/');
require ROOT_PATH."lib/chaojicms.class.php";
$chaojicms = new chaojicms;
$chaojicms->run();
?>