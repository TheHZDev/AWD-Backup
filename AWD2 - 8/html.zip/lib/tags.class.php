<?php
/*
 * tags标签类
 * 2018-02-26*/
class tags{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->category=$this->G->loadclass('category');
		$this->pages=$this->G->loadclass('pages');
		$this->article=$this->G->loadclass('article');
	}

	//获取所有tags
	public function getAll($condition=array()){
		return $this->dbpdo->query("tags",'*',$condition);
	}

	//获取所有tags
	public function getTagList($Snumber=PAGED,$condition=array(),$orderby='tag_label'){
		return $this->dbpdo->query("tags",'*',$condition,'',$orderby,"","0",$Snumber);
	}

	//获取所有tags带分页
	public function getList($Spage,$Snumber=PAGED,$condition=array(),$UrlStyle=""){
		$rs=array();
		//下句有报错 开始页码为1时（记录为0开始）只能转为字符，否则显示全部内容
		$rs['data']=$this->dbpdo->query("tags",'*',$condition,"","","",strval(intval($Spage-1)*$Snumber),$Snumber);
		$t=$this->dbpdo->getOne("tags",'count(*) AS total',$condition);
		$Intpages = $this->pages->set_page_info($t['total'],$Snumber,$UrlStyle);
		if($rs){
			$rs['pages']=$Intpages;
			$rs['total'] = $t['total'];
		}
		return $rs;
	}

	//根据标签ID获取标签信息
	public function getTagByID($tag_id){
		return $this->dbpdo->getOne("tags",'*',array('tag_id'=>$tag_id));
	}
	
	//根据标签名称获取标签信息
	public function getTagByLabel($tag_label){
		return $this->dbpdo->getOne("tags",'*',array('tag_label'=>$tag_label));
	}

	//添加标签
	public function addTag($args){
		$this->dbpdo->insert_data("tags",$args);
		return $this->dbpdo->getInsertId();
	}

	//修改标签信息
	public function editTag($tag_id,$args){
		$condition=array("tag_id"=>$tag_id);
		return $this->dbpdo->update_data("tags",$args,$condition);
	}

	public function CheckTag($tag_id='',$tag_label=''){
		$s=$this->dbpdo->getOne("tags",'*',array('tag_label'=>$tag_label));
		if($s){
			if($s['tag_id']!=$tag_id){
				return true;
			}
		}
	}

	public function updateTag($args,$condition=''){
		if(!empty($condition)){
			return $this->dbpdo->update_data("tags",$args,$condition);
		}else{
			return false;
		}
	}

	//菜单删除
	public function del($IntID){
		return $this->dbpdo->remove("tags",array("tag_id"=>$IntID));
	}

	//添加文章的tags,先检查再添加
	public function addArticleTags($tags=array(),$contentid){
		$arr=(explode(",",$tags));
		foreach ($arr as $value){
			$s=$this->getTagByLabel($value);
			//var_dump($s);
			if($s=='' and $value<>''){
				$args['tag_label']=$value;
				$args['tag_article']=$contentid;
				$this->addTag($args);
			}else{
				//先把已经存在标签表中课件ID取出，再与当前ID进行对比，如果不存在再存入数据库
				$doit=0;
				$tag_id=$s['tag_id'];
				$contentids=$this->getTagByID($tag_id);
				$a=(explode(",",$contentids['tag_article']));
				foreach ($a as $v){
					if($contentid<>$v){
						$doit=1;
					}else{
						$doit=0;
						break;
					}
				}
				if($doit==1 and $value<>''){
					if($s['tag_article']==''){//防止第一次加入，前面会有多余逗号。
						$s['tag_article']=$contentid;
					}else{
						$s['tag_article']=$s['tag_article'].','.$contentid;
					}
					$this->editTag($tag_id,$s);
				}
			}
		}
		return true;
	}

	//根据文章ID获取相关文章
	public function getTagByAid($IntID){
		if($IntID){
			$artTag=$this->article->getOne(array('id'=>$IntID));
			if($artTag['seo_tags']){
				$taglist=$this->dbpdo->query("tags",'*',"FIND_IN_SET(tag_label,'".$artTag['seo_tags']."')");
				return $taglist;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	//根据文章ID获取相关文章
	public function getRelationArtByAid($IntID){
		$taglist=$this->dbpdo->query("tags",'*',"FIND_IN_SET('".$IntID."',tag_article)");
		$i=0;
		foreach($taglist as $k=>$v){
			if($v['tag_article']!=$IntID){
				if($Sid==""){
					$Sid=$v['tag_article'];
				}else{
					$Sid=$Sid.','.$v['tag_article'];
				}
				$i++;
			}
		}
		$rs=explode(',',$Sid);
		$rs=array_unique($rs);
		$ids="";
		foreach($rs as $k=>$v){
			if($v!=$IntID){
				if($ids==""){
					$ids=$v;
				}else{
					$ids=$ids.','.$v;
				}
			}
		}
		//var_dump($ids);
		$ListArt=$this->dbpdo->query("article",'*',"FIND_IN_SET(id,'".$ids."')");
		if(!$ListArt){
			return false;
		}
		foreach($ListArt as $key=>$value){
			$CatOne=$this->category->getOneByID($value["cat_id"]);
			$ListArt[$key]['catalog_name']=$CatOne['catalog_name'];
			$Surl='/'.$CatOne['catalog_name'].'/'.$value['id'].'.html';
			$ListArt[$key]['url']=$Surl;
		}
		return $ListArt;
	}

	public function updateArtTags($tagid,$artids){
		$arrids=explode(',',$artids);
		$arrids=array_unique($arrids);
		$stag=$this->getTagByID($tagid);
		$sids=$stag['tag_article'];
		foreach($arrids as $k=>$v){
			$taglist=$this->dbpdo->query("tags",'*',"FIND_IN_SET('".$v."',tag_article)");
			if(!$taglist){
				if(empty($sids)){
					$sids=$v;
				}else{
					$sids=$sids.','.$v;
				}
			}
		}
		return $this->editTag($tagid,array('tag_article'=>$sids));
	}
}
?>
