<?php
/*
 * 2018-03-29
 * 数据表操作
 * */
class databackup{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->dbsqli=$this->G->loadclass('dbsqli');
		$this->files=$this->G->loadclass('files');
	}

	//获取数据表
	public function getDatabase(){
		return $this->dbsqli->exec("show table status");
	}

	//优化选中数据表
	public function optimize($tables){
		
		foreach($tables as $value){
			$this->dbsqli->exec("OPTIMIZE TABLE `{$value}`");
		}
		return '优化成功';
	}

	//修复选中数据表
	public function repair($tables){

		foreach($tables as $value){
			$this->dbsqli->exec("REPAIR TABLE `{$value}`");
		}
		return '修复成功';
	}

	//分析选中数据表
	public function analyze($tables){

		foreach($tables as $value){
			$this->dbsqli->exec("ANALYZE TABLE `{$value}`");
		}
		return '分析成功';
	}

	//备份数据库
	public function backup($tables){
		set_time_limit(0);
		$name=md5(rand(1000,10000)).date('Ymd-His').'.sql';
		$sql  = "\n\n-- ----------------------------------\n";
		$sql .= "-- 作者:牛哥 2018-03-29 \n";
        $sql .= "-- 生成时间:".date("Y-m-d H:i:s") . "\n";
        $sql .= "-- ----------------------------------\n\n";
        //$sql .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

		foreach($tables as $value){
			$rsTable=$this->dbsqli->exec("SHOW CREATE TABLE `{$value}`");
			$sql .= "\n\n";
            $sql .= "-- \n";
            $sql .= "-- 表结构 `{$value}`\n";
            $sql .= "-- \n";
            $sql .= "DROP TABLE IF EXISTS `{$value}`;\n";
            $sql .= trim($rsTable[0]['Create Table']) . ";\n\n";
		
			$rsData=$this->dbsqli->exec("SELECT * FROM `{$value}`");
			if($rsData){
				$sql .= "-- \n";
				$sql .= "-- 表记录 `{$value}`\n";
				$sql .= "-- \n";
				foreach($rsData as $row){
					$row=self::deal_backup($row);
					$val=implode("','",$row);
					$sql.= "INSERT INTO `{$value}` VALUES ('".$val."');\n";
				}
			}
			$sql .= "\n\n-- 表结束 `{$value}`\n";
			$sql .= "-------------------------------------------------- \n";		
		}
        if(!file_exists(DATA_BACKUP)){          
            $this->files->mdir(DATA_BACKUP);
        }
		file_put_contents(DATA_BACKUP.$name,$sql);
		return '备份成功';
	}

	//字符转换
	public function deal_backup($data){
		foreach ($data as $key=>$val){
			#换行
        	$val=str_replace(PHP_EOL,'\r\n',$val);
        	$val=str_replace(chr(10),'\n',$val);
        	#双引号
        	$val=str_replace('"','\"',$val);
        	#增加单引号转换
        	$val=str_replace("'","\'",$val);
			$data[$key]=$val;
		}
		return $data;
	}

	public function import($sfile){
		set_time_limit(0);
		$f=fopen($sfile,"rb");
		
		//创建表缓冲变量
		$create_table='';
		while(!feof($f)){
			$line=fgets($f);
			$create_table .= $line;
			if (preg_match('/表结构([\s\S]*?)表记录/',$create_table)){
				preg_match('/DROP([\s\S]*?);/',$create_table,$r,PREG_OFFSET_CAPTURE);
				//删除数据表
				$this->dbpdo->exec($r[0][0]);
				preg_match('/CREATE([\s\S]*?);/',$create_table,$s,PREG_OFFSET_CAPTURE);
				//创建数据表
				$this->dbpdo->exec($s[0][0]);
				$create_table="";
				continue;		
			}
			if (preg_match('/INSERT([\s\S]*?);/',$line)){
				//插入数据记录
				$this->dbpdo->exec($line);
			}
		}
		fclose($f);
		return '还原成功';
			
	}
	//获取备份文件列表
	public function getBackupList(){
		if(file_exists(DATA_BACKUP)){
            return $this->files->listDir(DATA_BACKUP);
        }else{
            $this->files->mdir(DATA_BACKUP);
            return $this->files->listDir(DATA_BACKUP);
        }
	}
}
?>
