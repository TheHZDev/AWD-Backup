<?php

/*
 * 2017-12-23
 * 插件管理类（admin 默认后台 home 默认前台 默认为安装不可卸载）
 * */
class apps{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->files = $this->G->loadclass('files');
		$this->tinwin = $this->G->loadclass('tinwin');
	}

	public function save($dsw){
		return $this->dbpdo->insert_data("apps",$dsw);
	}

	public function update($dsw,$condition=""){
		return $this->dbpdo->update_data("apps",$dsw,$condition);
	}

	//获取数据库已经存在的APP记录,即已安装的APP
	public function getAllByData(){
		$list=$this->dbpdo->query("apps",'*');
		foreach($list as $key=>$v){
			$list[$key]['mypath']='./application/'.$v['appname'].'/';
		}
		return $list;
	}

	//获取未安装的APP
	public function getUnInstall(){
		$sfile=$this->getLocalAppList();
		foreach($sfile as $k=>$v){
			if(file_exists($v['mypath']."install.lock")){
				unset($sfile[$k]);
			}
		}
		return $sfile;
	}

	public function getOneByName($appname){
		return $this->dbpdo->getOne("apps",'*',array('appname'=>$appname));
	}

	//获取本地应用列表
	public function getLocalAppList(){
		$ListAll=$this->files->listDir('application');
		foreach($ListAll['dir'] as $key=>$value){
			$mypath='./'.$value['path'].'/';
			if(file_exists($mypath.'application.php')){
				$appconfig=$this->tinwin->readArrFile($mypath.'application.php');
				$Sresult[$key]['mypath']=$mypath;
				$Sresult[$key]['appname']=$appconfig['appname'];
				$Sresult[$key]['applabel']=$appconfig['applabel'];
				$Sresult[$key]['appversion']=$appconfig['appversion'];
				$Sresult[$key]['description']=$appconfig['description'];
				$Sresult[$key]['appimg']=$appconfig['appimg'];
				$Sresult[$key]['author']=$appconfig['author'];
				$Sresult[$key]['install']=$appconfig['install'];
				$Sresult[$key]['uninstall']=$appconfig['uninstall'];
				$Sresult[$key]['upgrade']=$appconfig['upgrade'];
				if(file_exists($mypath."install.lock")){
					// $Sresult[$key]['title']="卸载";
					$Sresult[$key]['url']="apps-appuninstall&appname=".$appconfig['appname'];
					$Sresult[$key]['installed']=1;
				}else{
					$Sresult[$key]['installed']=0;
					// $Sresult[$key]['title']="安装";
					$Sresult[$key]['url']="apps-appinstall&appname=".$appconfig['appname'];
				}
			}
		}
		return $Sresult;
	}

	//获取单个本地APP信息
	public function getLocalAppByName($appname){
		$mypath='./application/'.$appname."/";
		if(file_exists($mypath.'application.php')){
			$appconfig=$this->tinwin->readArrFile($mypath.'application.php');
			$Sresult['mypath']=$mypath;
			$Sresult['appname']=$appconfig['appname'];
			$Sresult['applabel']=$appconfig['applabel'];
			$Sresult['appversion']=$appconfig['appversion'];
			$Sresult['description']=$appconfig['description'];
			$Sresult['appimg']=$appconfig['appimg'];
			$Sresult['author']=$appconfig['author'];
			$Sresult['install']=$appconfig['install'];
			$Sresult['uninstall']=$appconfig['uninstall'];
			$Sresult['upgrade']=$appconfig['upgrade'];
            $Sresult['menutitle']=$appconfig['menutitle'];
            $Sresult['menuurl']=$appconfig['menuurl'];
		}
		return $Sresult;
	}
}
?>
