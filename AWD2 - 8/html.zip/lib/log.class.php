<?php

/*
 * 2016-12-23
 * 日志管理类
 * */
class log{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->tinwin = $this->G->loadclass('tinwin');
		$this->pages = $this->G->loadclass('pages');
	}

	//增加登录信息
	public function addLoginLog($username,$status=1,$remark=''){
		$sip=$this->tinwin->getClientIp();
		$dsw=array(
			'addtime'=>time(),
			'login_ip'=>$sip,
			'username'=>$username,
			'login_status'=>$status,
			'remark'=>$remark
		);
		return $this->dbpdo->insert_data("userlogin",$dsw);
	}

	//获取用户的登录次数 2018-09-29 牛哥
	public function getLoginTimes($condition=""){
		$s=$this->dbpdo->getOne("userlogin",'count(*) AS total',$condition);
		return $s['total'];
	}

	//获取登录记录列表 2018-05-10
	public function getList($Spage=1,$Snumber=PAGED,$condition="",$sorder="id desc",$UrlStyle=""){
		$rs['data']=$this->dbpdo->query("userlogin",'*',$condition,"",$sorder,"",strval(intval($Spage-1)*$Snumber),$Snumber);
		$t=$this->dbpdo->getOne("userlogin",'count(*) AS total',$condition);
		$Intpages = $this->pages->set_page_info($t['total'],$Snumber,$UrlStyle);
		if($rs){
			$rs['pages']=$Intpages;
			$rs['total'] = $t['total'];
			return $rs;
		}
	}
}
?>
