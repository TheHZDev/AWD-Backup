<?php
/*
 * 搜索类 2018-03-03*/
class search{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->tinwin=$this->G->loadclass('tinwin');
		$this->pages=$this->G->loadclass('pages');
	}

	public function getAll($condition="",$orderby="search_id"){
		$rs=$this->dbpdo->query("search",'*',$condition,"",$orderby);
		return $rs;
	}

	public function getList($Spage=1,$Snumber=PAGED,$condition="",$UrlStyle="",$orderby=''){	
		$rs['data']=$this->dbpdo->query("search",'*',$condition,"",$orderby,"",strval(intval($Spage-1)*$Snumber),$Snumber);
		$t=$this->dbpdo->query("search",'count(*) AS total',$condition);
		$Intpages = $this->pages->set_page_info($t[0]['total'],$Snumber,$UrlStyle);
		if($rs){
			$rs['pages']=$Intpages;
			$rs['total'] = $t[0]['total'];
		}		
		return $rs;
	}


	//根据关键词获取所有文章
	public function getAllArtByKey($skey="",$Spage=1,$UrlStyle="",$Snumber=PAGED){
		$rs=array();
		$issearch=1;
		$ArtList=$this->dbpdo->query("article","*","title like '%$skey%' or content like '%$skey%'","","","",strval(intval($Spage-1)*$Snumber),$Snumber);
		$t=$this->dbpdo->query("article",'count(*) AS total',"title like '%$skey%' or content like '%$skey%'");
		$Intpages = $this->pages->set_page_info($t[0]['total'],$Snumber,$UrlStyle);
		if(!$ArtList){
			$issearch=0;
		}
		$sip=$this->tinwin->getClientIp();
		$istoken=$this->dbpdo->getOne("search","*",array('search_keywords'=>$skey,'search_ip'=>$sip));
		if(!$istoken){
			if($issearch==0){
				$row=array(
					'search_keywords'=>$skey,
					'search_ip'=>$sip,
					'search_time'=>TIME,
					'issearch'=>0
				);
				$this->dbpdo->insert_data('search',$row);
				return false;
			}else{
				$row=array(
					'search_keywords'=>$skey,
					'search_ip'=>$sip,
					'search_time'=>TIME,
					'issearch'=>1
				);
				$this->dbpdo->insert_data('search',$row);
			}			
		}
		$rs['pages']=$Intpages;
		$rs['total']=$t[0]['total'];
		$rs['data']=$this->G->loadclass('article')->ArtListAddUrl($ArtList);
		return $rs;
	}

	//根据内容设置内链
	/*
	 * 1、将内链数据表中的数据跟内容比较，并查看出现的次数。
	 * 2、如果优先级高的内链存在，就把优先级低的内链排除
	 * 
	*/
	public function setInLinkByContent($Content){
		$SInLink=$this->dbpdo->query("inlink","*","","","link_level desc");
		if(!$SInLink){
			return false;
		}
		foreach($SInLink as $key => $value){
			//$Scount[$key]=$key*10;
			$Scount[$key]=substr_count($Content,$value['link_title']);//记录子串出现的次数
			//echo $value['link_title']." ".$Scount[$key]."<br>";
		}
		foreach($Scount as $key=>$value){
			if($value==0){
				unset($SInLink[$key]);//删除没有出现的内链
			}
		}
		foreach($SInLink as $key=>$value){
			$Stitle=trim($SInLink[$key]['link_title']);
			foreach($SInLink as $key2 => $value2){
				if(strripos($Stitle,trim($value2['link_title']))===false){//必须是=== 否则取出错误结果				
				}else{
					if($key<>$key2){//排除跟自己比较
						unset($SInLink[$key2]);
					}					
				}
			}
		}
		foreach($SInLink as $key=>$value){
			$str=$value['link_title'];
			$str2='<a href="'.$value['link_url'].'">'.$value['link_title'].'</a>';
			$Content=str_replace($str,$str2,$Content,$value['replace_times']);
			//$Content=$NewContent;
		}
		return $Content;
	}

	//是否显示
	public function isview($IntID){
		$Strok="";
		$list=$this->dbpdo->getOne("search","*",array('search_id' => $IntID));
		if($list['isview']==0){
			$row=array(
				'isview'=>1
			);
			$Strok='<span class="glyphicon glyphicon-eye-open"></span>';
		}else{
			$row=array(
				'isview'=>0
			);
			$Strok='<span class="glyphicon glyphicon-eye-close"></span>';
		}
		$this->dbpdo->update_data('search',$row,array('search_id' => $IntID));
		return $Strok;
	}

	//删除
	public function del($IntID){
		return $this->dbpdo->remove("search",array("search_id"=>$IntID));
	}
}
?>
