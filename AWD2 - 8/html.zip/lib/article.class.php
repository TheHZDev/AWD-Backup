<?php
/*
 * 2016-03-25
 * 文章内容操作类
 * */
class article{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->category=$this->G->loadclass('category');
		$this->pages=$this->G->loadclass('pages');
		$this->files=$this->G->loadclass('files');
	}

	//根据条件获取所有文章
	public function getAll($condition=array(),$sfield='*'){
		$ArtList=$this->dbpdo->query("article",$sfield,$condition);
		if(!$ArtList){
			return false;
		}
		$rs=$this->ArtListAddUrl($ArtList);
		return $rs;
	}

	/*
	 * 根据分类ID获取指定记录数
	 * getArtList(分类ID,显示记录数,排序)
	 * 2018-04-23
	 */
	public function getArtList($cid='0',$Snumber=10,$orderby='id desc'){
		$cidArr=explode(',',$cid);
		foreach ($cidArr as $key => $value) {
			$cids=$this->category->getCids(array('parent_id'=>$value));
			if($cids){
				$cids=$cids.','.$value;
			}else{
				$cids=$value;
			}
			$cidStr=$cidStr.','.$cids;
		}
		$ArtList=$this->dbpdo->query("article",'*',"FIND_IN_SET(cat_id,'".$cidStr."')","",$orderby,"","0",$Snumber);
		if(!$ArtList){
			return false;
		}
		$rs=$this->ArtListAddUrl($ArtList);
		return $rs;
	}
    
	//设置文章的URL地址
	public function ArtListAddUrl($rs=array(),$UrlStyle=""){
		foreach($rs as $key=>$value){
			$CatOne=$this->dbpdo->getOne("category","*",array('id'=>$value['cat_id']));
            if($UrlStyle){
                $Url2=SITE_WEB.'/'.$CatOne['catalog_name'].'/'.$UrlStyle;
            }else{
                $Url2=SITE_WEB.'/'.$CatOne['catalog_name'].'/';
            }
            $Surl=$Url2.$value['id'].'.html';
            $rs[$key]['url']=$Surl;
            $rs[$key]['cat_url']=$Url2;
            $rs[$key]['cat_name']=$CatOne['cat_name'];
            if(empty($rs[$key]['img'])){
            	$rs[$key]['img']=STATIC_PATH.'images/noimage.png';
            }
		}
		return $rs;
	}

    //获取文章列表带分页
	public function getList($Spage=1,$Snumber=PAGED,$condition="",$UrlStyle="",$orderby='id desc'){		
		if(empty($condition)){
			$Cids=$this->category->getCids();
			$condition="FIND_IN_SET(cat_id,'".$Cids."')";
		}
		$rs['data']=$this->dbpdo->query("article",'*',$condition,"",$orderby,"",strval(intval($Spage-1)*$Snumber),$Snumber);
		$t=$this->dbpdo->query("article",'count(*) AS total',$condition);
		$Intpages = $this->pages->set_page_info($t[0]['total'],$Snumber,$UrlStyle);
		if($rs['data']){
			$rs['data']=$this->ArtListAddUrl($rs['data'],$UrlStyle="");
			$rs['pages']=$Intpages;
			$rs['total'] = $t[0]['total'];
			return $rs;
		}else{
			return false;
		}	
	}

	//根据ID序列获取文章
	public function getAllByIDs($IntIDs){
		return $this->dbpdo->query("article",'*',"FIND_IN_SET(id,'".$IntIDs."')");
	}
	
	//根据条件获取一条文章记录
	public function getOne($condition=array(),$sfield='*'){
		return $list=$this->dbpdo->getOne("article",$sfield,$condition);
	}

	//根据分类ID获取一条记录
	public function getOneByID($IntID){
		$ArtMe=$this->dbpdo->getOne("article",'*',array('id'=>$IntID));
		$CatOne=$this->category->getOneByID($ArtMe['cat_id']);
		$ArtMe['catalog_name']=$CatOne['catalog_name'];
		return $ArtMe;
	}

	//根据分类ID获取下一条记录
	public function getNextByID($IntID){
		$CurArt=$this->getOneByID($IntID);//查找当前ID文章
		$condition="id>".$IntID." and cat_id=".$CurArt['cat_id'];
		$NextArt=$this->dbpdo->query("article",'*',$condition,'','id','','0','1');
		if($NextArt){
			$Surl='/'.$CurArt['catalog_name'].'/'.$NextArt[0]['id'].'.html';
			$Sresult='<a href="'.$Surl.'">'.$NextArt[0]['title'].'</a>';
		}else{
			$Sresult="没有了";
		}
		return $Sresult;
	}
	
	//根据分类ID获取上一条记录
	public function getPreByID($IntID){
		$CurArt=$this->getOneByID($IntID);//查找当前ID文章
		$condition="id<".$IntID." and cat_id=".$CurArt['cat_id'];
		$PreArt=$this->dbpdo->query("article",'*',$condition,'','id DESC','','0','1');
		if($PreArt){
			$Surl='/'.$CurArt['catalog_name'].'/'.$PreArt[0]['id'].'.html';
			$Sresult='<a href="'.$Surl.'">'.$PreArt[0]['title'].'</a>';
		}else{
			$Sresult="没有了";
		}		
		return $Sresult;
	}

	//新增文章
	public function save($dsw){
		$dsw['endtime']=time();
		$dsw['enduser']=$_SESSION['tinwinsession']['uid'];
		if(empty($dsw['addtime'])){
            $dsw['addtime']=time();
        }
		$dsw['adduser']=$_SESSION['tinwinsession']['uid'];
        if(empty($dsw['img'])){
            $dsw['img']=$this->files->getFirstImg($dsw['content']);//将内容中的第一张图片作为缩略图
        }
		$this->dbpdo->insert_data("article",$dsw);
		return $this->dbpdo->getInsertId();
	}

	//更新文章
	public function update($dsw=array(),$condition=array()){
		$dsw['endtime']=time();
		$dsw['enduser']=$_SESSION['tinwinsession']['uid'];
		$img=$this->dbpdo->getOne("article","*",$condition);
		if(empty($dsw['img'])&&empty($img['img'])){
			$dsw['img']=$this->files->getFirstImg($dsw['content']);
		}
		return $this->dbpdo->update_data("article",$dsw,$condition);
	}

	//文章删除
	public function del($IntID){
		return $this->dbpdo->remove("article",array("id"=>$IntID));
	}

	//是否显示
	public function isview($IntID){
		$Strok="";
		$list=$this->dbpdo->getOne("article","*",array('id' => $IntID));
		if($list['isview']==0){
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'isview'=>1
			);
			$Strok='<span class="glyphicon glyphicon-eye-open"></span>';
		}else{
			$row=array(
				'endtime'=>time(),
				'enduser'=>$_SESSION['tinwinsession']['uid'],
				'isview'=>0
			);
			$Strok='<span class="glyphicon glyphicon-eye-close"></span>';
		}
		$this->dbpdo->update_data('article',$row,array('id' => $IntID));
		return $Strok;
	}

	//增加浏览次数
	public function updateView($IntID){
		$intview=$this->dbpdo->getOne("article",'*',array('id'=>$IntID));
		$dsw=array(
			"view"=>$intview['view']+1
		);
		return $this->dbpdo->update_data("article",$dsw,array('id'=>$IntID));
	}

	//检查文章标题是否存在
	public function getCheckTitle($STitle,$IntID=0){
		$Strok="";
		$list=$this->dbpdo->getOne("article","*",array('title' => $STitle));
		if($list['title']&&$IntID!=$list['id']){
			return false;
		}else{
			return true;
		}
	}

	//获取面包屑导航
	public function getNavCrumbByAid($IntID=0){
		$CurArt=$this->getOneByID($IntID);
		if($CurArt){
			$Sresult=$this->category->getNavCrumbByCid($CurArt['cat_id']);
		}
		return $Sresult;
	}

	//获取所有特殊排序文章（热门文章view,最新文章addtime）
	public function getSpecialArt($IntCid=0,$Number=PAGED,$orderby='id',$fields='*',$ssort='DESC'){
		$cids=$this->category->getCids(array('parent_id'=>$IntCid));
		if($cids){
			$cids=$cids.','.$IntCid;
		}else{
			$cids=$IntCid;
		}
		$condition="FIND_IN_SET(cat_id,'".$cids."')";
		$ArtList=$this->dbpdo->query("article",$fields,$condition,"",$orderby,"",'0',$Number);
		if(!$ArtList){
			return false;
		}
		$rs=$this->ArtListAddUrl($ArtList);
		if($ssort=='DESC'){
			array_multisort(array_column($rs,'id'),SORT_DESC,$rs);
		}else{
			array_multisort(array_column($rs,'id'),SORT_ASC,$rs);
		}
		return $rs;
	}

}
?>
