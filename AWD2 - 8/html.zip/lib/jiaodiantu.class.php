<?php

/*
 * 2016-12-23
 * 日志管理类
 * */
class jiaodiantu{
	public $G;
	public function __construct(&$G){
		$this->G = $G;
	}

	public function _init(){
		$this->dbpdo=$this->G->loadclass('dbpdo');
		$this->pages = $this->G->loadclass('pages');
	}

	public function getAll($condition=array('isview'=>1),$sfield='*',$sorder="inrow,id desc"){
		return $this->dbpdo->query("jiaodiantu",$sfield,$condition,"",$sorder);
	}

	public function getList($Spage=1,$Snumber=PAGED,$condition="",$sorder="inrow,id desc",$UrlStyle=""){
		$rs['data']=$this->dbpdo->query("jiaodiantu",'*',$condition,"",$sorder,"",strval(intval($Spage-1)*$Snumber),$Snumber);
		$t=$this->dbpdo->getOne("jiaodiantu",'count(*) AS total',$condition);
		$Intpages = $this->pages->set_page_info($t['total'],$Snumber,$UrlStyle);
		if($rs){
			$rs['pages']=$Intpages;
			$rs['total'] = $t['total'];
			return $rs;
		}
	}

	public function getSpecial($Number=PAGED,$sorder="inrow",$condition=array('isview'=>1),$sfield='*'){
		return $this->dbpdo->query("jiaodiantu",$sfield,$condition,"",$sorder,"",'0',$Number);
	}

	public function getOne($condition="",$sfield='*'){
		return $this->dbpdo->getOne("jiaodiantu",$sfield,$condition);
	}

	public function addSave($dsw){
		$this->dbpdo->insert_data("jiaodiantu",$dsw);
		return $this->dbpdo->getInsertId();
	}

	public function update($dsw=array(),$condition=array()){
		if($condition){
			return $this->dbpdo->update_data("jiaodiantu",$dsw,$condition);
		}
	}

	public function del($IntID=0){
		return $this->dbpdo->remove("jiaodiantu",array("id"=>$IntID));
	}

	public function isview($IntID){
		$Strok="";
		$list=$this->dbpdo->getOne("jiaodiantu","*",array('id' => $IntID));
		if($list['isview']==0){
			$isview=1;
			$Strok='显示';
		}else{
			$isview=0;
			$Strok='不显示';
		}
		$this->dbpdo->update_data('jiaodiantu',array('isview'=>$isview),array('id' => $IntID));
		return $Strok;
	}
}
?>
