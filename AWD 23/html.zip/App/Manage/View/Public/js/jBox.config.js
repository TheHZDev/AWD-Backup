
if(typeof(data_path) == 'undefined'){data_path="";}
document.write('<script type="text/javascript" src="'+data_path+'/static/jq_plugins/jBox/jquery.jBox-2.3.min.js"></script>');
document.write('<script type="text/javascript" src="'+data_path+'/static/jq_plugins/jBox/i18n/jquery.jBox-zh-CN.js"></script>');
document.write('<link rel="stylesheet" type="text/css" href="'+data_path+'/static/jq_plugins/jBox/Skins2/Blue/jbox.css" />');
