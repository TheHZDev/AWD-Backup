<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>我的网站</title>
<meta name="keywords" content="我的网站" />
<meta name="description" content="我的网站" />
<link rel="stylesheet" type="text/css" href="/Public/Home/blog/css/main.css" />
<link rel="stylesheet" type="text/css" href="/Public/Home/blog/css/ez.css" />
<?php
 $_flag = 0; switch ($_flag) { case 0: if (C('CFG_MOBILE_AUTO') == 1) { if (C('HTML_CACHE_ON') == true) { echo '<script type="text/javascript" src="/Data/static/js/mobile_auto.js"></script>'; } else { go_mobile(); } } break; case 1: go_mobile(); break; case 2: if (C('CFG_MOBILE_AUTO') == 1) { echo '<script type="text/javascript" src="/Data/static/js/mobile_auto.js"></script>'; } break; default: break; } ?>
</head>
<body>

<!-- Layout 2 -->
<div class="ez-mw wraper">
	<div class="ez-wr header">
		<div class="logo">
		<h1><a href="" title="我的网站" rel="home">我的网站</a></h1>
		<p>我的网站</p>
		</div>        
		<div class="top-ad"> </div>
	</div>
	<div class="ez-wr nav">
		<ul class="nav-menu">
			<li><a href="">首 页</a></li>
			<?php
 $_typeid = 0; if($_typeid == -1) $_typeid = I('cid', 0, 'intval'); $_navlist = get_category(1); if($_typeid == 0) { $_navlist = Common\Lib\Category::toLayer($_navlist); }else { $_navlist = Common\Lib\Category::toLayer($_navlist, 'child', $_typeid); } foreach($_navlist as $autoindex => $navlist): $navlist['url'] = get_url($navlist); ?><li><a href='<?php echo ($navlist["url"]); ?>'><?php echo ($navlist["name"]); ?></a></li><?php endforeach;?>
		</ul>
	</div>
	<div class="ez-wr">
		<div class="banner" id="Banner">
			<div class="banner-box" id="BannerBox">
				<ul class="banner-content" id="BannerContent">
					<li><a href="javascript:void(0)"><IMG src="/Public/Home/blog/images/photo/2.jpg"></a></li>
					<li><a href="javascript:void(0)"><IMG src="/Public/Home/blog/images/photo/1.jpg"></a></li>
				</ul>
			</div>
			<div class="banner-tab">
				<a class="tab-prev" id="BannerPrev" href="javascript:void(0);"><span>&#8249;</span></a> 
				<a class="tab-next" id="BannerNext" href="javascript:void(0);"><span>&#8250;</span></a>
			</div>
		</div>
	</div>
    <!-- Module 2A -->
	<div class="ez-wr marginT">
		<div class="ez-fl ez-negmr ez-66">	
			<?php
 $_typeid = -1; $_keyword = ""; $_arcid = ""; if($_typeid == -1) $_typeid = I('get.cid', 0, 'intval'); if ($_typeid>0 || substr($_typeid,0,1) == '$') { $ids = Common\Lib\Category::getChildsId(get_category(), $_typeid, true); $where = array('article.status' => 0, 'article.cid'=> array('IN',$ids)); }else { $where = array('article.status' => 0); } if ($_keyword != '') { $where['article.title'] = array('like','%'.$_keyword.'%'); } if (!empty($_arcid)) { $where['article.id'] = array('IN', $_arcid); } if (0 > 0) { $where['_string'] = 'article.flag & 0 = 0 '; } if (9 > 0) { $count = D2('ArcView','article')->where($where)->count(); $ename = I('e', '', 'htmlspecialchars,trim'); if (!empty($ename) && C('URL_ROUTER_ON') == true) { $param['p'] = I('p', 1, 'intval'); $param_action = '/'.$ename; }else { $param = array(); $param_action = ''; } $thisPage = new \Common\Lib\Page($count, 9, $param, $param_action); $thisPage->rollPage = 5; $thisPage->setConfig('theme'," %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%"); $limit = $thisPage->firstRow. ',' .$thisPage->listRows; $page = $thisPage->show(); }else { $limit = "10"; } $_artlist = D2('ArcView','article')->nofield('content')->where($where)->order("id DESC")->limit($limit)->select(); if (empty($_artlist)) { $_artlist = array(); } foreach($_artlist as $autoindex => $artlist): $_jumpflag = ($artlist['flag'] & B_JUMP) == B_JUMP? true : false; $artlist['url'] = get_content_url($artlist['id'], $artlist['cid'], $artlist['ename'], $_jumpflag, $artlist['jumpurl']); if(0) $artlist['title'] = str2sub($artlist['title'], 0, 0); if(0) $artlist['description'] = str2sub($artlist['description'], 0, 0); ?><div class="one-box">
				<h2 class="one-box-title"><a href="<?php echo ($artlist["url"]); ?>"><?php echo ($artlist["title"]); ?></a></h2>
				<div class="post-meta">
					<span class="meta-date"><?php echo (date('Y年m月d日',$artlist["publishtime"])); ?></span>
					<span class="meta-category"><?php echo ($artlist["catename"]); ?></span>
					<span class="meta-permalink"><a href="<?php echo ($artlist["url"]); ?>">永久链接</a></span>
				</div>
				<?php if(!empty($artlist['litpic'])): ?><p class="center"><img src="<?php echo ($artlist["litpic"]); ?>" /></p><?php endif; ?>
				<?php echo ($artlist["description"]); ?>
			</div><?php endforeach;?>	
			
			<div class="pager clearfix"><?php echo ($page); ?></div>
		
		</div>
		<div class="ez-last ez-oh">
		<div class="sidebar">          
		<div class="sidebar-box clearfix">
			<form method="post" id="searchbar" action="<?php echo U('Search/index');?>">
				<input type="text" size="16" name="keyword" value="搜索" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" id="search" />
				<input type="submit" id="searchsubmit" value="" />
			</form>
		</div>
		<div class="sidebar-box clearfix">
			<h4>近期文章</h4>	
			<ul>
				<?php
 $_typeid = -1; $_keyword = ""; $_arcid = ""; if($_typeid == -1) $_typeid = I('get.cid', 0, 'intval'); if ($_typeid>0 || substr($_typeid,0,1) == '$') { $ids = Common\Lib\Category::getChildsId(get_category(), $_typeid, true); $where = array('article.status' => 0, 'article.cid'=> array('IN',$ids)); }else { $where = array('article.status' => 0); } if ($_keyword != '') { $where['article.title'] = array('like','%'.$_keyword.'%'); } if (!empty($_arcid)) { $where['article.id'] = array('IN', $_arcid); } if (0 > 0) { $where['_string'] = 'article.flag & 0 = 0 '; } if (0 > 0) { $count = D2('ArcView','article')->where($where)->count(); $ename = I('e', '', 'htmlspecialchars,trim'); if (!empty($ename) && C('URL_ROUTER_ON') == true) { $param['p'] = I('p', 1, 'intval'); $param_action = '/'.$ename; }else { $param = array(); $param_action = ''; } $thisPage = new \Common\Lib\Page($count, 0, $param, $param_action); $thisPage->rollPage = 5; $thisPage->setConfig('theme'," %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%"); $limit = $thisPage->firstRow. ',' .$thisPage->listRows; $page = $thisPage->show(); }else { $limit = "5"; } $_artlist = D2('ArcView','article')->nofield('content')->where($where)->order("id DESC")->limit($limit)->select(); if (empty($_artlist)) { $_artlist = array(); } foreach($_artlist as $autoindex => $artlist): $_jumpflag = ($artlist['flag'] & B_JUMP) == B_JUMP? true : false; $artlist['url'] = get_content_url($artlist['id'], $artlist['cid'], $artlist['ename'], $_jumpflag, $artlist['jumpurl']); if(16) $artlist['title'] = str2sub($artlist['title'], 16, 0); if(0) $artlist['description'] = str2sub($artlist['description'], 0, 0); ?><li><a href="<?php echo ($artlist["url"]); ?>"><?php echo ($artlist["title"]); ?></a></li><?php endforeach;?>
			</ul>
		</div>
		<div class="sidebar-box clearfix">
			<h4>分类目录</h4>	
			<ul>
				<?php
 $_typeid = intval(0); $_type = "son"; $_temp = explode(',', "100"); $_temp[0] = $_temp[0] > 0? $_temp[0] : 10; if (isset($_temp[1]) && intval($_temp[1]) > 0) { $_limit[0] = $_temp[0]; $_limit[1] = intval($_temp[1]); }else { $_limit[0] = 0; $_limit[1] = $_temp[0]; } if($_typeid == -1) $_typeid = I('cid', 0, 'intval'); $__catlist = get_category(1); if (0) { $__catlist = Common\Lib\Category::getLevelOfModelId($__catlist, 0); } if (1 == 0) { $__catlist = Common\Lib\Category::clearPageAndLink($__catlist); } if($_typeid == 0 || $_type == 'top') { $_catlist = Common\Lib\Category::toLayer($__catlist); }else { if ($_type == 'self') { $_typeinfo = Common\Lib\Category::getSelf($__catlist, $_typeid ); $_catlist = Common\Lib\Category::toLayer($__catlist, 'child', $_typeinfo['pid']); }else { $_catlist = Common\Lib\Category::toLayer($__catlist, 'child', $_typeid); } } foreach($_catlist as $autoindex => $catlist): if($autoindex < $_limit[0]) continue; if($autoindex >= ($_limit[1]+$_limit[0])) break; $catlist['url'] = get_url($catlist); ?><li><a href="<?php echo ($catlist["url"]); ?>"><?php echo ($catlist["name"]); ?></a></li>
				<?php if(is_array($catlist["child"])): $i = 0; $__LIST__ = $catlist["child"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li>&nbsp;--&nbsp;<a href="<?php echo (get_url($v)); ?>"><?php echo ($v["name"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; endforeach;?>
			</ul>
		</div>
		
		<div class="sidebar-box clearfix">
			<h4>文章归档</h4>
			<ul>
				<?php
 $_modelid = intval(1); $_datelist = get_datelist($_modelid); $_temp = explode(',', "100"); $_temp[0] = $_temp[0] > 0? $_temp[0] : 10; if (isset($_temp[1]) && intval($_temp[1]) > 0) { $_limit[0] = $_temp[0]; $_limit[1] = intval($_temp[1]); }else { $_limit[0] = 0; $_limit[1] = $_temp[0]; } foreach($_datelist as $autoindex => $datelist): if($autoindex < $_limit[0]) continue; if($autoindex >= ($_limit[1]+$_limit[0])) break; $datelist['url'] = U('Archive/index', array('modelid' => $_modelid, 'year' => $datelist['arc_year'],'month' => $datelist['arc_month'])); ?><li><a href='<?php echo ($datelist["url"]); ?>'><?php echo ($datelist["arc_year"]); ?>年<?php echo ($datelist["arc_month"]); ?>[<?php echo ($datelist["arc_num"]); ?>]</a></li><?php endforeach;?>
			</ul>
		</div>
		
		<div class="sidebar-box clearfix">
			<h4>访客留言</h4>
			<ul>
				<?php
 $where = array('id' => array('gt',0)); if (0 > 0) { $count = M('guestbook')->where($where)->count(); $thisPage = new \Common\Lib\Page($count, 0); $thisPage->rollPage = 5; $thisPage->setConfig('theme'," %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%"); $limit = $thisPage->firstRow. ',' .$thisPage->listRows; $page = $thisPage->show(); }else { $limit = "10"; } $_gbooklist = M('guestbook')->where($where)->order("id DESC")->limit($limit)->select(); if (empty($_gbooklist)) { $_gbooklist = array(); } foreach($_gbooklist as $autoindex => $gbooklist): ?><li><span class="name"><?php echo ($gbooklist["username"]); ?></span> <span class="time">(<?php echo (date("Y-m-d H:i:s",$gbooklist["posttime"])); ?>)</span>
				<p><?php echo ($gbooklist["content"]); ?></p>
				</li><?php endforeach;?>
				<li style="text-align:right"><a href="/index.php?s=/Guestbook/index.html">查看所有留言</a></li>
			</ul>
		</div>
		
		</div>
		</div>
	</div>
	<div class="ez-box">
		<div class="flink-box clearfix">
			<h4>友情连接</h4>		
			<div class="note">
				<?php
 $_typeid = 0; if ($_typeid>0 || substr($_typeid,0,1) == '$') { $where = array('ischeck'=> $_typeid); }else { $where = array('id' => array('gt',0)); } if (0 > 0) { $count = M('link')->where($where)->count(); $thisPage = new \Common\Lib\Page($count, 0); $thisPage->rollPage = 5; $thisPage->setConfig('theme'," %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%"); $limit = $thisPage->firstRow. ',' .$thisPage->listRows; $page = $thisPage->show(); }else { $limit = "20"; } $_flink = M('link')->where($where)->order("sort ASC")->limit($limit)->select(); if (empty($_flink)) { $_flink = array(); } foreach($_flink as $autoindex => $flink): ?><a href="<?php echo ($flink["url"]); ?>" target="_blank"><?php echo ($flink["name"]); ?></a><?php endforeach;?>
			</div>
		</div>	
	</div>
		<div class="ez-box">
		<div class="copyright">
        &copy; 2014  我的网站 ~  <a href="http://www.0871k.com/" title="行云海CMS">Power by XYHCMS</a>		</div>			
	</div>	
	<?php
 echo '<script type="text/javascript" src="'.U(MODULE_NAME. '/Public/online').'"></script>'; ?>

</div>
<script language="javascript" src="/Public/Home/blog/js/MSClass.js"></script>
<script type="text/javascript">
new Marquee(
{
	MSClass	  : ["BannerBox","BannerContent"],
	PrevBtnID : "BannerPrev",
	NextBtnID : "BannerNext",
	Direction : 2,
	Step	  : 0.2,
	Width	  : 960,
	Height	  : 350,
	Timer	  : 20,
	DelayTime : 3000,
	WaitTime  : 1000,
	ScrollStep: 0,
	SwitchType: 0,
	AutoStart : true
});

</script>
</body>
</html>