<?php return array (
  'DB_TYPE' => 'mysqli',
  'DB_HOST' => '127.0.0.1',
  'DB_PORT' => '3306',
  'DB_USER' => 'cms',
  'DB_PWD' => '030d6471c729cc8b',
  'DB_NAME' => 'cms',
  'DB_PREFIX' => 'xyh_',
  'DB_CHARSET' => 'utf8',
);?>