<?php

if (C('CFG_WEBSITE_CLOSE') == 1) {
	exit_msg(C('CFG_WEBSITE_CLOSE_INFO'));
}


?>