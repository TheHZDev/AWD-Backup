<?php
return array(
    "NAME" => "分类名称",
    "CATEGORY_KEY" => '分类标识',
    "DESCRIPTION" => "描述",
    "DEFAULT_CATEGORY" => "默认分类",
    "NOT_ALLOWED_EDIT" => "不允许修改",
    "CATEGORY_KEY_HELP_TEXT" => '英文字母,数字或下划线(“_”)'
);