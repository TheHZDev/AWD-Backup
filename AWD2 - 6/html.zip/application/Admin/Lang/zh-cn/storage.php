<?php
return array(
    "DEFAULT" => '系统默认',
    "DOMAIN" => '空间域名',
    "BUCKET" => '空间名称',
);