<?php
return array(
    "NAME" => 'Name',
    "FILE_SIZE" => 'File Size',
    "BACKUP_TIME" => 'Time',
    "SELECT_ALL" => 'Select All',
    "START_BACKUP" => 'Start Backup',
    "BACKUP_TYPE" => 'Backup Type',
    "VOLUME_SIZE" => 'Volume Size',
    "VOLUME_SIZE_HELP_TEXT" => 'Recommended below 10M',
    "CUSTOM_BACKUP" => 'Custom Backup',
    "BACKUP_ALL" => 'Backup All'
);