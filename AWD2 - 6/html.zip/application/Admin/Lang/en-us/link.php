<?php
return array(
    "NAME" => "Link Name",
    "LINK_ADDRESS" => 'Link Address',
    "LINK_ICON" => 'Link Icon',
    "LINK_TARGET" => 'Link Target',
    "LINK_DESCRIPTION" => 'Description'
);