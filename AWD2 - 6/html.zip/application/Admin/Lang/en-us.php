<?php

return array(
		'ADMIN_CENTER' => 'Admin Center',
		'WELCOME_USER' => 'Welcome, {$username}',
		'REFRESH_CURRENT_PAGE' => 'Refresh Current Page',
		'WEBSITE_HOME_PAGE' => 'Website Home Page'
);